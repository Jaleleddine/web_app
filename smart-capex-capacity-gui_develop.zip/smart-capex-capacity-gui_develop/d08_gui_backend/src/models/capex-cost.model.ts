import {Entity, model, property} from '@loopback/repository';

@model()
export class CapexCost extends Entity {

  @property({
    id: true,
    type: 'string',
    required: true,
    index: {
      unique: true,
    },
    mysql: {columnName: 'cell_band'},
    jsonSchema: {
      minLength: 4,
    },
  })
  cellBand: string;

  @property({
    type: 'string',
    required: true,
    mysql: {columnName: 'modified_by'},
  })
  modifiedBy: string;

  @property({
    type: 'number',
    required: true,
    jsonSchema: {
      minLength: 1,
    },
    mysql: {dataType: 'double'}
  })
  capex: number;


  constructor(data?: Partial<CapexCost>) {
    super(data);
  }
}

export interface CapexCostRelations {
  // describe navigational properties here
}

export type CapexCostWithRelations = CapexCost & CapexCostRelations;
