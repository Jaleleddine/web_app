import {Model, model, property} from '@loopback/repository';

@model()
export class Locations extends Model {
  @property({
    type: 'array',
    itemType: 'string',
  })
  villes?: string[];

  @property({
    type: 'array',
    itemType: 'string',
  })
  sitePhysiques?: string[];

  @property({
    type: 'array',
    itemType: 'string',
  })
  quartiers?: string[];

  @property({
    type: 'array',
    itemType: 'string',
  })
  communes?: string[];

  @property({
    type: 'array',
    itemType: 'string',
  })
  departements?: string[];

  @property({
    type: 'array',
    itemType: 'string',
  })
  regions?: string[];

  @property({
    type: 'array',
    itemType: 'string',
  })
  districts?: string[];

  @property({
    type: 'array',
    itemType: 'string',
  })
  zonesCommerciales?: string[];


  constructor(data?: Partial<Locations>) {
    super(data);
  }
}

export interface LocationsRelations {
  // describe navigational properties here
}

export type LocationsWithRelations = Locations & LocationsRelations;
