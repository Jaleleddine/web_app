import {Entity, model, property} from '@loopback/repository';

@model({
  settings: {idInjection: false, mysql: {schema: 'smartcapex_db', table: 'smc_user'}}
})
export class User extends Entity {
  @property({
    type: 'number',
    required: false,
    precision: 10,
    scale: 0,
    id: 1,
    mysql: {columnName: 'id', dataType: 'int', dataLength: null, dataPrecision: 10, dataScale: 0, nullable: 'N'},
  })
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  id?: any;

  @property({
    type: 'string',
    length: 100,
    required: true,
    mysql: {columnName: 'u_name', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  uName: string;

  @property({
    type: 'string',
    required: true,
    length: 255,
    mysql: {columnName: 'firstname', dataType: 'varchar', dataLength: 255, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  firstname: string;

  @property({
    type: 'string',
    required: true,
    length: 50,
    mysql: {columnName: 'u_login', dataType: 'varchar', dataLength: 50, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  uLogin: string;

  @property({
    type: 'string',
    required: true,
    length: 255,
    mysql: {columnName: 'email', dataType: 'varchar', dataLength: 255, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  email: string;

  @property({
    type: 'number',
    precision: 3,
    required: true,
    scale: 0,
    mysql: {columnName: 'is_active', dataType: 'tinyint', dataLength: null, dataPrecision: 3, dataScale: 0, nullable: 'Y'},
  })
  isActive: number;

  @property({
    type: 'date',
    mysql: {columnName: 'created_at', dataType: 'datetime', dataLength: null, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  createdAt?: string;

  @property({
    type: 'date',
    mysql: {columnName: 'updated_at', dataType: 'datetime', dataLength: null, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  updatedAt?: string;

  @property({
    type: 'string',
    required: true,
    length: 255,
    mysql: {columnName: 'created_by', dataType: 'varchar', dataLength: 255, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  createdBy: string;

  @property({
    type: 'string',
    length: 255,
    mysql: {columnName: 'updated_by', dataType: 'varchar', dataLength: 255, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  updatedBy?: string;

  @property({
    type: 'string',
    required: true,
    length: 255,
    mysql: {columnName: 'roles', dataType: 'text', dataLength: 255, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  role: string;

  @property({
    type: 'string',
    required: true,
    length: 255,
    mysql: {columnName: 'phone_number', dataType: 'text', dataLength: 255, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  phoneNumber: string;

  /*@hasOne(() => UserCredentials)
  userCredentials: UserCredentials;*/
  // Define well-known properties here

  // Indexer property to allow additional data
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [prop: string]: any;

  constructor(data?: Partial<User>) {
    super(data);
  }
}

export interface UserRelations {
  // describe navigational properties here
}

export type UserWithRelations = User & UserRelations;
