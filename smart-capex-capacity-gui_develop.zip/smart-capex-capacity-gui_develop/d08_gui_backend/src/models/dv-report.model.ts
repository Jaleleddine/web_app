import {Entity, model, property} from '@loopback/repository';

@model({
  settings: {idInjection: false, mysql: {schema: 'smartcapex_db', table: 'dv_report'}}
})
export class DvReport extends Entity {
  @property({
    type: 'number',
    required: true,
    precision: 10,
    scale: 0,
    id: true,
    mysql: {columnName: 'id', dataType: 'int', dataLength: null, dataPrecision: 10, dataScale: 0, nullable: 'N'},
  })
  id: number;

  @property({
    type: 'string',
    length: 255,
    mysql: {columnName: 'anomaly_short_description', dataType: 'varchar', dataLength: 255, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  anomalyShortDescription?: string;

  @property({
    type: 'string',
    length: 65535,
    mysql: {columnName: 'anomaly_long_description', dataType: 'text', dataLength: 65535, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  anomalyLongDescription?: string;

  @property({
    type: 'string',
    length: 200,
    mysql: {columnName: 'feature_name', dataType: 'varchar', dataLength: 200, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  featureName?: string;

  @property({
    type: 'date',
    mysql: {columnName: 'date', dataType: 'date', dataLength: null, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  date?: string;

  @property({
    type: 'string',
    length: 200,
    mysql: {columnName: 'source', dataType: 'varchar', dataLength: 200, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  source?: string;

  // Define well-known properties here

  // Indexer property to allow additional data
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [prop: string]: any;

  constructor(data?: Partial<DvReport>) {
    super(data);
  }
}

export interface DvReportRelations {
  // describe navigational properties here
}

export type DvReportWithRelations = DvReport & DvReportRelations;
