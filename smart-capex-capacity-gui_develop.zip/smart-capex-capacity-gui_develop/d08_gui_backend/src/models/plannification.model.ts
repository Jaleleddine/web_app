import {Entity, model, property} from '@loopback/repository';

@model()
export class Plannification extends Entity {
  @property({
    type: 'number',
    id: true,
    generated: true,
  })
  id?: number;

  @property({
    type: 'string',
    required: true,
  })
  name: string;

  @property({
    type: 'number',
    required: false,
    default: null,
  })
  budget?: number;

  @property({
    type: 'array',
    itemType: 'string',
    required: true,
    mysql: {
      dataType: 'longtext'
    }
  })
  zonesConsidered: string[];

  @property({
    type: 'array',
    itemType: 'object',
    required: true,
    default: null,
    mysql: {
      dataType: 'longtext'
    }
  })
  sitesConsidered: object[];

  @property({
    type: 'array',
    itemType: 'object',
    required: false,
    default: null,
    mysql: {
      dataType: 'longtext'
    }
  })
  sitesExcluded?: object[];

  @property({
    type: 'string',
    required: true,
  })
  etatValidation: string;

  @property({
    type: 'number',
    required: false,
    default: null,
  })
  impactDuration?: number;

  @property({
    type: 'number',
    required: false,
    default: null,
  })
  wacc?: number;

  @property({
    type: 'array',
    itemType: 'object',
    default: null,
    mysql: {
      dataType: 'longtext'
    }
  })
  steeringNetwork?: object[];

  @property({
    type: 'date',
    default: null,
  })
  dateDebut?: string;

  @property({
    type: 'string',
    required: true,
  })
  anneeDeploiement: string;

  @property({
    type: 'string',
    required: true,
  })
  statutAnalyse: string;

  @property({
    type: 'string',
    required: true,
  })
  createdBy?: string;

  @property({
    type: 'string',
    required: false,
    default: null,
  })
  updatedBy?: string;

  @property({
    type: 'string',
    required: false,
    default: null,
  })
  validatedBy?: string;


  constructor(data?: Partial<Plannification>) {
    super(data);
  }
}

export interface PlannificationRelations {
  // describe navigational properties here
}

export type PlannificationWithRelations = Plannification & PlannificationRelations;
