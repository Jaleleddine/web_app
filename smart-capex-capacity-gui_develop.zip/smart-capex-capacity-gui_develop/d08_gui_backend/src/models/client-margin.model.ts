import {Entity, model, property} from '@loopback/repository';

@model()
export class ClientMargin extends Entity {

  @property({
    type: 'string',
    required: true,
    id: true,
    index: {
      unique: true,
    },
    jsonSchema: {
      minLength: 2,
    },
  })
  identifiant: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      minLength: 1,
    },
  })
  categorie: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      minLength: 1,
    },
  })
  donnee: string;

  @property({
    type: 'string',
    required: false,
    jsonSchema: {
      minLength: 1,
    },
  })
  unite: string;

  @property({
    type: 'number',
    jsonSchema: {
      minLength: 1,
    },
  })
  valeur: number;


  constructor(data?: Partial<ClientMargin>) {
    super(data);
  }
}

export interface ClientMarginRelations {
  // describe navigational properties here
}

export type ClientMarginWithRelations = ClientMargin & ClientMarginRelations;
