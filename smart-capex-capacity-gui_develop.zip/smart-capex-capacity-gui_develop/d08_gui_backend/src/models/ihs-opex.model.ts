import {Entity, model, property} from '@loopback/repository';

@model()
export class IhsOpex extends Entity {

  @property({
    type: 'string',
    required: true,
    id: true,
    index: {
      unique: true,
    },
    jsonSchema: {
      minLength: 4,
    },
  })
  band: string;

  @property({
    type: 'number',
    required: true,
    jsonSchema: {
      minLength: 1,
    },
  })
  averageEnergy: number;

  @property({
    type: 'number',
    required: true,
    jsonSchema: {
      minLength: 1,
    },
  })
  gridGensetSiteAverageMonthlyOpexXof: number;

  @property({
    type: 'number',
    required: true,
    jsonSchema: {
      minLength: 1,
    },
  })
  gensetOnlyOrSolarSiteAverageMonthlyOpexXof: number;


  constructor(data?: Partial<IhsOpex>) {
    super(data);
  }
}

export interface IhsOpexRelations {
  // describe navigational properties here
}

export type IhsOpexWithRelations = IhsOpex & IhsOpexRelations;
