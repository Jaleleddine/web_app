import {Entity, model, property} from '@loopback/repository';

@model()
export class Constante extends Entity {

  @property({
    type: 'string',
    required: true,
    id: true,
    index: {
      unique: true,
    },
    jsonSchema: {
      minLength: 2,
    },
  })
  identifiant: string;

  @property({
    type: 'string',
    required: true,
    mysql: {columnName: 'modified_by'},
  })
  modifiedBy: string;


  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      minLength: 2,
    },
  })
  parameter: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      minLength: 1,
    }
  })
  valeur: string;


  constructor(data?: Partial<Constante>) {
    super(data);
  }
}

export interface ConstanteRelations {
  // describe navigational properties here
}

export type ConstanteWithRelations = Constante & ConstanteRelations;
