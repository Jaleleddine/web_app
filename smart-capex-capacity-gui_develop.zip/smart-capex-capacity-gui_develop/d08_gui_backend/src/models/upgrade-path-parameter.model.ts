import {Entity, model, property} from '@loopback/repository';

@model()
export class UpgradePathParameter extends Entity {

  @property({
    type: 'string',
    required: true,
    id: true,
    index: {
      unique: true,
    },
  })
  identifiant: string;

  @property({
    type: 'string',
    required: true,
  })
  parameter: string;

  @property({
    type: 'string',
    required: true,
  })
  valeur: string;


  constructor(data?: Partial<UpgradePathParameter>) {
    super(data);
  }
}

export interface UpgradePathParameterRelations {
  // describe navigational properties here
}

export type UpgradePathParameterWithRelations = UpgradePathParameter & UpgradePathParameterRelations;
