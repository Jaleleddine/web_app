import {Entity, model, property} from '@loopback/repository';

@model()
export class Cagr extends Entity {

  @property({
    type: 'string',
    id: true,
    required: true,
    index: {
      unique: true,
    },
    jsonSchema: {
      maxLength: 100,
      minLength: 15,
    },
  })
  identifiant: string;

  @property({
    type: 'string',
    required: true,
    mysql: {columnName: 'modified_by'},
  })
  modifiedBy: string;

  @property({
    type: 'string',
    required: true,
  })
  parameter: string;

  @property({
    type: 'number',
    jsonSchema: {
      minLength: 1,
    },
    mysql: {dataType: 'double'}
  })
  valeur?: number;


  constructor(data?: Partial<Cagr>) {
    super(data);
  }
}

export interface CagrRelations {
  // describe navigational properties here
}

export type CagrWithRelations = Cagr & CagrRelations;
