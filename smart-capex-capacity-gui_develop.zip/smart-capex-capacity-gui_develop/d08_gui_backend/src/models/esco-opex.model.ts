import {Entity, model, property} from '@loopback/repository';

@model({settings: {strict: true}})
export class EscoOpex extends Entity {

  @property({
    type: 'string',
    required: true,
    id: true,
    index: {
      unique: true,
    },
    jsonSchema: {
      minLength: 4,
    },
  })
  band: string;

  @property({
    type: 'number',
    required: true,
    jsonSchema: {
      minLength: 1,
    },
  })
  averagePower: number;


  @property({
    type: 'number',
    required: true,
    jsonSchema: {
      minLength: 1,
    },
  })
  indoorAverageMonthlyOpexXof: number;

  @property({
    type: 'number',
    required: true,
    jsonSchema: {
      minLength: 1,
    },
  })
  outdoorAverageMonthlyOpexXof: number;

  // Define well-known properties here

  // Indexer property to allow additional data
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [prop: string]: any;

  constructor(data?: Partial<EscoOpex>) {
    super(data);
  }
}

export interface EscoOpexRelations {
  // describe navigational properties here
}

export type EscoOpexWithRelations = EscoOpex & EscoOpexRelations;
