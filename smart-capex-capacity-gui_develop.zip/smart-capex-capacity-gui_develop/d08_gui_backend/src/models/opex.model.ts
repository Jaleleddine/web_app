import {Entity, model, property} from '@loopback/repository';

@model()
export class Opex extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: false,
    required: true,
    jsonSchema: {
      minLength: 4,
    },
  })
  identifiant: string;

  @property({
    type: 'string',
    generated: false,
    required: true,
    mysql: {columnName: 'cell_band'},
    jsonSchema: {
      minLength: 4,
    },
  })
  cellBand: string;

  @property({
    type: 'string',
    required: true,
  })
  provider: string;

  @property({
    type: 'string',
    required: true,
    mysql: {columnName: 'modified_by'},
  })
  modifiedBy: string;

  @property({
    type: 'number',
    required: true,
    mysql: {dataType: 'double'}
  })
  power: number;

  @property({
    type: 'number',
    mysql: {dataType: 'double'}
  })
  indoor?: number;

  @property({
    type: 'number',
    mysql: {dataType: 'double'}
  })
  outdoor?: number;

  @property({
    type: 'number',
    mysql: {columnName: 'grid_genset', dataType: 'double'},
  })
  gridGenset?: number;

  @property({
    type: 'number',
    mysql: {dataType: 'double'}
  })
  other?: number;


  constructor(data?: Partial<Opex>) {
    super(data);
  }
}

export interface OpexRelations {
  // describe navigational properties here
}

export type OpexWithRelations = Opex & OpexRelations;
