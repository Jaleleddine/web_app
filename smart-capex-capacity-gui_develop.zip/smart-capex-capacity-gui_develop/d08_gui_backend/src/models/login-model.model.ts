import {Model, model, property} from '@loopback/repository';

@model()
export class LoginModel extends Model {
  @property({
    type: 'string',
    required: true,
  })
  login: string;

  @property({
    type: 'string',
    required: true,
  })
  password: string;


  constructor(data?: Partial<LoginModel>) {
    super(data);
  }
}

export interface LoginModelRelations {
  // describe navigational properties here
}

export type LoginModelWithRelations = LoginModel & LoginModelRelations;
