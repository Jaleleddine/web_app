import {Entity, model, property} from '@loopback/repository';

@model({
  settings: {
    idInjection: false,
    mysql: {schema: 'smartcapex_db', table: 'final_npv_of_the_coverage'}
  }
})
export class FinalNpvOfTheCoverage extends Entity {
  @property({
    type: 'number',
    required: true,
    precision: 10,
    scale: 0,
    id: 1,
    mysql: {columnName: 'ID', dataType: 'int', dataLength: null, dataPrecision: 10, dataScale: 0, nullable: 'N'},
  })
  id: number;

  @property({
    type: 'string',
    length: 10,
    mysql: {columnName: 'site_id', dataType: 'varchar', dataLength: 10, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  siteId?: string;

  @property({
    type: 'string',
    length: 10,
    mysql: {columnName: 'cell_band', dataType: 'varchar', dataLength: 10, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  cellBand?: string;

  @property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'cashflow_year_0', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  cashFlowYear0?: string;

  @property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'cashflow_year_1', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  cashFlowYear1?: string;

  @property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'cashflow_year_2', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  cashFlowYear2?: string;

  @property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'cashflow_year_3', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  cashFlowYear3?: string;

  @property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'cashflow_year_4', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  cashFlowYear4?: string;

  @property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'cashflow_year_5', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  cashFlowYear5?: string;

  /*@property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'cashflow_year_6', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  cashFlowYear6?: string;*/

  @property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'NPV', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  npv?: string;

  @property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'opex_cost_year_0', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  opexCostYear0?: string;

  @property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'opex_cost_year_1', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  opexCostYear1?: string;

  @property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'opex_cost_year_2', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  opexCostYear2?: string;

  @property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'opex_cost_year_3', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  opexCostYear3?: string;

  @property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'opex_cost_year_4', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  opexCostYear4?: string;

  @property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'opex_cost_year_5', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  opexCostYear5?: string;

  @property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'opex_cost_year_6', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  opexCostYear6?: string;

  @property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'total_opex', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  totalOpex?: string;

  @property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'total_revenue', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  totalRevenue?: string;

  @property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'EBITDA_Value', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  ebitdaValue?: string;

  @property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'EBITDA', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  ebitda?: string;

  @property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'IRR', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  irr?: string;

  @property({
    type: 'string',
    length: 255,
    mysql: {columnName: 'localite', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  localite?: string;

  @property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'ua', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  ua?: string;

  @property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'zone_commerciale', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  zoneCommerciale?: string;

  @property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'latitude', dataType: 'double', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  latitude?: string;

  @property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'longitude', dataType: 'double', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  longitude?: string;

  @property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'population_couverte', dataType: 'double', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  populationCouverte?: string;

  // Define well-known properties here

  // Indexer property to allow additional data
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [prop: string]: any;

  constructor(data?: Partial<FinalNpvOfTheCoverage>) {
    super(data);
  }
}

export interface FinalNpvOfTheCoverageRelations {
  // describe navigational properties here
}

export type FinalNpvOfTheCoverageWithRelations = FinalNpvOfTheCoverage & FinalNpvOfTheCoverageRelations;
