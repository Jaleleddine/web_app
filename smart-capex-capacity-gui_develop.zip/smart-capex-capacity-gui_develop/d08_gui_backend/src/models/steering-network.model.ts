import {Entity, model, property} from '@loopback/repository';

@model()
export class SteeringNetwork extends Entity {
  @property({
    type: 'string',
    id: true,
    generated: false,
    required: true,
    jsonSchema: {
      minLength: 2,
    },
  })
  identifiant: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      minLength: 1,
    },
  })
  technologie: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      minLength: 1,
    },
  })
  typeTraffic: string;


  @property({
    type: 'string',
    required: true,
    default: 'NA',
    jsonSchema: {
      minLength: 1,
    },
  })
  steering2020Percent: string;

  @property({
    type: 'string',
    required: true,
    default: 'NA',
    jsonSchema: {
      minLength: 1,
    },
  })
  steering2021Percent: string;

  @property({
    type: 'string',
    required: true,
    jsonSchema: {
      minLength: 1,
    },
  })
  steering2022Percent: string;

  @property({
    type: 'string',
    default: 'NA',
    jsonSchema: {
      minLength: 1,
    },
  })
  steering2023Percent?: string;

  @property({
    type: 'string',
    default: 'NA',
    jsonSchema: {
      minLength: 1,
    },
  })
  steering2024Percent?: string;

  @property({
    type: 'string',
    default: 'NA',
    jsonSchema: {
      minLength: 1,
    },
  })
  steering2025Percent?: string;


  constructor(data?: Partial<SteeringNetwork>) {
    super(data);
  }
}

export interface SteeringNetworkRelations {
  // describe navigational properties here
}

export type SteeringNetworkWithRelations = SteeringNetwork & SteeringNetworkRelations;
