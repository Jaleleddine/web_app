import {Entity, model, property} from '@loopback/repository';

@model({
  settings: {idInjection: false, mysql: {schema: 'smartcapex_db', table: 'sites'}}
})
export class Sites extends Entity {
  @property({
    type: 'string',
    id: true,
    mysql: {columnName: 'site_id', dataType: 'text', dataLength: 65535, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  siteId?: string;

  @property({
    type: 'string',
    length: 65535,
    mysql: {columnName: 'site_physique', dataType: 'text', dataLength: 65535, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  sitePhysique?: string;

  @property({
    type: 'string',
    length: 65535,
    mysql: {columnName: 'site_status', dataType: 'text', dataLength: 65535, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  siteStatus?: string;

  @property({
    type: 'string',
    length: 65535,
    mysql: {columnName: 'site_ville', dataType: 'text', dataLength: 65535, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  siteVille?: string;

  @property({
    type: 'string',
    length: 65535,
    mysql: {columnName: 'site_gestionnaire', dataType: 'text', dataLength: 65535, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  siteGestionnaire?: string;

  @property({
    type: 'string',
    length: 65535,
    mysql: {columnName: 'site_quartier', dataType: 'text', dataLength: 65535, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  siteQuartier?: string;

  @property({
    type: 'string',
    length: 65535,
    mysql: {columnName: 'site_commune', dataType: 'text', dataLength: 65535, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  siteCommune?: string;

  @property({
    type: 'string',
    length: 65535,
    mysql: {columnName: 'site_department', dataType: 'text', dataLength: 65535, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  siteDepartment?: string;

  @property({
    type: 'string',
    length: 65535,
    mysql: {columnName: 'site_region', dataType: 'text', dataLength: 65535, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  siteRegion?: string;

  @property({
    type: 'string',
    length: 65535,
    mysql: {columnName: 'site_district', dataType: 'text', dataLength: 65535, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  siteDistrict?: string;

  @property({
    type: 'string',
    length: 65535,
    mysql: {columnName: 'site_zone_commerciale', dataType: 'text', dataLength: 65535, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  siteZoneCommerciale?: string;

  @property({
    type: 'number',
    precision: 22,
    mysql: {columnName: 'site_longitude', dataType: 'double', dataLength: null, /*dataPrecision: 22,*/ dataScale: null, nullable: 'Y'},
  })
  siteLongitude?: number;

  @property({
    type: 'number',
    precision: 22,
    mysql: {columnName: 'site_latitude', dataType: 'double', dataLength: null, /*dataPrecision: 22,*/ dataScale: null, nullable: 'Y'},
  })
  siteLatitude?: number;

  @property({
    type: 'string',
    length: 65535,
    mysql: {columnName: 'site_tower_height', dataType: 'text', dataLength: 65535, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  siteTowerHeight?: string;

  @property({
    type: 'string',
    length: 65535,
    mysql: {columnName: 'site_type_baie', dataType: 'text', dataLength: 65535, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  siteTypeBaie?: string;

  @property({
    type: 'string',
    length: 65535,
    mysql: {columnName: 'site_geotype', dataType: 'text', dataLength: 65535, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  siteGeotype?: string;

  @property({
    type: 'string',
    length: 65535,
    mysql: {columnName: 'site_energy_type', dataType: 'text', dataLength: 65535, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  siteEnergyType?: string;

  @property({
    type: 'string',
    length: 65535,
    mysql: {columnName: 'opex_key', dataType: 'text', dataLength: 65535, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  opexKey?: string;

  // Define well-known properties here

  // Indexer property to allow additional data
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [prop: string]: any;

  constructor(data?: Partial<Sites>) {
    super(data);
  }
}

export interface SitesRelations {
  // describe navigational properties here
}

export type SitesWithRelations = Sites & SitesRelations;
