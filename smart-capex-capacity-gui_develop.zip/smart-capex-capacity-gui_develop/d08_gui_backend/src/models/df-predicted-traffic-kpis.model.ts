import {Model, model, property} from '@loopback/repository';

@model({settings: {strict: false}})
export class DfPredictedTrafficKpis extends Model {

  @property({
    type: 'string',
  })
  siteId?: string;

  @property({
    type: 'string',
    length: 65535,
  })
  sitePhysique?: string;

  @property({
    type: 'string',
    length: 65535,
  })
  siteStatus?: string;

  @property({
    type: 'string',
    length: 65535,

  })
  siteVille?: string;

  @property({
    type: 'string',
    length: 65535,

  })
  siteGestionnaire?: string;

  @property({
    type: 'string',
    length: 65535,

  })
  siteQuartier?: string;

  @property({
    type: 'string',
    length: 65535,

  })
  siteCommune?: string;

  @property({
    type: 'string',
    length: 65535,

  })
  siteDepartment?: string;

  @property({
    type: 'string',
    length: 65535,

  })
  siteRegion?: string;

  @property({
    type: 'string',
    length: 65535,

  })
  siteDistrict?: string;

  @property({
    type: 'string',
    length: 65535,

  })
  siteZoneCommerciale?: string;

  @property({
    type: 'number',
    precision: 22,

  })
  siteLongitude?: number;

  @property({
    type: 'number',
    precision: 22,

  })
  siteLatitude?: number;

  @property({
    type: 'string',
    length: 65535,

  })
  siteTowerHeight?: string;

  @property({
    type: 'string',
    length: 65535,
  })
  siteTypeBaie?: string;

  @property({
    type: 'string',
    length: 65535,

  })
  siteGeotype?: string;

  @property({
    type: 'string',
    length: 65535,

  })
  siteEnergyType?: string;

  @property({
    type: 'string',
    length: 65535,

  })
  opexKey?: string;

  @property({
    type: 'string',
  })
  cellName?: string;

  @property({
    type: 'date',
  })
  date?: string;

  @property({
    type: 'string',
    length: 65535,
  })
  cellTech?: string;

  @property({
    type: 'string',
    length: 65535,
  })
  cellBand?: string;

  @property({
    type: 'number',
    precision: 19,
    scale: 0,
  })
  cellSector?: number;

  @property({
    type: 'number',
    precision: 19,
    scale: 0,
  })
  year?: number;

  @property({
    type: 'number',
    precision: 19,
    scale: 0,
  })
  week?: number;

  @property({
    type: 'number',
    precision: 19,
    scale: 0
  })
  weekPeriod?: number;

  @property({
    type: 'number',
    precision: 22,
  })
  totalDataTrafficDlGb?: number;

  @property({
    type: 'number',
    precision: 22,
  })
  totalVoiceTrafficKerlands?: number;

  @property({
    type: 'number',
    precision: 22,
  })
  averageThroughputUserDlKbps?: number;

  @property({
    type: 'number',
    precision: 22,
  })
  cellOccupationDlPercentage?: number;

  @property({
    type: 'number',
    precision: 22,
  })
  lostTrafficKerland?: number;

  @property({
    type: 'number',
    precision: 22,
  })
  averageNumberOfUsersInQueue?: number;

  // Define well-known properties here

  // Indexer property to allow additional data
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [prop: string]: any;

  constructor(data?: Partial<DfPredictedTrafficKpis>) {
    super(data);
  }
}

export interface DfPredictedTrafficKpisRelations {
  // describe navigational properties here
}

export type DfPredictedTrafficKpisWithRelations = DfPredictedTrafficKpis & DfPredictedTrafficKpisRelations;
