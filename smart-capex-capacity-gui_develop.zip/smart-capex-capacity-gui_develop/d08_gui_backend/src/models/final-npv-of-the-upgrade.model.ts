import {Entity, model, property} from '@loopback/repository';

@model({
  settings: {
    idInjection: false,
    mysql: {schema: 'smartcapex_db', table: 'final_npv_of_the_upgrade'}
  }
})
export class FinalNpvOfTheUpgrade extends Entity {
  @property({
    type: 'number',
    required: true,
    precision: 10,
    scale: 0,
    id: 1,
    mysql: {columnName: 'ID', dataType: 'int', dataLength: null, dataPrecision: 10, dataScale: 0, nullable: 'N'},
  })
  id: number;

  @property({
    type: 'string',
    length: 10,
    mysql: {columnName: 'site_id', dataType: 'varchar', dataLength: 10, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  siteId?: string;

  @property({
    type: 'string',
    length: 10,
    mysql: {columnName: 'cell_band', dataType: 'varchar', dataLength: 10, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  cellBand?: string;

  @property({
    type: 'number',
    precision: 22,
    mysql: {columnName: 'cash_flow_year_0', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  cashFlowYear0?: number;

  @property({
    type: 'number',
    precision: 22,
    mysql: {columnName: 'cash_flow_year_1', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  cashFlowYear1?: number;

  @property({
    type: 'number',
    precision: 22,
    mysql: {columnName: 'cash_flow_year_2', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  cashFlowYear2?: number;

  @property({
    type: 'number',
    precision: 22,
    mysql: {columnName: 'cash_flow_year_3', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  cashFlowYear3?: number;

  @property({
    type: 'number',
    precision: 22,
    mysql: {columnName: 'cash_flow_year_4', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  cashFlowYear4?: number;

  @property({
    type: 'number',
    precision: 22,
    mysql: {columnName: 'cash_flow_year_5', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  cashFlowYear5?: number;

  @property({
    type: 'number',
    precision: 22,
    mysql: {columnName: 'cash_flow_year_6', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  cashFlowYear6?: number;

  @property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'NPV', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  npv?: string;

  @property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'opex_cost_year_0', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })

  opexCostYear0?: string;
  @property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'opex_cost_year_1', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  opexCostYear1?: string;

  @property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'opex_cost_year_2', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  opexCostYear2?: string;

  @property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'opex_cost_year_3', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  opexCostYear3?: string;

  @property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'opex_cost_year_4', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  opexCostYear4?: string;

  @property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'opex_cost_year_5', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  opexCostYear5?: string;

  @property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'opex_cost_year_6', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  opexCostYear6?: string;

  @property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'total_opex', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  totalOpex?: string;

  @property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'total_revenue', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  totalRevenue?: string;

  @property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'EBITDA_Value', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  EBITDAValue?: string;

  @property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'EBITDA', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  EBITDA?: string;

  @property({
    type: 'string',
    length: 100,
    mysql: {columnName: 'IRR', dataType: 'varchar', dataLength: 100, dataPrecision: null, dataScale: null, nullable: 'Y'},
  })
  IRR?: string;

  // Define well-known properties here

  // Indexer property to allow additional data
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [prop: string]: any;

  constructor(data?: Partial<FinalNpvOfTheUpgrade>) {
    super(data);
  }
}

export interface FinalNpvOfTheUpgradeRelations {
  // describe navigational properties here
}

export type FinalNpvOfTheUpgradeWithRelations = FinalNpvOfTheUpgrade & FinalNpvOfTheUpgradeRelations;
