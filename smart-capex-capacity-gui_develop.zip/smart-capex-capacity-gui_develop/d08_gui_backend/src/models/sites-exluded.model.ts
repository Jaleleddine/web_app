import {Entity, model, property} from '@loopback/repository';

@model()
export class SitesExluded extends Entity {

  constructor(data?: Partial<SitesExluded>) {
    super(data);
  }


  @property({
    type: 'string',
    id: true,
  })
  siteId?: string;

  @property({
    type: 'string',
  })
  sitePhysique?: string;

  @property({
    type: 'string',

  })
  siteStatus?: string;

  @property({
    type: 'string',

  })
  siteVille?: string;

  @property({
    type: 'string',

  })
  siteGestionnaire?: string;

  @property({
    type: 'string',

  })
  siteQuartier?: string;

  @property({
    type: 'string',

  })
  siteCommune?: string;

  @property({
    type: 'string',

  })
  siteDepartment?: string;

  @property({
    type: 'string',

  })
  siteRegion?: string;

  @property({
    type: 'string',

  })
  siteDistrict?: string;

  @property({
    type: 'string',

  })
  siteZoneCommerciale?: string;

  @property({
    type: 'number',
    precision: 22
  })
  siteLongitude?: number;

  @property({
    type: 'number',
    precision: 22,
  })
  siteLatitude?: number;

  @property({
    type: 'string',

  })
  siteTowerHeight?: string;

  @property({
    type: 'string',

  })
  siteTypeBaie?: string;

  @property({
    type: 'string',

  })
  siteGeotype?: string;

  @property({
    type: 'string',

  })
  siteEnergyType?: string;

  @property({
    type: 'string',
  })
  opexKey?: string;

}



export interface SitesExludedRelations {
  // describe navigational properties here
}

export type SitesExludedWithRelations = SitesExluded & SitesExludedRelations;
