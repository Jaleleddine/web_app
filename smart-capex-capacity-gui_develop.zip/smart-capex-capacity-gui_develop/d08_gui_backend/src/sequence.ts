/*import {MiddlewareSequence} from '@loopback/rest';
export class MySequence implements SequenceHandler

export class MySequence extends MiddlewareSequence {}*/
import {
  AuthenticateFn,
  AuthenticationBindings, AUTHENTICATION_STRATEGY_NOT_FOUND,
  USER_PROFILE_NOT_FOUND
} from '@loopback/authentication';
import {inject} from '@loopback/context';
import {
  ExpressRequestHandler,
  FindRoute,
  InvokeMethod,
  InvokeMiddleware,
  ParseParams,
  Reject,
  RequestContext,
  RestBindings,
  Send,
  SequenceHandler
} from '@loopback/rest';
import helmet from 'helmet'; // For security
const cors = require('cors');
const timeout = require('express-timeout-handler');
//const xXssProtection = require("x-xss-protection");

const SequenceActions = RestBindings.SequenceActions;
// eslint-disable-next-line @typescript-eslint/no-unused-vars
const middlewareList: ExpressRequestHandler[] = [
  helmet({
    contentSecurityPolicy: {
      useDefaults: false,
      directives: {
        "default-src": 'self',
        "script-src": 'self',
        "style-src": null,
        "object-src": 'none',
        "script-src-elem": 'self',
      },
    },
    dnsPrefetchControl: true,
    expectCt: true,
    frameguard: true,
    hidePoweredBy: true,
    hsts: {
      maxAge: 31536000,
      includeSubDomains: true,
    },
    ieNoOpen: true,
    noSniff: true,
    permittedCrossDomainPolicies: true,
    referrerPolicy: true,
    xssFilter: false,
  }), // options for helmet is fixed and cannot be changed at runtime
  cors({
    origin: ['https://smartcapex.gtm.ocitnetad.ci', 'https://apismartcapex.gtm.ocitnetad.ci', 'http://10.238.36.23', 'http://10.238.36.24', 'http://127.0.0.1:4200', 'http://localhost:4200', 'https://10.238.36.24', 'http://10.240.32.55', 'https://10.240.32.55:8443', 'http://smartcapex', 'https://smartcapex:8443', 'https://192.168.55.17'],
    methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
    preflightContinue: false,
    optionsSuccessStatus: 204,
    maxAge: 86400,
    credentials: true,
  }),
  timeout.handler({timeout: 600000})
];

export class MySequence implements SequenceHandler {
  /**
   * Optional invoker for registered middleware in a chain.
   * To be injected via SequenceActions.INVOKE_MIDDLEWARE.
   */
  @inject(SequenceActions.INVOKE_MIDDLEWARE, {optional: true})
  protected invokeMiddleware: InvokeMiddleware = () => false;

  constructor(
    @inject(SequenceActions.FIND_ROUTE) protected findRoute: FindRoute,
    @inject(SequenceActions.PARSE_PARAMS) protected parseParams: ParseParams,
    @inject(SequenceActions.INVOKE_METHOD) protected invoke: InvokeMethod,
    @inject(SequenceActions.SEND) public send: Send,
    @inject(SequenceActions.REJECT) public reject: Reject,
    @inject(AuthenticationBindings.AUTH_ACTION)
    protected authenticateRequest: AuthenticateFn,
  ) { }

  async handle(context: RequestContext) {
    try {
      const {request, response} = context;
      //const finished = await this.invokeMiddleware(context);
      // `this.invokeMiddleware` is an injected function to invoke a list of
      // Express middleware handler functions
      const finished = await this.invokeMiddleware(context, middlewareList);
      /*response.setHeader("X-XSS-Protection", "1; mode=block");
      request.setTimeout(600000, () => {console.log('server timeout')})*/
      //response.header('Access-Control-Allow-Origin', '*');
      //response.header('Access-Control-Allow-Headers', 'Origin, Content-Type, Accept');
      if (finished) return;
      const route = this.findRoute(request);
      //call authentication action
      await this.authenticateRequest(request);
      const args = await this.parseParams(request, route);
      const result = await this.invoke(route, args);
      this.send(response, result);
    } catch (err) {
      if (
        err.code === AUTHENTICATION_STRATEGY_NOT_FOUND ||
        err.code === USER_PROFILE_NOT_FOUND
      ) {
        Object.assign(err, {statusCode: 401 /* Unauthorized */});
      }

      this.reject(context, err);
      return;
    }
  }
}
