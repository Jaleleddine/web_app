import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {MysqldbDataSource} from '../datasources';
import {Opex, OpexRelations} from '../models';

export class OpexRepository extends DefaultCrudRepository<
  Opex,
  typeof Opex.prototype.identifiant,
  OpexRelations
  > {
  constructor(
    @inject('datasources.mysqldb') dataSource: MysqldbDataSource,
  ) {
    super(Opex, dataSource);
  }
}
