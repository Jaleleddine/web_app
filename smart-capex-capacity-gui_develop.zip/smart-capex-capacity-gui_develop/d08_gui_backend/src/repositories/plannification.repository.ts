import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {MysqldbDataSource} from '../datasources';
import {Plannification, PlannificationRelations} from '../models';

export class PlannificationRepository extends DefaultCrudRepository<
  Plannification,
  typeof Plannification.prototype.id,
  PlannificationRelations
  > {
  constructor(
    @inject('datasources.mysqldb') dataSource: MysqldbDataSource,
  ) {
    super(Plannification, dataSource);
  }
}
