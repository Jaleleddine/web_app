import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {MysqldbDataSource} from '../datasources';
import {Sites, SitesRelations} from '../models';

export class SitesRepository extends DefaultCrudRepository<
  Sites,
  typeof Sites.prototype.siteId,
  SitesRelations
> {
  constructor(
    @inject('datasources.mysqldb') dataSource: MysqldbDataSource,
  ) {
    super(Sites, dataSource);
  }
}
