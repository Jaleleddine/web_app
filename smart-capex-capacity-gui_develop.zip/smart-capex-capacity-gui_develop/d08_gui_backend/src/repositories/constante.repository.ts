import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {MysqldbDataSource} from '../datasources';
import {Constante, ConstanteRelations} from '../models';

export class ConstanteRepository extends DefaultCrudRepository<
  Constante,
  typeof Constante.prototype.identifiant,
  ConstanteRelations
> {
  constructor(
    @inject('datasources.mysqldb') dataSource: MysqldbDataSource,
  ) {
    super(Constante, dataSource);
  }
}
