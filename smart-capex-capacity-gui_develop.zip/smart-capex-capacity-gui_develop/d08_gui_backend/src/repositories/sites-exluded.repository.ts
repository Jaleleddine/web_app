import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {MysqldbDataSource} from '../datasources';
import {SitesExluded, SitesExludedRelations} from '../models';

export class SitesExludedRepository extends DefaultCrudRepository<
  SitesExluded,
  typeof SitesExluded.prototype.siteId,
  SitesExludedRelations
> {
  constructor(
    @inject('datasources.mysqldb') dataSource: MysqldbDataSource,
  ) {
    super(SitesExluded, dataSource);
  }
}
