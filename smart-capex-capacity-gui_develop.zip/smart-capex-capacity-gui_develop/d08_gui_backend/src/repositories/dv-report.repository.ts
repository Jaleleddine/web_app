import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {MysqldbDataSource} from '../datasources';
import {DvReport, DvReportRelations} from '../models';

export class DvReportRepository extends DefaultCrudRepository<
  DvReport,
  typeof DvReport.prototype.id,
  DvReportRelations
> {
  constructor(
    @inject('datasources.mysqldb') dataSource: MysqldbDataSource,
  ) {
    super(DvReport, dataSource);
  }
}
