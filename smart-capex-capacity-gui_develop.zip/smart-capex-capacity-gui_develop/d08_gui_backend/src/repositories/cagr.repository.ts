import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {MysqldbDataSource} from '../datasources';
import {Cagr, CagrRelations} from '../models';

export class CagrRepository extends DefaultCrudRepository<
  Cagr,
  typeof Cagr.prototype.identifiant,
  CagrRelations
> {
  constructor(
    @inject('datasources.mysqldb') dataSource: MysqldbDataSource,
  ) {
    super(Cagr, dataSource);
  }
}
