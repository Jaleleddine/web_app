import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {MysqldbDataSource} from '../datasources';
import {EscoOpex, EscoOpexRelations} from '../models';

export class EscoOpexRepository extends DefaultCrudRepository<
  EscoOpex,
  typeof EscoOpex.prototype.band,
  EscoOpexRelations
> {
  constructor(
    @inject('datasources.mysqldb') dataSource: MysqldbDataSource,
  ) {
    super(EscoOpex, dataSource);
  }
}
