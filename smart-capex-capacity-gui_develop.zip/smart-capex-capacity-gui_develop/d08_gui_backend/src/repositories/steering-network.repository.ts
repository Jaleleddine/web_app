import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {MysqldbDataSource} from '../datasources';
import {SteeringNetwork, SteeringNetworkRelations} from '../models';

export class SteeringNetworkRepository extends DefaultCrudRepository<
  SteeringNetwork,
  typeof SteeringNetwork.prototype.identifiant,
  SteeringNetworkRelations
> {
  constructor(
    @inject('datasources.mysqldb') dataSource: MysqldbDataSource,
  ) {
    super(SteeringNetwork, dataSource);
  }
}
