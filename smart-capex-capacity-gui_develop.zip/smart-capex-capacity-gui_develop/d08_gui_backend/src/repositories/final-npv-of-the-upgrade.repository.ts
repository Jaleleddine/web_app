import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {MysqldbDataSource} from '../datasources';
import {FinalNpvOfTheUpgrade, FinalNpvOfTheUpgradeRelations} from '../models/final-npv-of-the-upgrade.model';

export class FinalNpvOfTheUpgradeRepository extends DefaultCrudRepository<
  FinalNpvOfTheUpgrade,
  typeof FinalNpvOfTheUpgrade.prototype.id,
  FinalNpvOfTheUpgradeRelations
  > {
  constructor(
    @inject('datasources.mysqldb') dataSource: MysqldbDataSource,
  ) {
    super(FinalNpvOfTheUpgrade, dataSource);
  }
}
