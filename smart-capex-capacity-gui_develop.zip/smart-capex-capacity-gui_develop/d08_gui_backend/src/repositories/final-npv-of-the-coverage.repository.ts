import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {MysqldbDataSource} from '../datasources';
import {FinalNpvOfTheCoverage, FinalNpvOfTheCoverageRelations} from '../models';

export class FinalNpvOfTheCoverageRepository extends DefaultCrudRepository<
  FinalNpvOfTheCoverage,
  typeof FinalNpvOfTheCoverage.prototype.id,
  FinalNpvOfTheCoverageRelations
> {
  constructor(
    @inject('datasources.mysqldb') dataSource: MysqldbDataSource,
  ) {
    super(FinalNpvOfTheCoverage, dataSource);
  }
}
