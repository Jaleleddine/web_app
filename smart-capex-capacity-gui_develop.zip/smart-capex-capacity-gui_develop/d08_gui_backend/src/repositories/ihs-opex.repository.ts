import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {MysqldbDataSource} from '../datasources';
import {IhsOpex, IhsOpexRelations} from '../models';

export class IhsOpexRepository extends DefaultCrudRepository<
  IhsOpex,
  typeof IhsOpex.prototype.band,
  IhsOpexRelations
> {
  constructor(
    @inject('datasources.mysqldb') dataSource: MysqldbDataSource,
  ) {
    super(IhsOpex, dataSource);
  }
}
