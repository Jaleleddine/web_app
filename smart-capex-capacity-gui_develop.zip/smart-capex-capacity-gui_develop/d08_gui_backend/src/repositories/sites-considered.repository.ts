import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {MysqldbDataSource} from '../datasources';
import {SitesConsidered, SitesConsideredRelations} from '../models';

export class SitesConsideredRepository extends DefaultCrudRepository<
  SitesConsidered,
  typeof SitesConsidered.prototype.siteId,
  SitesConsideredRelations
> {
  constructor(
    @inject('datasources.mysqldb') dataSource: MysqldbDataSource,
  ) {
    super(SitesConsidered, dataSource);
  }
}
