import {inject} from '@loopback/core';
import {DefaultCrudRepository} from '@loopback/repository';
import {MysqldbDataSource} from '../datasources';
import {ClientMargin, ClientMarginRelations} from '../models';

export class ClientMarginRepository extends DefaultCrudRepository<
  ClientMargin,
  typeof ClientMargin.prototype.identifiant,
  ClientMarginRelations
> {
  constructor(
    @inject('datasources.mysqldb') dataSource: MysqldbDataSource,
  ) {
    super(ClientMargin, dataSource);
  }
}
