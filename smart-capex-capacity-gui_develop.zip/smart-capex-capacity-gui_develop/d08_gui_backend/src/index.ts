/* eslint-disable @typescript-eslint/no-unused-vars */
import * as dotenv from 'dotenv';
import {ApplicationConfig, LbAppApplication} from './application';
export * from './application';
const fs = require('fs');
const path = require('path');
const dir = path.join(__dirname, '../');

export async function main(options: ApplicationConfig = {}) {
  dotenv.config({path: dir + '.env'});
  const app = new LbAppApplication(options);
  await app.boot();
  await app.start();

  const url = app.restServer.url;
  console.log(`Server is running at ${url}`);
  console.log(`Try ${url}/ping`);

  return app;
}

if (require.main === module) {
  // Run the application
  const config = {
    rest: {
      /*expressSettings: {
        'x-powered-by': false,
      },*/
      port: +(process.env.PORT ?? 3000),
      host: process.env.HOST,
      // The `gracePeriodForClose` provides a graceful close for http/https
      // servers with keep-alive clients. The default value is `Infinity`
      // (don't force-close). If you want to immediately destroy all sockets
      // upon stop, set its value to `0`.
      // See https://www.npmjs.com/package/stoppable
      gracePeriodForClose: 5000, // 5 seconds
      openApiSpec: {
        // useful when used with OpenAPI-to-GraphQL to locate your application
        setServersFromRequest: true,
      },
      requestBodyParser: {
        json: {limit: '20mb'},
        text: {limit: '5MB'},
      },

      // Enable HTTPS
      /*protocol: 'https',
      key: fs.readFileSync("/etc/pki/tls/certs/OK-SMARTCAPEXBE-ST01.key"),
      cert: fs.readFileSync("/etc/pki/tls/certs/OK-SMARTCAPEXBE-ST01.cer")*/
    },

  };
  main(config).catch(err => {
    console.error('Cannot start the application.', err);
    process.exit(1);
  });
}
