import {authenticate} from '@loopback/authentication';
import {authorize} from '@loopback/authorization';
import {inject} from '@loopback/core';
import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where
} from '@loopback/repository';
import {
  del, get,
  getModelSchemaRef, param,
  patch, post,
  put,
  requestBody,
  response,
  Response,
  RestBindings
} from '@loopback/rest';
import {basicAuthorization} from '../middlewares/auth.midd';
import {SteeringNetwork} from '../models';
import {SteeringNetworkRepository} from '../repositories';


export class SteeringNetworkController {
  constructor(
    @repository(SteeringNetworkRepository)
    public steeringNetworkRepository: SteeringNetworkRepository,
    @inject(RestBindings.Http.RESPONSE)
    private respo: Response,
  ) { }

  @post('/steering-networks')
  @response(200, {
    description: 'SteeringNetwork model instance',
    content: {'application/json': {schema: getModelSchemaRef(SteeringNetwork)}},
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'strategy'],
    voters: [basicAuthorization],
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'array',
            items: getModelSchemaRef(SteeringNetwork, {includeRelations: true}),
          },
        },
      },
    })
    steeringNetworks: SteeringNetwork[],
  ): Promise<SteeringNetwork[]> {
    // admin,editor, validator,modeling,strategy,ser  ==> sms
    // Delete all data before saving news
    await this.steeringNetworkRepository.execute(`TRUNCATE SteeringNetwork;`);
    // check if data ids are corrects
    const ids = ['DATA2G', 'DATA3G', 'DATA4G', 'DATA5G', 'VOICE2G', 'VOICE3G', 'VOICE4G', 'VOICE5G']
    steeringNetworks.forEach(item => {
      if (!ids.includes(item.identifiant)) {
        return this.respo.status(400).send({
          message: `Identifiant ${item.identifiant} incorrect`,
          status: 400,
        });
      }
    })
    return this.steeringNetworkRepository.createAll(steeringNetworks);
  }

  @get('/steering-networks/count')
  @response(200, {
    description: 'SteeringNetwork model count',
    content: {'application/json': {schema: CountSchema}},
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'editor', 'viewer', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async count(
    @param.where(SteeringNetwork) where?: Where<SteeringNetwork>,
  ): Promise<Count> {
    return this.steeringNetworkRepository.count(where);
  }

  @get('/steering-networks')
  @response(200, {
    description: 'Array of SteeringNetwork model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(SteeringNetwork, {includeRelations: true}),
        },
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'editor', 'viewer', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async find(
    @param.filter(SteeringNetwork) filter?: Filter<SteeringNetwork>,
  ): Promise<SteeringNetwork[]> {
    return this.steeringNetworkRepository.find(filter);
  }

  @get('/steering-networks/{id}')
  @response(200, {
    description: 'SteeringNetwork model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(SteeringNetwork, {includeRelations: true}),
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'editor', 'viewer', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async findById(
    @param.path.string('id') id: string,
    @param.filter(SteeringNetwork, {exclude: 'where'}) filter?: FilterExcludingWhere<SteeringNetwork>
  ): Promise<SteeringNetwork> {
    return this.steeringNetworkRepository.findById(id, filter);
  }

  @patch('/steering-networks/{id}')
  @response(204, {
    description: 'SteeringNetwork PATCH success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'strategy'],
    voters: [basicAuthorization],
  })
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(SteeringNetwork, {partial: true}),
        },
      },
    })
    steeringNetwork: SteeringNetwork,
  ): Promise<void> {
    await this.steeringNetworkRepository.updateById(id, steeringNetwork);
  }

  @put('/steering-networks/{id}')
  @response(204, {
    description: 'SteeringNetwork PUT success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'strategy'],
    voters: [basicAuthorization],
  })
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() steeringNetwork: SteeringNetwork,
  ): Promise<void> {
    await this.steeringNetworkRepository.replaceById(id, steeringNetwork);
  }

  @del('/steering-networks/{id}')
  @response(204, {
    description: 'SteeringNetwork DELETE success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'strategy'],
    voters: [basicAuthorization],
  })
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.steeringNetworkRepository.deleteById(id);
  }
}
