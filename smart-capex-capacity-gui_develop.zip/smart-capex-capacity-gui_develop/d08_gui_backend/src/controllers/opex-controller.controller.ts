/* eslint-disable @typescript-eslint/no-explicit-any */
import {authenticate} from '@loopback/authentication';
import {authorize} from '@loopback/authorization';
import {inject} from '@loopback/core';
import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where
} from '@loopback/repository';
import {
  del, get,
  getModelSchemaRef, param,
  patch, post,
  put,
  requestBody,
  response,
  Response,
  RestBindings
} from '@loopback/rest';
import * as config from '../config.json';
import {basicAuthorization} from '../middlewares/auth.midd';
import {Opex} from '../models';
import {OpexRepository, UserRepository} from '../repositories';
import {sendSMS} from '../services/send-sms.service';
const axios = require('axios');

export class OpexControllerController {
  constructor(
    @repository(OpexRepository)
    public opexRepository: OpexRepository,
    @repository(UserRepository)
    public userRepository: UserRepository,
    @inject(RestBindings.Http.RESPONSE)
    private respo: Response,
  ) { }

  @get('/opexes/count')
  @response(200, {
    description: 'Opex model count',
    content: {'application/json': {schema: CountSchema}},
  })
  async count(
    @param.where(Opex) where?: Where<Opex>,
  ): Promise<Count> {
    return this.opexRepository.count(where);
  }

  @post('/opexes')
  @response(200, {
    description: 'Opex model instance',
    type: 'array',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Opex),
        },
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'finance'],
    voters: [basicAuthorization],
  })
  async createAll(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'array',
            items: getModelSchemaRef(Opex, {includeRelations: true}),
          },
        },
      },
    })
    opex: Opex[],
  ): Promise<unknown> {
    // SMS 'finance', 'ser', 'strategy'
    // Save many item to the data base
    await this.opexRepository.execute('TRUNCATE Opex;');
    const user = opex[0].modifiedBy;
    // check if data ids are corrects
    const ids = ['IHS_U900', 'IHS_U2100', 'IHS_L800', 'IHS_L1800', 'IHS_L2300', 'IHS_L2600', 'ESCO_U900', 'ESCO_U2100', 'ESCO_L800', 'ESCO_L1800', 'ESCO_L2300', 'ESCO_L2600'];
    opex.forEach(item => {
      if (!ids.includes(item.identifiant)) {
        return this.respo.status(400).send({
          message: `Identifiant OPEX ${item.identifiant} incorrect`,
          status: 400,
        });
      }
    })

    // Get config from analytic server and save new with CAGRS parameters
    try {
      const result: any = await axios.get(config.config_host + '/getConfig ');
      const configs = result.data
      //console.log(configs)
      configs["OPEX"] = opex;

      // Update config parameters in analytic server
      await axios.post(config.config_host + '/setConfigs', configs)
      // Save config in DB
      const dbconfigs = await this.opexRepository.createAll(opex)

      // Send sms to all smartcapex users
      const users = await this.userRepository.find();
      const smsContent = `${user}, vient de mettre à jour les paramètres OPEX.`
      if (users.length > 0) {
        users.forEach(item => {
          //console.log('send sms');
          sendSMS(item.phoneNumber, smsContent)
        })
      }

      // return config saved in DB
      return dbconfigs;

    } catch (error) {
      console.error(error);
      return this.respo.status(400).send({
        message: `La mise à jour des OPEX a échoué, merci de réessayer!`,
        status: 400,
      });
    }

  }

  @get('/opexes')
  @response(200, {
    description: 'Array of Opex model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Opex, {includeRelations: true}),
        },
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'finance'],
    voters: [basicAuthorization],
  })
  async find(
    @param.filter(Opex) filter?: Filter<Opex>,
  ): Promise<Opex[]> {
    return this.opexRepository.find(filter);
  }

  @patch('/opexes')
  @response(200, {
    description: 'Opex PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'finance'],
    voters: [basicAuthorization],
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Opex, {partial: true}),
        },
      },
    })
    opex: Opex,
    @param.where(Opex) where?: Where<Opex>,
  ): Promise<Count> {
    return this.opexRepository.updateAll(opex, where);
  }


  // Get Configs from Analytic server
  @get('/getconfigs')
  @response(200, {
    description: 'Configs from Analytic server',
    content: {
      'application/json': {
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async getConfigs(
  ): Promise<unknown> {
    const result: any = await axios.get(config.config_host + '/getConfig');
    const configs = result.data;
    //console.log(configs)
    return this.respo.status(200).send(configs);
  }

  @get('/opexes/{id}')
  @response(200, {
    description: 'Opex model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(Opex, {includeRelations: true}),
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'finance'],
    voters: [basicAuthorization],
  })
  async findById(
    @param.path.string('id') id: string,
    @param.filter(Opex, {exclude: 'where'}) filter?: FilterExcludingWhere<Opex>
  ): Promise<Opex> {
    return this.opexRepository.findById(id, filter);
  }

  @patch('/opexes/{id}')
  @response(204, {
    description: 'Opex PATCH success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'finance'],
    voters: [basicAuthorization],
  })
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Opex, {partial: true}),
        },
      },
    })
    opex: Opex,
  ): Promise<void> {
    await this.opexRepository.updateById(id, opex);
  }

  @put('/opexes/{id}')
  @response(204, {
    description: 'Opex PUT success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'finance'],
    voters: [basicAuthorization],
  })
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() opex: Opex,
  ): Promise<void> {
    await this.opexRepository.replaceById(id, opex);
  }

  @del('/opexes/{id}')
  @response(204, {
    description: 'Opex DELETE success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'finance'],
    voters: [basicAuthorization],
  })
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.opexRepository.deleteById(id);
  }
}
