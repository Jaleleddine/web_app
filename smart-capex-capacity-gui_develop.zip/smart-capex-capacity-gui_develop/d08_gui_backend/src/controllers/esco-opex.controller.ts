import {authenticate} from '@loopback/authentication';
import {authorize} from '@loopback/authorization';
import {inject} from '@loopback/core';
import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where
} from '@loopback/repository';
import {
  del, get,
  getModelSchemaRef, param,
  patch, post,
  put,
  requestBody,
  response,
  Response,
  RestBindings
} from '@loopback/rest';
import {basicAuthorization} from '../middlewares/auth.midd';
import {EscoOpex} from '../models';
import {EscoOpexRepository} from '../repositories';

export class EscoOpexController {
  constructor(
    @repository(EscoOpexRepository)
    public escoOpexRepository: EscoOpexRepository,
    @inject(RestBindings.Http.RESPONSE)
    private respo: Response,
  ) { }

  @post('/esco-opexes')
  @response(200, {
    description: 'EscoOpex model instance',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(EscoOpex),
        }
      }
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'finance'],
    voters: [basicAuthorization],
  })
  async createAll(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'array',
            items: getModelSchemaRef(EscoOpex, {includeRelations: true}),
          }
        }
      },
    })
    escoOpex: EscoOpex[],
  ): Promise<EscoOpex[]> {
    // SMS finance, ser,strategy
    await this.escoOpexRepository.execute('TRUNCATE EscoOpex;');
    // check if data ids are corrects
    const ids = ['U900', 'U2100', 'L800', 'L1800', 'L2600'];
    escoOpex.forEach(item => {
      if (!ids.includes(item.band)) {
        return this.respo.status(400).send({
          message: `Band ${item.band} incorrect`,
          status: 400,
        });
      }
    })
    return this.escoOpexRepository.createAll(escoOpex)
  }

  @get('/esco-opexes/count')
  @response(200, {
    description: 'EscoOpex model count',
    content: {'application/json': {schema: CountSchema}},
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async count(
    @param.where(EscoOpex) where?: Where<EscoOpex>,
  ): Promise<Count> {
    return this.escoOpexRepository.count(where);
  }

  @get('/esco-opexes')
  @response(200, {
    description: 'Array of EscoOpex model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(EscoOpex, {includeRelations: true}),
        },
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async find(
    @param.filter(EscoOpex) filter?: Filter<EscoOpex>,
  ): Promise<EscoOpex[]> {
    return this.escoOpexRepository.find(filter);
  }

  @get('/esco-opexes/{id}')
  @response(200, {
    description: 'EscoOpex model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(EscoOpex, {includeRelations: true}),
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async findById(
    @param.path.string('id') id: string,
    @param.filter(EscoOpex, {exclude: 'where'}) filter?: FilterExcludingWhere<EscoOpex>
  ): Promise<EscoOpex> {
    return this.escoOpexRepository.findById(id, filter);
  }

  @patch('/esco-opexes/{id}')
  @response(204, {
    description: 'EscoOpex PATCH success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'finance'],
    voters: [basicAuthorization],
  })
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(EscoOpex, {partial: true}),
        },
      },
    })
    escoOpex: EscoOpex,
  ): Promise<void> {
    await this.escoOpexRepository.updateById(id, escoOpex);
  }

  @put('/esco-opexes/{id}')
  @response(204, {
    description: 'EscoOpex PUT success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'finance'],
    voters: [basicAuthorization],
  })
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() escoOpex: EscoOpex,
  ): Promise<void> {
    await this.escoOpexRepository.replaceById(id, escoOpex);
  }

  @del('/esco-opexes/{id}')
  @response(204, {
    description: 'EscoOpex DELETE success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'finance'],
    voters: [basicAuthorization],
  })
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.escoOpexRepository.deleteById(id);
  }
}
