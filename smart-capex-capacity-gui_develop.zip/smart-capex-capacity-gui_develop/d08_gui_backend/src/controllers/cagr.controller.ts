/* eslint-disable @typescript-eslint/no-explicit-any */
import {authenticate} from '@loopback/authentication';
import {authorize} from '@loopback/authorization';
import {inject} from '@loopback/core';
import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where
} from '@loopback/repository';
import {
  del, get,
  getModelSchemaRef, param,
  patch, post,
  put,
  requestBody,
  response,
  Response,
  RestBindings
} from '@loopback/rest';
import * as config from '../config.json';
import {basicAuthorization} from '../middlewares/auth.midd';
import {Cagr} from '../models';
import {CagrRepository, UserRepository} from '../repositories';
import {sendSMS} from '../services/send-sms.service';
const axios = require('axios');
//const _ = require('lodash');

export class CagrController {
  constructor(
    @repository(CagrRepository)
    public cagrRepository: CagrRepository,
    @repository(UserRepository)
    public userRepository: UserRepository,
    @inject(RestBindings.Http.RESPONSE)
    private respo: Response,
  ) { }

  @post('/cagrs')
  @response(200, {
    description: 'Cagr model instance',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Cagr),
        },
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy'],
    voters: [basicAuthorization],
  })
  async createAll(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'array',
            items: getModelSchemaRef(Cagr, {includeRelations: true}),
          },
        },
      },
    })
    cagrs: Cagr[],
  ): Promise<unknown> {
    // Save many item to the data base
    await this.cagrRepository.execute('TRUNCATE Cagr;');
    // check if data ids are corrects
    const ids = ['ANNUAL_DECREASE_UNIT_PRICE_DATA_PERCENTAGE', 'ANNUAL_DECREASE_UNIT_PRICE_VOICE_PERCENTAGE', 'PERCENTAGE_DISTRIBUTION_REVENUES', 'PERCENTAGE_DISTRIBUTION_REVENUES',
      'PERCENTAGE_ITERCO', 'PERCENTAGE_OPEX_INCREMENT', 'UNIT_PRICE_DATA_GB', 'UNIT_PRICE_VOICE_MIN'];

    // config parameters
    const CAGRS: any = {};
    const user = cagrs[0].modifiedBy;
    cagrs.forEach(item => {
      CAGRS[item.identifiant] = item.valeur
      if (!ids.includes(item.identifiant)) {
        return this.respo.status(400).send({
          message: `Identifiant ${item.identifiant} incorrect`,
          status: 400,
        });
      }
    })

    // Get config from analytic server and save new with CAGRS parameters
    try {
      //console.log(CAGRS)
      //console.log(config.config_host)
      const result: any = await axios.get(config.config_host + '/getConfig ');
      const configs = result.data
      //console.log(configs)
      configs["MARGIN_COMPUTATION"] = CAGRS;

      // Update config parameters in analytic server
      await axios.post(config.config_host + '/setConfigs', configs)
      // Save config in DB
      const dbconfigs = await this.cagrRepository.createAll(cagrs)

      // Send sms to all smartcapex users
      const users = await this.userRepository.find();
      const smsContent = `${user}, vient de mettre à jour les paramètres CAGRS.`
      if (users.length > 0) {
        users.forEach(item => {
          //console.log('send sms');
          sendSMS(item.phoneNumber, smsContent)
        })
      }

      // return config saved in DB
      return dbconfigs;

    } catch (error) {
      console.error(error);
      return this.respo.status(400).send({
        message: `La mise à jour des CAGRS a échoué, merci de réessayer!`,
        status: 400,
      });
    }

  }

  @get('/cagrs/count')
  @response(200, {
    description: 'Cagr model count',
    content: {'application/json': {schema: CountSchema}},
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy'],
    voters: [basicAuthorization],
  })
  async count(
    @param.where(Cagr) where?: Where<Cagr>,
  ): Promise<Count> {
    return this.cagrRepository.count(where);
  }

  @get('/cagrs')
  @response(200, {
    description: 'Array of Cagr model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Cagr, {includeRelations: true}),
        },
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy'],
    voters: [basicAuthorization],
  })
  async find(
    @param.filter(Cagr) filter?: Filter<Cagr>,
  ): Promise<Cagr[]> {
    return this.cagrRepository.find(filter);
  }

  @get('/cagrs/{id}')
  @response(200, {
    description: 'Cagr model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(Cagr, {includeRelations: true}),
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy'],
    voters: [basicAuthorization],
  })
  async findById(
    @param.path.string('id') id: string,
    @param.filter(Cagr, {exclude: 'where'}) filter?: FilterExcludingWhere<Cagr>
  ): Promise<Cagr> {
    return this.cagrRepository.findById(id, filter);
  }

  @patch('/cagrs/{id}')
  @response(204, {
    description: 'Cagr PATCH success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy'],
    voters: [basicAuthorization],
  })
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Cagr, {partial: true}),
        },
      },
    })
    cagr: Cagr,
  ): Promise<void> {
    await this.cagrRepository.updateById(id, cagr);
  }

  @put('/cagrs/{id}')
  @response(204, {
    description: 'Cagr PUT success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy'],
    voters: [basicAuthorization],
  })
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() cagr: Cagr,
  ): Promise<void> {
    await this.cagrRepository.replaceById(id, cagr);
  }

  @del('/cagrs/{id}')
  @response(204, {
    description: 'Cagr DELETE success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy'],
    voters: [basicAuthorization],
  })
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.cagrRepository.deleteById(id);
  }
}
