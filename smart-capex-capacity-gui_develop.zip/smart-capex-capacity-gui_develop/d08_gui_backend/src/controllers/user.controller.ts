import {authenticate, TokenService, UserService} from '@loopback/authentication';
import {authorize} from '@loopback/authorization';
import {inject} from '@loopback/core';
import {
  Filter, model, property, repository
} from '@loopback/repository';
import {
  del, get, getModelSchemaRef,
  param, patch, post, Request, requestBody, response, Response, RestBindings
} from '@loopback/rest';
import {SecurityBindings, securityId, UserProfile} from '@loopback/security';
import {PasswordHasherBindings, TokenServiceBindings, UserServiceBindings} from '../keys';
import {basicAuthorization} from '../middlewares/auth.midd';
import {LoginModel, User} from '../models';
import {UserRepository} from '../repositories';
import {PasswordHasher} from '../services';
import {UserProfileSchema} from './specs/user-controller.specs';

// Librairies
const moment = require('moment');
const ActiveDirectory = require('activedirectory');
//const tls = require('tls');
// eslint-disable-next-line @typescript-eslint/no-unused-vars
const fs = require('fs');
// const {authenticate} = require('ldap-authentication');
/*const events = require('events');
//create an object of EventEmitter class by using above reference
const em = new events.EventEmitter();
const isAuth = false;*/

@model()
export class NewUserRequest extends User {
  @property({
    type: 'string',
    required: true,
  })
  password: string;
}

export class UserController {
  constructor(
    @repository(UserRepository) public userRepository: UserRepository,
    @inject(PasswordHasherBindings.PASSWORD_HASHER)
    public passwordHasher: PasswordHasher,
    @inject(TokenServiceBindings.TOKEN_SERVICE)
    public jwtService: TokenService,
    @inject(UserServiceBindings.USER_SERVICE)
    public userService: UserService<User, LoginModel>,
    @inject(RestBindings.Http.RESPONSE) private respo: Response,
    @inject(RestBindings.Http.REQUEST) private request: Request
  ) {
  }

  @post('/users')
  @response(201, {
    description: 'User model instance',
    content: {'application/json': {schema: getModelSchemaRef(User)}},
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator'],
    voters: [basicAuthorization],
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(User, {
            title: 'NewUser',
            exclude: ['id'],
          }),
        },
      },
    })
    user: Omit<User, 'id'>
  ): Promise<User> {
    user.createdAt = new Date();
    const savedUser = await this.userRepository.create(user);
    return savedUser;
  }

  @get('/users')
  @response(200, {
    description: 'Array of User model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(User, {includeRelations: true}),
        },
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator'],
    voters: [basicAuthorization],
  })
  async find(
    @param.filter(User) filter?: Filter<User>,
  ): Promise<User[]> {
    return this.userRepository.find(filter);
  }


  @get('/users/{id}', {
    responses: {
      '200': {
        description: 'User',
        content: {
          'application/json': {
            schema: {
              'x-ts-type': User,
            },
          },
        },
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator'],
    voters: [basicAuthorization],
  })
  async findById(@param.path.number('id') id: string): Promise<User> {
    return this.userRepository.findById(id);
  }

  @get('/users/me', {
    responses: {
      '200': {
        description: 'The current user profile',
        content: {
          'application/json': {
            schema: UserProfileSchema,
          },
        },
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'editor', 'viewer', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async printCurrentUser(
    @inject(SecurityBindings.USER)
    currentUserProfile: UserProfile,
  ): Promise<User> {
    const userId = currentUserProfile[securityId];
    return this.userRepository.findById(userId);
  }

  @get('/users/refresh', {
    responses: {
      '200': {
        description: 'Refresh user infos in Dev Environnment',
        content: {
          'application/json': {
            schema: UserProfileSchema,
          },
        },
      },
    },
  })
  async refreshUserInfos(
  ): Promise<unknown> {
    const cookies = this.request.headers.cookie ? this.request.headers.cookie.split('; ') : undefined;
    //console.log(cookies)
    if (cookies !== undefined) {
      const tokenArr = cookies.filter(item => item.indexOf('token') !== -1)
      const roleArr = cookies.filter(item => item.indexOf('role') !== -1)

      let token = '';
      let role = '';
      // Get the token of the user
      if (tokenArr.length > 0) {
        token = tokenArr[0].substring(6)
        // console.log(token)
      }
      // Get the role of the user
      if (roleArr.length > 0) {
        role = roleArr[0].substring(5)
        // console.log(role)
      }
      //console.log(token)
      //console.log(role)
      return this.respo.send({token, role})
    } else {
      this.respo.status(404).send({
        message: 'User Infos non trouvées',
        status: 404,
      });
    }
  }

  @post('/users/login', {
    responses: {
      '200': {
        description: 'Token',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                token: {
                  type: 'string',
                },
              },
            },
          },
        },
      },
    },
  })
  async login(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(LoginModel),
        },
      },
    })
    credentials: LoginModel,
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
  ): Promise<any | {userProfile: object}> {
    // ensure the user exists, and the password is correct
    // Login via AD
    const config = {
      url: 'ldaps://192.168.224.76:636',
      secure: true,
      tlsOptions: {
        servername: 'SRVCIRP2AD-02.ocitnetad.ci',
        ca: [fs.readFileSync("/etc/pki/tls/certs/oci_ca_1.cer")],
        key: fs.readFileSync("/etc/pki/tls/certs/OK-SMARTCAPEXBE-ST01.key"),
        cert: fs.readFileSync("/etc/pki/tls/certs/OK-SMARTCAPEXBE-ST01.cer"),
        rejectUnauthorized: false,
      },
      baseDN: 'OU=OR-CI,DC=ocitnetad,DC=ci',
      username: credentials.login + '@ocitnetad.ci',
      password: credentials.password
    }

    // Dev authentification
    /*const config = {
      url: 'ldap://192.168.224.76',
      baseDN: 'OU=OR-CI,DC=ocitnetad,DC=ci',
      username: credentials.login + '@ocitnetad.ci',
      password: credentials.password
    }*/
    const ad = new ActiveDirectory(config);

    const username = credentials.login + '@ocitnetad.ci';
    const password = credentials.password;
    // console.log('Login...');

    const authL = await new Promise((success, failure) => {
      ad.authenticate(username, password, (err: unknown, auth: unknown) => {
        /*console.log(err);
        console.log(auth)*/
        if (auth) {
          success(true);
        }
        else {
          //failure(true);
          success(false);
        }
      });
    })
    // console.log(authL);
    if (!authL) {
      this.respo.status(403).send({
        message: 'Mot de passe ou Login AD incorrect.',
        status: 403,
      });
      return this.respo;
    }
    // Verify if user is in our BD
    const user = await this.userService.verifyCredentials(credentials);
    // convert a User object into a UserProfile object (reduced set of properties)
    const userProfile = this.userService.convertToUserProfile(user);
    // create a JSON Web Token based on the user profile
    const token = await this.jwtService.generateToken(userProfile);
    userProfile.token = token;
    //console.log(userProfile)
    // User token
    this.respo.cookie('token', token, {
      maxAge: 3600000,
      httpOnly: true,
      sameSite: 'none',// None because the frontend app is on another server
      path: '/',
      secure: true
    });
    // User rôle
    this.respo.cookie('role', userProfile.role, {
      maxAge: 3600000,
      httpOnly: true,
      sameSite: 'none',// None because the frontend app is on another server
      path: '/',
      secure: true
    });
    return this.respo.status(200).send(userProfile);
    //return {userProfile};
  }

  @patch('/users/{id}')
  @response(204, {
    description: 'User PATCH success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator'],
    voters: [basicAuthorization],
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(User, {partial: true}),
        },
      },
    })
    user: User,
  ): Promise<void> {
    user.updatedAt = moment().format();
    // console.log(user);
    await this.userRepository.updateById(id, user);
  }

  @del('/users/{id}')
  @response(204, {
    description: 'User DELETE success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator'],
    voters: [basicAuthorization],
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.userRepository.deleteById(id);
  }
}
