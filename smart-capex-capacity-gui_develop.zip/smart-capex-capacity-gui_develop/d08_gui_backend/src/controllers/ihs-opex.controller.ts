import {authenticate} from '@loopback/authentication';
import {authorize} from '@loopback/authorization';
import {inject} from '@loopback/core';
import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where
} from '@loopback/repository';
import {
  del, get,
  getModelSchemaRef, param,
  patch, post,
  put,
  requestBody,
  response,
  Response,
  RestBindings
} from '@loopback/rest';
import {basicAuthorization} from '../middlewares/auth.midd';
import {IhsOpex} from '../models';
import {IhsOpexRepository} from '../repositories';

export class IhsOpexController {
  constructor(
    @repository(IhsOpexRepository)
    public ihsOpexRepository: IhsOpexRepository,
    @inject(RestBindings.Http.RESPONSE)
    private respo: Response,
  ) { }

  @post('/ihs-opexes')
  @response(200, {
    description: 'IhsOpex model instance',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(IhsOpex),
        }
      }
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'finance'],
    voters: [basicAuthorization],
  })
  async createAll(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'array',
            items: getModelSchemaRef(IhsOpex, {includeRelations: true}),
          }
        }
      },
    })
    ihsOpex: IhsOpex[],
  ): Promise<IhsOpex[]> {
    // SMS finance, ser,strategy
    await this.ihsOpexRepository.execute('TRUNCATE IhsOpex;');
    // check if data ids are corrects
    const ids = ['U900', 'U2100', 'L800', 'L1800', 'L2600'];
    ihsOpex.forEach(item => {
      if (!ids.includes(item.band)) {
        return this.respo.status(400).send({
          message: `Band ${item.band} incorrect`,
          status: 400,
        });
      }
    })
    return this.ihsOpexRepository.createAll(ihsOpex)
  }

  @get('/ihs-opexes/count')
  @response(200, {
    description: 'IhsOpex model count',
    content: {'application/json': {schema: CountSchema}},
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async count(
    @param.where(IhsOpex) where?: Where<IhsOpex>,
  ): Promise<Count> {
    return this.ihsOpexRepository.count(where);
  }

  @get('/ihs-opexes')
  @response(200, {
    description: 'Array of IhsOpex model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(IhsOpex, {includeRelations: true}),
        },
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async find(
    @param.filter(IhsOpex) filter?: Filter<IhsOpex>,
  ): Promise<IhsOpex[]> {
    return this.ihsOpexRepository.find(filter);
  }

  @get('/ihs-opexes/{id}')
  @response(200, {
    description: 'IhsOpex model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(IhsOpex, {includeRelations: true}),
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async findById(
    @param.path.string('id') id: string,
    @param.filter(IhsOpex, {exclude: 'where'}) filter?: FilterExcludingWhere<IhsOpex>
  ): Promise<IhsOpex> {
    return this.ihsOpexRepository.findById(id, filter);
  }

  @patch('/ihs-opexes/{id}')
  @response(204, {
    description: 'IhsOpex PATCH success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(IhsOpex, {partial: true}),
        },
      },
    })
    ihsOpex: IhsOpex,
  ): Promise<void> {
    await this.ihsOpexRepository.updateById(id, ihsOpex);
  }

  @put('/ihs-opexes/{id}')
  @response(204, {
    description: 'IhsOpex PUT success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() ihsOpex: IhsOpex,
  ): Promise<void> {
    await this.ihsOpexRepository.replaceById(id, ihsOpex);
  }

  @del('/ihs-opexes/{id}')
  @response(204, {
    description: 'IhsOpex DELETE success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'finance'],
    voters: [basicAuthorization],
  })
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.ihsOpexRepository.deleteById(id);
  }
}
