import {authenticate} from '@loopback/authentication';
import {authorize} from '@loopback/authorization';
import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where
} from '@loopback/repository';
import {
  del, get,
  getModelSchemaRef, param,
  patch, post,
  put,
  requestBody,
  response
} from '@loopback/rest';
import {basicAuthorization} from '../middlewares/auth.midd';
import {SitesConsidered} from '../models';
import {SitesConsideredRepository} from '../repositories';

export class SitesConsideredController {
  constructor(
    @repository(SitesConsideredRepository)
    public sitesConsideredRepository: SitesConsideredRepository,
  ) { }

  @post('/sites-considereds')
  @response(200, {
    description: 'SitesConsidered model instance',
    content: {'application/json': {schema: getModelSchemaRef(SitesConsidered)}},
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy'],
    voters: [basicAuthorization],
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(SitesConsidered, {
            title: 'NewSitesConsidered',

          }),
        },
      },
    })
    sitesConsidered: SitesConsidered,
  ): Promise<SitesConsidered> {
    return this.sitesConsideredRepository.create(sitesConsidered);
  }

  @get('/sites-considereds/count')
  @response(200, {
    description: 'SitesConsidered model count',
    content: {'application/json': {schema: CountSchema}},
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy'],
    voters: [basicAuthorization],
  })
  async count(
    @param.where(SitesConsidered) where?: Where<SitesConsidered>,
  ): Promise<Count> {
    return this.sitesConsideredRepository.count(where);
  }

  @get('/sites-considereds')
  @response(200, {
    description: 'Array of SitesConsidered model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(SitesConsidered, {includeRelations: true}),
        },
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy'],
    voters: [basicAuthorization],
  })
  async find(
    @param.filter(SitesConsidered) filter?: Filter<SitesConsidered>,
  ): Promise<SitesConsidered[]> {
    return this.sitesConsideredRepository.find(filter);
  }

  @patch('/sites-considereds')
  @response(200, {
    description: 'SitesConsidered PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy'],
    voters: [basicAuthorization],
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(SitesConsidered, {partial: true}),
        },
      },
    })
    sitesConsidered: SitesConsidered,
    @param.where(SitesConsidered) where?: Where<SitesConsidered>,
  ): Promise<Count> {
    return this.sitesConsideredRepository.updateAll(sitesConsidered, where);
  }

  @get('/sites-considereds/{id}')
  @response(200, {
    description: 'SitesConsidered model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(SitesConsidered, {includeRelations: true}),
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy'],
    voters: [basicAuthorization],
  })
  async findById(
    @param.path.string('id') id: string,
    @param.filter(SitesConsidered, {exclude: 'where'}) filter?: FilterExcludingWhere<SitesConsidered>
  ): Promise<SitesConsidered> {
    return this.sitesConsideredRepository.findById(id, filter);
  }

  @patch('/sites-considereds/{id}')
  @response(204, {
    description: 'SitesConsidered PATCH success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy'],
    voters: [basicAuthorization],
  })
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(SitesConsidered, {partial: true}),
        },
      },
    })
    sitesConsidered: SitesConsidered,
  ): Promise<void> {
    await this.sitesConsideredRepository.updateById(id, sitesConsidered);
  }

  @put('/sites-considereds/{id}')
  @response(204, {
    description: 'SitesConsidered PUT success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy'],
    voters: [basicAuthorization],
  })
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() sitesConsidered: SitesConsidered,
  ): Promise<void> {
    await this.sitesConsideredRepository.replaceById(id, sitesConsidered);
  }

  @del('/sites-considereds/{id}')
  @response(204, {
    description: 'SitesConsidered DELETE success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy'],
    voters: [basicAuthorization],
  })
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.sitesConsideredRepository.deleteById(id);
  }
}
