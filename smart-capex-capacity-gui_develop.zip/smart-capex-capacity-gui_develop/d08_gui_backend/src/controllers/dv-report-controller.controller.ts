/* eslint-disable @typescript-eslint/no-explicit-any */
import {authenticate} from '@loopback/authentication';
import {authorize} from '@loopback/authorization';
import {inject} from '@loopback/core';
import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where
} from '@loopback/repository';
import {
  del, get,
  getModelSchemaRef, param, patch, post, put, Request, requestBody,
  response, Response, RestBindings
} from '@loopback/rest';
import {basicAuthorization} from '../middlewares/auth.midd';
import {DvReport} from '../models';
import {DvReportRepository} from '../repositories';
const _ = require('lodash');

export class DvReportControllerController {
  constructor(
    @repository(DvReportRepository)
    public dvReportRepository: DvReportRepository,
    @inject(RestBindings.Http.RESPONSE) private respo: Response,
    @inject(RestBindings.Http.REQUEST) private request: Request,
  ) { }

  @post('/dv-reports')
  @response(200, {
    description: 'DvReport model instance',
    content: {'application/json': {schema: getModelSchemaRef(DvReport)}},
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['editor', 'admin', 'validator', 'ser'],
    voters: [basicAuthorization],
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(DvReport, {
            title: 'NewDvReport',
            exclude: ['id'],
          }),
        },
      },
    })
    dvReport: Omit<DvReport, 'id'>,
  ): Promise<DvReport> {
    return this.dvReportRepository.create(dvReport);
  }

  @get('/dv-reports/count')
  @response(200, {
    description: 'DvReport model count',
    content: {'application/json': {schema: CountSchema}},
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['editor', 'admin', 'validator', 'ser'],
    voters: [basicAuthorization],
  })
  async count(
    @param.where(DvReport) where?: Where<DvReport>,
  ): Promise<Count> {
    return this.dvReportRepository.count(where);
  }

  @get('/dv-reports/{anomalie}/{periodeStart}/{periodeEnd}')
  @response(200, {
    description: 'Anomalies HeatMap Data',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(DvReport, {includeRelations: true}),
        },
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['editor', 'admin', 'validator', 'ser'],
    voters: [basicAuthorization],
  })
  async findByHeatmapCriteria(
    @param.path.string('anomalie') anomalie: string,
    @param.path.string('periodeStart') periodeStart: string,
    @param.path.string('periodeEnd') periodeEnd: string,
    @param.filter(DvReport) filter?: Filter<DvReport>,
  ): Promise<any> {
    try {
      const sql = `SELECT * FROM dv_report WHERE anomaly_short_description = ? AND batch_id >= ? AND batch_id <= ?;`
      const data = await this.dvReportRepository.execute(sql, [anomalie, periodeStart, periodeEnd]);
      let values: any[][] = [];
      // Dates et KPIS
      const dates = data.length > 0 ? _.uniq(data.map((item: any) => item["batch_id"]/*moment(item["date"]).format('YYYY-MM-DD')*/)) : [];
      console.log(dates)
      const kpis = data.length > 0 ? _.uniq(data.map((item: any) => item["feature_name"])) : [];
      if (data.length > 0) {
        // Construire la matrice de la heatmap
        dates.forEach((date: any) => {
          kpis.forEach((kpi: any) => {
            const allItems = data.filter((el: any) => el.batch_id === date /*moment(el.date).format('YYYY-MM-DD') === moment(date).format('YYYY-MM-DD')*/ && el.feature_name === kpi);
            //Push data in the matrice if allItems is not empty
            if (allItems.length > 0) {
              values.push([kpis.indexOf(kpi), dates.indexOf(date), allItems.length]);
            }
          })

        });
      }

      values = values.map((item) => {
        return [item[1], item[0], item[2] || '-'];
      });

      return this.respo.send({values, dates, kpis});

    } catch (error) {
      return this.respo.status(500).send({
        message: `Ouf, une erreur serveur est survenue!`,
        error,
        status: 500,
      });
    }

  }

  @get('/dv-reports/{periodeStart}/{periodeEnd}')
  @response(200, {
    description: 'TreeMap Data',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(DvReport, {includeRelations: true}),
        },
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['editor', 'admin', 'validator', 'ser'],
    voters: [basicAuthorization],
  })
  async findByTreeCriteria(
    @param.path.string('periodeStart') periodeStart: string,
    @param.path.string('periodeEnd') periodeEnd: string,
    @param.filter(DvReport) filter?: Filter<DvReport>,
  ): Promise<any> {
    try {
      //const sql = `SELECT * FROM dv_report WHERE batch_id BETWEEN CAST(? AS DATE) AND CAST(? AS DATE);`
      const sql = `SELECT * FROM dv_report WHERE batch_id >= ? AND batch_id <= ?;`
      const data = await this.dvReportRepository.execute(sql, [periodeStart, periodeEnd]);
      //console.log(data);
      const values: any[] = [];
      if (data.length > 0) {
        const anomalies: any[] = _.uniq(data.map((item: any) => item["anomaly_short_description"]));
        // Construire la matrice de la treemap
        anomalies.forEach((anomalie: any) => {
          const allItems = data.filter((el: any) => el.anomaly_short_description === anomalie);
          // eslint-disable-next-line @typescript-eslint/naming-convention
          type child = {
            value: number,
            name: string,
            path: string,
            children: any[]
          };
          const node: child = {
            "value": allItems.length,
            "name": anomalie,
            "path": anomalie,
            children: []
          }

          const features = _.uniq(allItems.map((item: any) => item["feature_name"]));
          // Find the children of the node
          features.forEach((feature: any) => {
            const childs = allItems.filter((el: any) => el.feature_name === feature);
            node.children.push({
              value: childs.length,
              name: feature,
              path: anomalie + '/' + feature,
            })
          })
          // save the node
          values.push(node)
        })

      }

      return this.respo.send(values);

    } catch (error) {
      return this.respo.status(500).send({
        message: `Ouf, une erreur serveur est survenue!`,
        status: 500,
        error
      });
    }

  }


  @get('/dv-reports/exemples/{anomalyId}')
  @response(200, {
    description: 'Get dv exemples for anomaly type',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(DvReport, {includeRelations: true}),
        },
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['editor', 'admin', 'validator', 'ser'],
    voters: [basicAuthorization],
  })
  async getDvExemples(
    @param.path.string('anomalyId') anomalyId: string,
    @param.filter(DvReport) filter?: Filter<DvReport>,
  ): Promise<any> {
    try {
      const sql = `SELECT * FROM dv_examples WHERE anomaly_id = ?;`
      const data = await this.dvReportRepository.execute(sql, [anomalyId]);
      return this.respo.send(data);

    } catch (error) {
      return this.respo.status(500).send({
        message: `Ouf, une erreur serveur est survenue pendant le chargement des exemples d'anomalies!`,
        status: 500,
        error
      });
    }
  }

  @get('/dv-reports/all/{periodeStart}/{periodeEnd}')
  @response(200, {
    description: 'Array of DvReport model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(DvReport, {includeRelations: true}),
        },
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['editor', 'admin', 'validator', 'ser'],
    voters: [basicAuthorization],
  })
  async find(
    @param.path.string('periodeStart') periodeStart: string,
    @param.path.string('periodeEnd') periodeEnd: string,
    @param.filter(DvReport) filter?: Filter<DvReport>,
  ): Promise<any> {
    try {
      const sql = `SELECT * FROM dv_report WHERE batch_id >= ? AND batch_id <= ? ;`
      const data = await this.dvReportRepository.execute(sql, [periodeStart, periodeEnd]);
      const allData = await this.dvReportRepository.execute(`SELECT * FROM dv_report`);
      return this.respo.send({data, allData});

    } catch (error) {
      return this.respo.status(500).send({
        message: `Ouf, une erreur serveur est survenue pendant le chargement de toutes les anomalies!`,
        status: 500,
        error
      });
    }
  }

  @patch('/dv-reports')
  @response(200, {
    description: 'DvReport PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['editor', 'admin', 'validator', 'ser'],
    voters: [basicAuthorization],
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(DvReport, {partial: true}),
        },
      },
    })
    dvReport: DvReport,
    @param.where(DvReport) where?: Where<DvReport>,
  ): Promise<Count> {
    return this.dvReportRepository.updateAll(dvReport, where);
  }

  @get('/dv-reports/{id}')
  @response(200, {
    description: 'DvReport model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(DvReport, {includeRelations: true}),
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['editor', 'admin', 'validator', 'ser'],
    voters: [basicAuthorization],
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(DvReport, {exclude: 'where'}) filter?: FilterExcludingWhere<DvReport>
  ): Promise<DvReport> {
    return this.dvReportRepository.findById(id, filter);
  }

  @patch('/dv-reports/{id}')
  @response(204, {
    description: 'DvReport PATCH success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['editor', 'admin', 'validator', 'ser'],
    voters: [basicAuthorization],
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(DvReport, {partial: true}),
        },
      },
    })
    dvReport: DvReport,
  ): Promise<void> {
    await this.dvReportRepository.updateById(id, dvReport);
  }

  @put('/dv-reports/{id}')
  @response(204, {
    description: 'DvReport PUT success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['editor', 'admin', 'validator', 'ser'],
    voters: [basicAuthorization],
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() dvReport: DvReport,
  ): Promise<void> {
    await this.dvReportRepository.replaceById(id, dvReport);
  }

  @del('/dv-reports/{id}')
  @response(204, {
    description: 'DvReport DELETE success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['editor', 'admin', 'validator', 'ser'],
    voters: [basicAuthorization],
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.dvReportRepository.deleteById(id);
  }
}
