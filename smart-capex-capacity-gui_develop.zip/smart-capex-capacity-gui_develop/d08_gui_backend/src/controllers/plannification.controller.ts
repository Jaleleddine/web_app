/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-shadow */
import {authenticate} from '@loopback/authentication';
import {authorize} from '@loopback/authorization';
import {inject} from '@loopback/core';
import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where
} from '@loopback/repository';
import {
  del, get,
  getModelSchemaRef,
  param,
  patch, post,
  put,
  Request,
  requestBody,
  response,
  Response, RestBindings
} from '@loopback/rest';
import {basicAuthorization} from '../middlewares/auth.midd';
import {Plannification} from '../models';
import {PlanificationExecution} from '../models/planification-execution.model';
import {PlannificationRepository, UserRepository} from '../repositories';
import {sendSMS} from '../services/send-sms.service';
const axios = require('axios');
const _ = require('lodash');

export class PlannificationController {
  constructor(
    @repository(PlannificationRepository)
    public plannificationRepository: PlannificationRepository,
    @repository(UserRepository)
    public userRepository: UserRepository,
    @inject(RestBindings.Http.RESPONSE) private respo: Response,
    @inject(RestBindings.Http.REQUEST) private request: Request
  ) { }

  @post('/plannifications')
  @response(200, {
    description: 'Plannification model instance',
    content: {'application/json': {schema: getModelSchemaRef(Plannification)}},
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['editor', 'admin', 'validator', 'ser'],
    voters: [basicAuthorization],
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Plannification, {
            title: 'NewPlannification',
            exclude: ['id'],
          }),
        },
      },
    })
    plannification: Omit<Plannification, 'id'>,
  ): Promise<unknown> {

    try {
      // La liste des users à être notifiés
      // eslint-disable-next-line @typescript-eslint/no-unused-vars
      const validatorUsers = await this.userRepository.find({
        where: {or: [{role: 'validator'}, {role: 'admin'}]},
      });
      // const validatorUsers: string[] = ['2250708923820'];
      const smsContent = `Une planification vient d'être créée par ${plannification.createdBy}, veuillez svp vous connecter à l'application SmartCAPEX pour l'éxécuter.`
      const data = await this.plannificationRepository.create(plannification);
      //console.log('Save planif')
      if (validatorUsers.length > 0) {
        validatorUsers.forEach(user => {
          //console.log('send sms');
          sendSMS(user.phoneNumber, smsContent)
        })
      }
      //console.log(data)
      return this.respo.status(200).send(data);
    } catch (error) {
      //console.log(error)
      return this.respo.status(400).send({
        message: `La création de la planification a échoué, merci de réessayer!`,
        status: 400,
      });
    }

  }

  @get('/plannifications/count')
  @response(200, {
    description: 'Plannification model count',
    content: {'application/json': {schema: CountSchema}},
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'editor', 'viewer', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async count(
    @param.where(Plannification) where?: Where<Plannification>,
  ): Promise<Count> {
    return this.plannificationRepository.count(where);
  }

  @get('/plannifications')
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'editor', 'viewer', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  @response(200, {
    description: 'Array of Plannification model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Plannification, {includeRelations: true}),
        },
      },
    },
  })
  async find(
    @param.filter(Plannification) filter?: Filter<Plannification>,
  ): Promise<any> {
    return this.plannificationRepository.execute('SELECT id, name, budget, etatValidation, impactDuration, wacc, dateDebut, anneeDeploiement, statutAnalyse, createdBy, updatedBy, validatedBy FROM Plannification;');

  }

  @patch('/plannifications')
  @response(200, {
    description: 'Plannification PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['editor', 'admin', 'validator', 'ser'],
    voters: [basicAuthorization],
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Plannification, {partial: true}),
        },
      },
    })
    plannification: Plannification,
    @param.where(Plannification) where?: Where<Plannification>,
  ): Promise<Count> {
    return this.plannificationRepository.updateAll(plannification, where);
  }

  @get('/plannifications/{id}')
  @response(200, {
    description: 'Plannification model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(Plannification, {includeRelations: true}),
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'editor', 'viewer', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(Plannification, {exclude: 'where'}) filter?: FilterExcludingWhere<Plannification>
  ): Promise<Plannification> {
    return this.plannificationRepository.findById(id, filter);
  }

  @patch('/plannifications/{id}')
  @response(204, {
    description: 'Plannification PATCH success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['editor', 'admin', 'validator', 'ser'],
    voters: [basicAuthorization],
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Plannification, {partial: true}),
        },
      },
    })
    plannification: Plannification,
  ): Promise<void> {
    await this.plannificationRepository.updateById(id, plannification);
  }

  @get('/plannifications/check-execution')
  @response(200, {
    description: 'Check Plannification Execution statut',
    content: {
      'application/json': {
        type: 'array',
        schema: getModelSchemaRef(Plannification, {includeRelations: true}),
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'editor', 'viewer', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async checkPlannificationExecution(
  ): Promise<any> {
    // return this.plannificationRepository.findById(id, filter);
    // console.log('checking');
    // const sql = `SELECT * FROM Plannification AS a JOIN final_npv_of_planification AS b ON a.id = b.planification_id WHERE a.statutAnalyse = 'DEMARRE';`
    const sql = `SELECT a.id, a.name, b.planification_id, b.site_id, b.statut_execution, b.cell_band, b.cash_flow_year_0, b.cash_flow_year_1, b.cash_flow_year_2,
    b.cash_flow_year_3, b.cash_flow_year_4, b.cash_flow_year_5, b.cash_flow_year_6
     FROM Plannification AS a JOIN final_npv_of_planification AS b ON a.id = b.planification_id WHERE a.statutAnalyse = 'DEMARRE';`
    let result: any = await this.plannificationRepository.execute(sql);

    if (result.length > 0) {
      // Eliminer les doublons dans les résultats
      result = _.uniqBy(result, 'planification_id');
      console.log(result.length)
      result.forEach(async (item: any) => {
        await this.plannificationRepository.execute(`UPDATE Plannification SET statutAnalyse = ? WHERE id = ?`,
          [item.statut_execution, item.planification_id])

      });
    }
    // return {statut: 200, message: 'Checking ok'};
  }

  @get('/plannifications/{id}/execution-result')
  @response(200, {
    description: 'Get Plannification Execution Result',
    content: {
      'application/json': {
        type: 'array',
        schema: getModelSchemaRef(Plannification, {includeRelations: true}),
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'editor', 'viewer', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async getPlannificationExecution(
    @param.path.number('id') id: number,
  ): Promise<any> {
    const sql = `SELECT a.id, a.name, a.budget, b.planification_id, b.site_id, b.statut_execution, b.cell_band, b.cash_flow_year_0, b.cash_flow_year_1, b.cash_flow_year_2,
    b.cash_flow_year_3, b.cash_flow_year_4, b.cash_flow_year_5, b.cash_flow_year_6, b.npv, b.opex_cost_year_0, b.opex_cost_year_1, b.opex_cost_year_2, b.opex_cost_year_3, b.opex_cost_year_4,
    b.opex_cost_year_4, b.opex_cost_year_5, b.opex_cost_year_6, b.total_revenue, b.EBITDA_Value, b.EBITDA, b.IRR, b.IRR_TOTAL
    FROM Plannification AS a JOIN final_npv_of_planification AS b ON a.id = b.planification_id WHERE a.statutAnalyse = 'SUCCESS' AND a.id = ?;`
    // const sql = `SELECT * FROM Plannification AS a JOIN final_npv_of_planification AS b ON a.id = b.planification_id WHERE a.statutAnalyse = 'SUCCESS' AND a.id = ${id};`
    const result: any = await this.plannificationRepository.execute(sql, [id]);
    return result;
  }

  @patch('/plannifications/{id}/execution')
  @response(200, {
    description: 'Plannification Execution',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['validator'],
    voters: [basicAuthorization],
  })
  async updateNdExecutionById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(PlanificationExecution, {partial: true}),
        },
      },
    })
    plannification: Plannification,
  ): Promise<any> {
    // Executer notre planification coté analytic
    const execution = await new Promise((success, failure) => {
      axios({
        method: 'post',
        url: 'http://10.238.36.20:5000/planif',
        data: plannification,
        headers: {'Accept': 'application/json', 'Content-Type': 'application/json'},
        maxContentLength: 10000000000,
        maxBodyLength: 10000000000
      }).then(function (response: any) {
        const data = response.data;
        //console.log()
        console.log(data["code"])
        // eslint-disable-next-line eqeqeq
        if (data["code"] === 200) {
          success(true);
          //console.log(data)
        } else {
          //console.log('failure')
          //failure(false)
          success(false);
        }
      })
        .catch((error: any) => {
          console.log(error)
          //failure(false);
          success(false);
        })

    })
    // console.log(execution);

    if (!execution) {
      this.respo.status(500).send({
        message: 'Une erreur est intervenue pendant l\'exécution de la planification',
        status: 500,
      });
      return this.respo;
    } else {
      await this.plannificationRepository.updateById(id, plannification);
    }

  }

  @put('/plannifications/{id}')
  @response(204, {
    description: 'Plannification PUT success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['editor', 'admin', 'validator', 'ser'],
    voters: [basicAuthorization],
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() plannification: Plannification,
  ): Promise<void> {
    await this.plannificationRepository.replaceById(id, plannification);
  }

  @del('/plannifications/{id}')
  @response(204, {
    description: 'Plannification DELETE success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['editor', 'admin', 'validator', 'ser'],
    voters: [basicAuthorization],
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.plannificationRepository.deleteById(id);
  }

}
