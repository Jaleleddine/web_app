/* eslint-disable @typescript-eslint/naming-convention */
/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {authenticate} from '@loopback/authentication';
import {authorize} from '@loopback/authorization';
import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where
} from '@loopback/repository';
import {
  get,
  getModelSchemaRef, param, post, requestBody,
  response
} from '@loopback/rest';
import _ from 'lodash';
import {basicAuthorization} from '../middlewares/auth.midd';
import {FinalNpvOfTheCoverage, NpvCoverage} from '../models';
import {FinalNpvOfTheCoverageRepository} from '../repositories';

export class FinalNpvOfTheCoverageControllerController {
  constructor(
    @repository(FinalNpvOfTheCoverageRepository)
    public finalNpvOfTheCoverageRepository: FinalNpvOfTheCoverageRepository,
  ) { }

  @post('/finali-npv-of-the-coverages-kpis')
  @response(200, {
    description: 'FinalNpvOfTheCoverage of KPIS',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async npvListKpis(
    @requestBody({
      /*content: {
        'application/json': {
          schema: getModelSchemaRef(NpvCoverage, {
            title: 'NewFinalNpvOfTheCoverage',

          }),
        },
      },*/
    })
    finalNpvOfTheCoverage: NpvCoverage,
  ): Promise<any> {
    // Calculate KPIS
    const data = finalNpvOfTheCoverage.list;
    const npv = _.sumBy(data, function (o: any) {return parseFloat(o.npv);});
    const totalRevenue = _.sumBy(data, function (o: any) {return parseFloat(parseFloat(o.totalRevenue).toFixed(2));});
    const totalOpex = _.sumBy(data, function (o: any) {return parseFloat(parseFloat(o.totalOpex).toFixed(2));});
    const totalCapex = _.sumBy(data, function (o: any) {return Math.abs(parseFloat(parseFloat(o.cashFlowYear0).toFixed(2)));});
    const cashFlowYear0 = _.sumBy(data, function (o: any) {return parseFloat(parseFloat(o.cashFlowYear0).toFixed(2));});
    const cashFlowYear1 = _.sumBy(data, function (o: any) {return parseFloat(parseFloat(o.cashFlowYear1).toFixed(2));});
    const cashFlowYear2 = _.sumBy(data, function (o: any) {return parseFloat(parseFloat(o.cashFlowYear2).toFixed(2));});
    const cashFlowYear3 = _.sumBy(data, function (o: any) {return parseFloat(parseFloat(o.cashFlowYear3).toFixed(2));});
    const cashFlowYear4 = _.sumBy(data, function (o: any) {return parseFloat(parseFloat(o.cashFlowYear4).toFixed(2));});
    const cashFlowYear5 = _.sumBy(data, function (o: any) {return parseFloat(parseFloat(o.cashFlowYear5).toFixed(2));});
    const cashFlowYear6 = _.sumBy(data, function (o: any) {return parseFloat(parseFloat(o.cashFlowYear6).toFixed(2));});
    // Calcul du payback period
    const cashFlows = [cashFlowYear0, cashFlowYear1, cashFlowYear2, cashFlowYear3, cashFlowYear4, cashFlowYear5, cashFlowYear6];

    const cCashFlowYear1 = cashFlowYear0 + cashFlowYear1;
    const cCashFlowYear2 = cCashFlowYear1 + cashFlowYear2;
    const cCashFlowYear3 = cCashFlowYear2 + cashFlowYear3;
    const cCashFlowYear4 = cCashFlowYear3 + cashFlowYear4;
    const cCashFlowYear5 = cCashFlowYear4 + cashFlowYear5;
    const cCashFlowYear6 = cCashFlowYear5 + cashFlowYear6;

    const cumulativeCashFlows = [cCashFlowYear1, cCashFlowYear2, cCashFlowYear3, cCashFlowYear4, cCashFlowYear5, cCashFlowYear6]; // La liste des cumulative cashflow
    const negativeCumulativeCashFlows: number[] = [];
    let firstPositive = 0;
    let totalNegativeCumulativeCashFlows = 0;

    // Get the first positive
    cashFlows.every(cash => {
      if (cash < 0) {
        return true;
      }
      if (cash > 0) {
        firstPositive = cash;
        return false;// stop the loop
      }
    }
    );

    cumulativeCashFlows.every(cash => {
      if (cash < 0) {
        totalNegativeCumulativeCashFlows += 1;
        negativeCumulativeCashFlows.push(cash)
        return true;// continue the loop
      }
      if (cash > 0) {
        return false;// stop the loop
      }
    })
    // Payback period
    const lastNegative = negativeCumulativeCashFlows[negativeCumulativeCashFlows.length - 1];
    const payback = Math.abs(lastNegative / firstPositive) + totalNegativeCumulativeCashFlows;


    return {payback, npv, totalCapex, totalOpex, totalRevenue, cashFlowYear0, cashFlowYear1, cashFlowYear2, cashFlowYear3, cashFlowYear4, cashFlowYear5, cashFlowYear6};
  }

  @get('/final-npv-of-the-coverages/count')
  @response(200, {
    description: 'FinalNpvOfTheCoverage model count',
    content: {'application/json': {schema: CountSchema}},
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async count(
    @param.where(FinalNpvOfTheCoverage) where?: Where<FinalNpvOfTheCoverage>,
  ): Promise<Count> {
    return this.finalNpvOfTheCoverageRepository.count(where);
  }

  @get('/final-npv-of-the-coverages')
  @response(200, {
    description: 'Array of FinalNpvOfTheCoverage model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(FinalNpvOfTheCoverage, {includeRelations: true}),
        },
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async find(
    @param.filter(FinalNpvOfTheCoverage) filter?: Filter<FinalNpvOfTheCoverage>,
  ): Promise<FinalNpvOfTheCoverage[]> {
    return this.finalNpvOfTheCoverageRepository.find(filter);
  }


  @get('/existed-cells-position/{sousPrefecture}')
  @response(200, {
    description: 'Get existed cells positions by sous-prefecture',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(FinalNpvOfTheCoverage, {includeRelations: true}),
        },
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async findExistedCellsPosition(
    @param.path.string('sousPrefecture') sousPrefecture: string,
  ): Promise<unknown> {
    const sql = `SELECT * FROM existed_cells_position WHERE sous_prefecture_name = ? ;`;
    try {
      const result: any = await this.finalNpvOfTheCoverageRepository.execute(sql,
        [sousPrefecture]);
      if (result.length > 0) {
        result.forEach((sp: any) => {
          sp.coordinates = JSON.parse(sp.coordinates)
        })

      }
      return result;
    } catch (err) {
      // handle the error
      //console.log(err)
    } finally {
      // d'autres actions finales ici
    }
  }


  @get('/existed-cells-coverage/{sousPrefecture}')
  @response(200, {
    description: 'Get existed cells coverage by sous-prefecture',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(FinalNpvOfTheCoverage, {includeRelations: true}),
        },
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async findExistedCellsCoverage(
    @param.path.string('sousPrefecture') sousPrefecture: string,
  ): Promise<unknown> {
    const sql = `SELECT * FROM existed_cells_coverage_light WHERE sous_prefecture_name = ? ;`;
    try {
      const result: any = await this.finalNpvOfTheCoverageRepository.execute(sql,
        [sousPrefecture]);

      if (result.length > 0) {
        result.forEach((sp: any) => {
          sp.coordinates = JSON.parse(sp.coordinates)
        })

      }
      /*result = _.groupBy(result, function (o: any) {return o.cell_name;})
      const data: any[] = []
      for (const cell_name in result) {
        const cellRows: any[] = result[cell_name]
        if (cellRows.length > 0) {
          const coordinates = cellRows.map(row => JSON.parse(row?.coordinates)?.coordinates);

          data.push({coordinates, cell_name, cell_population: cellRows[0]?.cell_population, site_id: cellRows[0]?.site_id, sous_prefecture_name: cellRows[0]?.sous_prefecture_name})
        }
      }*/

      return result;

    } catch (err) {
      // handle the error
      //console.log(err)
    } finally {
      // d'autres actions finales ici
    }
  }


  @get('/new-cells-coverage/{sousPrefecture}')
  @response(200, {
    description: 'Get new cells coverage by sous-prefecture',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(FinalNpvOfTheCoverage, {includeRelations: true}),
        },
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async findNewCellsCoverage(
    @param.path.string('sousPrefecture') sousPrefecture: string,
  ): Promise<unknown> {
    const sql = `SELECT * FROM new_cells_coverage_light WHERE sous_prefecture_name = ?;`;
    try {
      const result: any = await this.finalNpvOfTheCoverageRepository.execute(sql,
        [sousPrefecture]);

      if (result.length > 0) {
        result.forEach((sp: any) => {
          sp.coordinates = JSON.parse(sp.coordinates)
        })

      }
      /*result = _.groupBy(result, function (o: any) {return o.cell_name;})
      const data: any[] = []
      for (const cell_name in result) {
        const cellRows: any[] = result[cell_name]
        if (cellRows.length > 0) {
          const coordinates = cellRows.map(row => JSON.parse(row?.coordinates)?.coordinates);

          data.push({coordinates, cell_name, cell_population: cellRows[0]?.cell_population, site_id: cellRows[0]?.site_id, sous_prefecture_name: cellRows[0]?.sous_prefecture_name})
        }
      }*/

      /*const geojson = turf.polygon(polygones);
      const options = {tolerance: 0.01, highQuality: false};
      const simplified = turf.simplify(geojson, options);*/
      return result;

    } catch (err) {
      // handle the error
      //console.log(err)
    } finally {
      // d'autres actions finales ici
    }
  }


  @get('/new-cells-position/{sousPrefecture}')
  @response(200, {
    description: 'Get existed cells coverage by sous-prefecture',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(FinalNpvOfTheCoverage, {includeRelations: true}),
        },
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async findNewCellsPosition(
    @param.path.string('sousPrefecture') sousPrefecture: string,
  ): Promise<unknown> {
    const sql = `SELECT * FROM new_cells_position WHERE sous_prefecture_name = ? ;`;
    try {
      const result: any = await this.finalNpvOfTheCoverageRepository.execute(sql,
        [sousPrefecture]);
      if (result.length > 0) {
        result.forEach((sp: any) => {
          sp.coordinates = JSON.parse(sp.coordinates)
        })
      }
      return result;
    } catch (err) {
      // handle the error
      //console.log(err)
    } finally {
      // d'autres actions finales ici
    }
  }


  @get('/sous-prefectures')
  @response(200, {
    description: 'Get all sous-prefectures',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(FinalNpvOfTheCoverage, {includeRelations: true}),
        },
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async getAllSousPrefectures(
  ): Promise<unknown> {
    const sql = `SELECT * FROM coverage_sous_prefecture;`;
    try {
      const result: any = await this.finalNpvOfTheCoverageRepository.execute(sql);
      if (result.length > 0) {
        result.forEach((sp: any) => {
          sp.coordinates = JSON.parse(sp.coordinates)
        })

      }
      return result;
    } catch (err) {
      // handle the error
      //console.log(err)
    } finally {
      // d'autres actions finales ici
    }
  }



  @get('/final-npv-of-the-coverages/{id}')
  @response(200, {
    description: 'FinalNpvOfTheCoverage model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(FinalNpvOfTheCoverage, {includeRelations: true}),
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(FinalNpvOfTheCoverage, {exclude: 'where'}) filter?: FilterExcludingWhere<FinalNpvOfTheCoverage>
  ): Promise<FinalNpvOfTheCoverage> {
    return this.finalNpvOfTheCoverageRepository.findById(id, filter);
  }


}
