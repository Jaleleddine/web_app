/* eslint-disable @typescript-eslint/no-explicit-any */
import {authenticate} from '@loopback/authentication';
import {authorize} from '@loopback/authorization';
import {inject} from '@loopback/core';
import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where
} from '@loopback/repository';
import {
  del, get,
  getModelSchemaRef, param,
  patch, post,
  put,
  requestBody,
  response,
  Response,
  RestBindings
} from '@loopback/rest';
import * as config from '../config.json';
import {basicAuthorization} from '../middlewares/auth.midd';
import {Constante} from '../models';
import {ConstanteRepository, UserRepository} from '../repositories';
import {sendSMS} from '../services/send-sms.service';
const axios = require('axios');

export class ConstanteController {
  constructor(
    @repository(ConstanteRepository)
    public constanteRepository: ConstanteRepository,
    @repository(UserRepository)
    public userRepository: UserRepository,
    @inject(RestBindings.Http.RESPONSE)
    private respo: Response,
  ) { }

  @post('/constantes')
  @response(200, {
    description: 'Constante model instance',
    content: {'application/json': {schema: getModelSchemaRef(Constante)}},
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async create(
    @requestBody(/*{
      content: {
        'application/json': {
          schema: getModelSchemaRef(Constante, {
            title: 'New Constante',

          }),
        },
      },
    }*/)
    constante: Constante,
  ): Promise<unknown> {
    // console.log(constante)
    // Get config from analytic server and save new with parameters
    try {
      const user = constante.modifiedBy;
      // check if data ids are corrects
      const ids = ['OPEX_INCREASE_BY_YEAR', 'TIME_TO_COMPUTE_NPV', 'WACC', 'MAX_NUMBER_OF_NEIGHBORS', 'WEEK_OF_THE_UPGRADE'];
      if (!ids.includes(constante.identifiant)) {
        return this.respo.status(400).send({
          message: `Identifiant ${constante.identifiant} incorrect`,
          status: 400,
        });
      }

      //console.log(config.config_host)
      const result: any = await axios.get(config.config_host + '/getConfig ');
      const configs = result.data
      //console.log(configs)
      switch (constante.identifiant) {
        case 'OPEX_INCREASE_BY_YEAR':
          configs.NPV.OPEX_INCREASE_BY_YEAR = parseFloat(constante.valeur);
          break;
        case 'TIME_TO_COMPUTE_NPV':
          configs.NPV.TIME_TO_COMPUTE_NPV = parseFloat(constante.valeur);
          break;
        case 'WACC':
          configs.NPV.WACC = parseFloat(constante.valeur);
          break;
        case 'MAX_NUMBER_OF_NEIGHBORS':
          configs.TRAFFIC_IMPROVEMENT.MAX_NUMBER_OF_NEIGHBORS = parseFloat(constante.valeur);
          break;
        case 'WEEK_OF_THE_UPGRADE':
          configs.TRAFFIC_IMPROVEMENT.WEEK_OF_THE_UPGRADE = constante.valeur;
          break;
        default:
          console.log(`Parameter doesnt exist!`);
      }

      // Update config parameters in analytic server
      await axios.post(config.config_host + '/setConfigs', configs)
      // Save config in DB
      const dbconfigs = await this.constanteRepository.create(constante);

      // Send sms to all smartcapex users
      const users = await this.userRepository.find();
      const smsContent = `${user}, vient de mettre à jour le paramètre ${constante.parameter}.`
      if (users.length > 0) {
        users.forEach(item => {
          //console.log('send sms');
          sendSMS(item.phoneNumber, smsContent)
        })
      }

      // return config saved in DB
      return dbconfigs;

    } catch (error) {
      console.error(error);
      return this.respo.status(400).send({
        message: `La mise à jour de ${constante.parameter} a échoué, merci de réessayer!`,
        status: 400,
      });
    }
  }


  @get('/constantes/count')
  @response(200, {
    description: 'Constante model count',
    content: {'application/json': {schema: CountSchema}},
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async count(
    @param.where(Constante) where?: Where<Constante>,
  ): Promise<Count> {
    return this.constanteRepository.count(where);
  }

  @get('/constantes')
  @response(200, {
    description: 'Array of Constante model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Constante, {includeRelations: true}),
        },
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async find(
    @param.filter(Constante) filter?: Filter<Constante>,
  ): Promise<Constante[]> {
    return this.constanteRepository.find(filter);
  }

  @patch('/constantes')
  @response(200, {
    description: 'Constante PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy'],
    voters: [basicAuthorization],
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Constante, {partial: true}),
        },
      },
    })
    constante: Constante,
    @param.where(Constante) where?: Where<Constante>,
  ): Promise<Count> {
    return this.constanteRepository.updateAll(constante, where);
  }

  @get('/constantes/{id}')
  @response(200, {
    description: 'Constante model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(Constante, {includeRelations: true}),
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async findById(
    @param.path.string('id') id: string,
    @param.filter(Constante, {exclude: 'where'}) filter?: FilterExcludingWhere<Constante>
  ): Promise<Constante> {
    return this.constanteRepository.findById(id, filter);
  }

  @patch('/constantes/{id}')
  @response(204, {
    description: 'Constante PATCH success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Constante, {partial: true}),
        },
      },
    })
    constante: Constante,
  ): Promise<unknown> {
    //console.log(constante)
    // Get config from analytic server and save new with parameters
    try {
      const user = constante.modifiedBy;
      // check if data ids are corrects
      const ids = ['OPEX_INCREASE_BY_YEAR', 'TIME_TO_COMPUTE_NPV', 'WACC', 'MAX_NUMBER_OF_NEIGHBORS', 'WEEK_OF_THE_UPGRADE'];
      if (!ids.includes(constante.identifiant)) {
        return this.respo.status(400).send({
          message: `Identifiant ${constante.identifiant} incorrect`,
          status: 400,
        });
      }

      const result: any = await axios.get(config.config_host + '/getConfig ');
      const configs = result.data
      //console.log(configs)
      //console.log(constante)
      switch (constante.identifiant) {
        case 'OPEX_INCREASE_BY_YEAR':
          configs.NPV.OPEX_INCREASE_BY_YEAR = parseFloat(constante.valeur);
          break;
        case 'TIME_TO_COMPUTE_NPV':
          configs.NPV.TIME_TO_COMPUTE_NPV = parseFloat(constante.valeur);
          break;
        case 'WACC':
          configs.NPV.WACC = parseFloat(constante.valeur);
          break;
        case 'MAX_NUMBER_OF_NEIGHBORS':
          configs.TRAFFIC_IMPROVEMENT.MAX_NUMBER_OF_NEIGHBORS = parseFloat(constante.valeur);
          break;
        case 'WEEK_OF_THE_UPGRADE':
          configs.TRAFFIC_IMPROVEMENT.WEEK_OF_THE_UPGRADE = constante.valeur;
          break;
        default:
          console.log(`Parameter doesnt exist!`);
      }

      // Update config parameters in analytic server
      await axios.post(config.config_host + '/setConfigs', configs)
      // Save config in DB
      const dbconfigs = await this.constanteRepository.updateById(id, constante);;

      // Send sms to all smartcapex users
      const users = await this.userRepository.find();
      const smsContent = `${user}, vient de mettre à jour le paramètre ${constante.parameter}.`
      if (users.length > 0) {
        users.forEach(item => {
          //console.log('send sms');
          sendSMS(item.phoneNumber, smsContent)
        })
      }

      // return config saved in DB
      return dbconfigs;

    } catch (error) {
      console.error(error);
      return this.respo.status(400).send({
        message: `La mise à jour de ${constante.parameter} a échoué, merci de réessayer!`,
        status: 400,
      });
    }

  }

  @put('/constantes/{id}')
  @response(204, {
    description: 'Constante PUT success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() constante: Constante,
  ): Promise<void> {
    await this.constanteRepository.replaceById(id, constante);
  }

  @del('/constantes/{id}')
  @response(204, {
    description: 'Constante DELETE success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.constanteRepository.deleteById(id);
  }
}
