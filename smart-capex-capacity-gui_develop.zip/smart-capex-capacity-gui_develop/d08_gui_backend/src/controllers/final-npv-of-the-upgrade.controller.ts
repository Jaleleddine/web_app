import {authenticate} from '@loopback/authentication';
import {authorize} from '@loopback/authorization';
import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where
} from '@loopback/repository';
import {
  del, get,
  getModelSchemaRef, param,
  patch, post,
  put,
  requestBody,
  response
} from '@loopback/rest';
import {basicAuthorization} from '../middlewares/auth.midd';
import {FinalNpvOfTheUpgrade} from '../models/final-npv-of-the-upgrade.model';
import {FinalNpvOfTheUpgradeRepository} from '../repositories/final-npv-of-the-upgrade.repository';

export class FinalNpvOfTheUpgradeController {
  constructor(
    @repository(FinalNpvOfTheUpgradeRepository)
    public finalNpvOfTheUpgradeRepository: FinalNpvOfTheUpgradeRepository,
  ) { }

  @post('/final-npv-of-the-upgrades')
  @response(200, {
    description: 'FinalNpvOfTheUpgrade model instance',
    content: {'application/json': {schema: getModelSchemaRef(FinalNpvOfTheUpgrade)}},
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(FinalNpvOfTheUpgrade, {
            title: 'NewFinalNpvOfTheUpgrade',
            exclude: ['id'],
          }),
        },
      },
    })
    finalNpvOfTheUpgrade: Omit<FinalNpvOfTheUpgrade, 'id'>,
  ): Promise<FinalNpvOfTheUpgrade> {
    return this.finalNpvOfTheUpgradeRepository.create(finalNpvOfTheUpgrade);
  }

  @get('/final-npv-of-the-upgrades/count')
  @response(200, {
    description: 'FinalNpvOfTheUpgrade model count',
    content: {'application/json': {schema: CountSchema}},
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async count(
    @param.where(FinalNpvOfTheUpgrade) where?: Where<FinalNpvOfTheUpgrade>,
  ): Promise<Count> {
    return this.finalNpvOfTheUpgradeRepository.count(where);
  }

  @get('/final-npv-of-the-upgrades')
  @response(200, {
    description: 'Array of FinalNpvOfTheUpgrade model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(FinalNpvOfTheUpgrade, {includeRelations: true}),
        },
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async find(
    @param.filter(FinalNpvOfTheUpgrade) filter?: Filter<FinalNpvOfTheUpgrade>,
  ): Promise<FinalNpvOfTheUpgrade[]> {
    return this.finalNpvOfTheUpgradeRepository.find(filter);
  }

  @patch('/final-npv-of-the-upgrades')
  @response(200, {
    description: 'FinalNpvOfTheUpgrade PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(FinalNpvOfTheUpgrade, {partial: true}),
        },
      },
    })
    finalNpvOfTheUpgrade: FinalNpvOfTheUpgrade,
    @param.where(FinalNpvOfTheUpgrade) where?: Where<FinalNpvOfTheUpgrade>,
  ): Promise<Count> {
    return this.finalNpvOfTheUpgradeRepository.updateAll(finalNpvOfTheUpgrade, where);
  }

  @get('/final-npv-of-the-upgrades/{id}')
  @response(200, {
    description: 'FinalNpvOfTheUpgrade model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(FinalNpvOfTheUpgrade, {includeRelations: true}),
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async findById(
    @param.path.number('id') id: number,
    @param.filter(FinalNpvOfTheUpgrade, {exclude: 'where'}) filter?: FilterExcludingWhere<FinalNpvOfTheUpgrade>
  ): Promise<FinalNpvOfTheUpgrade> {
    return this.finalNpvOfTheUpgradeRepository.findById(id, filter);
  }

  @patch('/final-npv-of-the-upgrades/{id}')
  @response(204, {
    description: 'FinalNpvOfTheUpgrade PATCH success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async updateById(
    @param.path.number('id') id: number,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(FinalNpvOfTheUpgrade, {partial: true}),
        },
      },
    })
    finalNpvOfTheUpgrade: FinalNpvOfTheUpgrade,
  ): Promise<void> {
    await this.finalNpvOfTheUpgradeRepository.updateById(id, finalNpvOfTheUpgrade);
  }

  @put('/final-npv-of-the-upgrades/{id}')
  @response(204, {
    description: 'FinalNpvOfTheUpgrade PUT success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async replaceById(
    @param.path.number('id') id: number,
    @requestBody() finalNpvOfTheUpgrade: FinalNpvOfTheUpgrade,
  ): Promise<void> {
    await this.finalNpvOfTheUpgradeRepository.replaceById(id, finalNpvOfTheUpgrade);
  }

  @del('/final-npv-of-the-upgrades/{id}')
  @response(204, {
    description: 'FinalNpvOfTheUpgrade DELETE success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async deleteById(@param.path.number('id') id: number): Promise<void> {
    await this.finalNpvOfTheUpgradeRepository.deleteById(id);
  }
}
