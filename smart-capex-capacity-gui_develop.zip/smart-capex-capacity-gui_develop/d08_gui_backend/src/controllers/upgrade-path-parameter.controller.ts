import {authenticate} from '@loopback/authentication';
import {authorize} from '@loopback/authorization';
import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where
} from '@loopback/repository';
import {
  del, get,
  getModelSchemaRef, param,
  patch, post,
  put,
  requestBody,
  response
} from '@loopback/rest';
import {basicAuthorization} from '../middlewares/auth.midd';
import {UpgradePathParameter} from '../models';
import {UpgradePathParameterRepository} from '../repositories';

export class UpgradePathParameterController {
  constructor(
    @repository(UpgradePathParameterRepository)
    public upgradePathParameterRepository: UpgradePathParameterRepository,
  ) { }


  @post('/upgrade-path-parameters')
  @response(200, {
    description: 'UpgradePathParameter model instance',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(UpgradePathParameter),
        }
      }
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'editor'],
    voters: [basicAuthorization],
  })
  async createAll(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'array',
            items: getModelSchemaRef(UpgradePathParameter, {includeRelations: true}),
          }
        }
      },
    })
    upgradePathParameters: UpgradePathParameter[],
  ): Promise<UpgradePathParameter[]> {
    // delete before saving new data
    await this.upgradePathParameterRepository.execute(`TRUNCATE UpgradePathParameter;`);
    return this.upgradePathParameterRepository.createAll(upgradePathParameters);
  }

  @get('/upgrade-path-parameters/count')
  @response(200, {
    description: 'UpgradePathParameter model count',
    content: {'application/json': {schema: CountSchema}},
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'editor'],
    voters: [basicAuthorization],
  })
  async count(
    @param.where(UpgradePathParameter) where?: Where<UpgradePathParameter>,
  ): Promise<Count> {
    return this.upgradePathParameterRepository.count(where);
  }

  @get('/upgrade-path-parameters')
  @response(200, {
    description: 'Array of UpgradePathParameter model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(UpgradePathParameter, {includeRelations: true}),
        },
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'editor'],
    voters: [basicAuthorization],
  })
  async find(
    @param.filter(UpgradePathParameter) filter?: Filter<UpgradePathParameter>,
  ): Promise<UpgradePathParameter[]> {
    return this.upgradePathParameterRepository.find(filter);
  }

  @get('/upgrade-path-parameters/{id}')
  @response(200, {
    description: 'UpgradePathParameter model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(UpgradePathParameter, {includeRelations: true}),
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'editor'],
    voters: [basicAuthorization],
  })
  async findById(
    @param.path.string('id') id: string,
    @param.filter(UpgradePathParameter, {exclude: 'where'}) filter?: FilterExcludingWhere<UpgradePathParameter>
  ): Promise<UpgradePathParameter> {
    return this.upgradePathParameterRepository.findById(id, filter);
  }

  @patch('/upgrade-path-parameters/{id}')
  @response(204, {
    description: 'UpgradePathParameter PATCH success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'editor'],
    voters: [basicAuthorization],
  })
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(UpgradePathParameter, {partial: true}),
        },
      },
    })
    upgradePathParameter: UpgradePathParameter,
  ): Promise<void> {
    await this.upgradePathParameterRepository.updateById(id, upgradePathParameter);
  }

  @put('/upgrade-path-parameters/{id}')
  @response(204, {
    description: 'UpgradePathParameter PUT success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'editor'],
    voters: [basicAuthorization],
  })
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() upgradePathParameter: UpgradePathParameter,
  ): Promise<void> {
    await this.upgradePathParameterRepository.replaceById(id, upgradePathParameter);
  }

  @del('/upgrade-path-parameters/{id}')
  @response(204, {
    description: 'UpgradePathParameter DELETE success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'editor'],
    voters: [basicAuthorization],
  })
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.upgradePathParameterRepository.deleteById(id);
  }
}
