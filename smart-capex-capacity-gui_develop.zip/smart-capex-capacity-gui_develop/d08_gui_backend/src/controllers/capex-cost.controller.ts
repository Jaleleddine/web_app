/* eslint-disable @typescript-eslint/no-explicit-any */
import {authenticate} from '@loopback/authentication';
import {authorize} from '@loopback/authorization';
import {inject} from '@loopback/core';
import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where
} from '@loopback/repository';
import {
  del, get,
  getModelSchemaRef, param,
  patch, post,
  put,
  requestBody,
  response,
  Response,
  RestBindings
} from '@loopback/rest';
import * as config from '../config.json';
import {basicAuthorization} from '../middlewares/auth.midd';
import {CapexCost} from '../models';
import {CapexCostRepository, UserRepository} from '../repositories';
import {sendSMS} from '../services/send-sms.service';
const axios = require('axios');

export class CapexCostController {
  constructor(
    @repository(CapexCostRepository)
    public capexCostRepository: CapexCostRepository,
    @repository(UserRepository)
    public userRepository: UserRepository,
    @inject(RestBindings.Http.RESPONSE)
    private respo: Response,
  ) { }

  @post('/capex-costs')
  @response(200, {
    description: 'CapexCost model instance',
    type: 'array',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(CapexCost),
        },
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'finance'],
    voters: [basicAuthorization],
  })
  async createAll(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'array',
            items: getModelSchemaRef(CapexCost, {includeRelations: true}),
          },
        },
      },
    })
    capexCost: CapexCost[],
  ): Promise<unknown> {
    // SMS 'finance', 'ser', 'strategy'
    // Save many item to the data base
    await this.capexCostRepository.execute('TRUNCATE CapexCost;');
    // check if data ids are corrects
    const ids = ['U900', 'U2100', 'L800', 'L1800', 'L2300', 'L2600'];
    const user = capexCost[0].modifiedBy;
    const PARAMS: any = {};
    capexCost.forEach(item => {
      PARAMS[item.cellBand] = item.capex
      if (!ids.includes(item.cellBand)) {
        return this.respo.status(400).send({
          message: `Frequency Band ${item.cellBand} incorrect`,
          status: 400,
        });
      }
    })

    // Get config from analytic server and save new with parameters
    try {
      const result: any = await axios.get(config.config_host + '/getConfig ');
      const configs = result.data
      console.log(PARAMS)
      configs['CAPEX'] = capexCost;

      // Update config parameters in analytic server
      await axios.post(config.config_host + '/setConfigs', configs)
      // Save config in DB
      const dbconfigs = await this.capexCostRepository.createAll(capexCost)

      // Send sms to all smartcapex users
      const users = await this.userRepository.find();
      const smsContent = `${user}, vient de mettre à jour les paramètres CAPEX.`
      if (users.length > 0) {
        users.forEach(item => {
          //console.log('send sms');
          sendSMS(item.phoneNumber, smsContent)
        })
      }

      // return config saved in DB
      return dbconfigs;

    } catch (error) {
      console.error(error);
      return this.respo.status(400).send({
        message: `La mise à jour des CAPEX a échoué, merci de réessayer!`,
        status: 400,
      });
    }
  }


  @get('/capex-costs/count')
  @response(200, {
    description: 'CapexCost model count',
    content: {'application/json': {schema: CountSchema}},
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'marketing', 'modeling'],
    voters: [basicAuthorization],
  })
  async count(
    @param.where(CapexCost) where?: Where<CapexCost>,
  ): Promise<Count> {
    return this.capexCostRepository.count(where);
  }

  @get('/capex-costs')
  @response(200, {
    description: 'Array of CapexCost model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(CapexCost, {includeRelations: true}),
        },
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'marketing', 'modeling'],
    voters: [basicAuthorization],
  })
  async find(
    @param.filter(CapexCost) filter?: Filter<CapexCost>,
  ): Promise<CapexCost[]> {
    return this.capexCostRepository.find(filter);
  }

  @get('/capex-costs/{id}')
  @response(200, {
    description: 'CapexCost model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(CapexCost, {includeRelations: true}),
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'marketing', 'modeling'],
    voters: [basicAuthorization],
  })
  async findById(
    @param.path.number('id') frequencyBand: string,
    @param.filter(CapexCost, {exclude: 'where'}) filter?: FilterExcludingWhere<CapexCost>
  ): Promise<CapexCost> {
    return this.capexCostRepository.findById(frequencyBand, filter);
  }

  @patch('/capex-costs/{id}')
  @response(204, {
    description: 'CapexCost PATCH success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'finance'],
    voters: [basicAuthorization],
  })
  async updateById(
    @param.path.number('id') frequencyBand: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(CapexCost, {partial: true}),
        },
      },
    })
    capexCost: CapexCost,
  ): Promise<void> {
    await this.capexCostRepository.updateById(frequencyBand, capexCost);
  }

  @put('/capex-costs/{id}')
  @response(204, {
    description: 'CapexCost PUT success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'finance'],
    voters: [basicAuthorization],
  })
  async replaceById(
    @param.path.number('id') frequencyBand: string,
    @requestBody() capexCost: CapexCost,
  ): Promise<void> {
    await this.capexCostRepository.replaceById(frequencyBand, capexCost);
  }

  @del('/capex-costs/{id}')
  @response(204, {
    description: 'CapexCost DELETE success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'finance'],
    voters: [basicAuthorization],
  })
  async deleteById(@param.path.number('id') frequencyBand: string): Promise<void> {
    await this.capexCostRepository.deleteById(frequencyBand);
  }
}
