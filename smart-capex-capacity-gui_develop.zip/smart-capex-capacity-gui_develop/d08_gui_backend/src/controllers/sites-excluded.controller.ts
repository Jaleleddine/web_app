import {authenticate} from '@loopback/authentication';
import {authorize} from '@loopback/authorization';
import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where
} from '@loopback/repository';
import {
  del, get,
  getModelSchemaRef, param,
  patch, post,
  put,
  requestBody,
  response
} from '@loopback/rest';
import {basicAuthorization} from '../middlewares/auth.midd';
import {SitesExluded} from '../models';
import {SitesExludedRepository} from '../repositories';

export class SitesExcludedController {
  constructor(
    @repository(SitesExludedRepository)
    public sitesExludedRepository: SitesExludedRepository,
  ) { }

  @post('/sites-exludeds')
  @response(200, {
    description: 'SitesExluded model instance',
    content: {'application/json': {schema: getModelSchemaRef(SitesExluded)}},
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy'],
    voters: [basicAuthorization],
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(SitesExluded, {
            title: 'NewSitesExluded',

          }),
        },
      },
    })
    sitesExluded: SitesExluded,
  ): Promise<SitesExluded> {
    return this.sitesExludedRepository.create(sitesExluded);
  }

  @get('/sites-exludeds/count')
  @response(200, {
    description: 'SitesExluded model count',
    content: {'application/json': {schema: CountSchema}},
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy'],
    voters: [basicAuthorization],
  })
  async count(
    @param.where(SitesExluded) where?: Where<SitesExluded>,
  ): Promise<Count> {
    return this.sitesExludedRepository.count(where);
  }

  @get('/sites-exludeds')
  @response(200, {
    description: 'Array of SitesExluded model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(SitesExluded, {includeRelations: true}),
        },
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy'],
    voters: [basicAuthorization],
  })
  async find(
    @param.filter(SitesExluded) filter?: Filter<SitesExluded>,
  ): Promise<SitesExluded[]> {
    return this.sitesExludedRepository.find(filter);
  }

  @patch('/sites-exludeds')
  @response(200, {
    description: 'SitesExluded PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy'],
    voters: [basicAuthorization],
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(SitesExluded, {partial: true}),
        },
      },
    })
    sitesExluded: SitesExluded,
    @param.where(SitesExluded) where?: Where<SitesExluded>,
  ): Promise<Count> {
    return this.sitesExludedRepository.updateAll(sitesExluded, where);
  }

  @get('/sites-exludeds/{id}')
  @response(200, {
    description: 'SitesExluded model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(SitesExluded, {includeRelations: true}),
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy'],
    voters: [basicAuthorization],
  })
  async findById(
    @param.path.string('id') id: string,
    @param.filter(SitesExluded, {exclude: 'where'}) filter?: FilterExcludingWhere<SitesExluded>
  ): Promise<SitesExluded> {
    return this.sitesExludedRepository.findById(id, filter);
  }

  @patch('/sites-exludeds/{id}')
  @response(204, {
    description: 'SitesExluded PATCH success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy'],
    voters: [basicAuthorization],
  })
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(SitesExluded, {partial: true}),
        },
      },
    })
    sitesExluded: SitesExluded,
  ): Promise<void> {
    await this.sitesExludedRepository.updateById(id, sitesExluded);
  }

  @put('/sites-exludeds/{id}')
  @response(204, {
    description: 'SitesExluded PUT success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy'],
    voters: [basicAuthorization],
  })
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() sitesExluded: SitesExluded,
  ): Promise<void> {
    await this.sitesExludedRepository.replaceById(id, sitesExluded);
  }

  @del('/sites-exludeds/{id}')
  @response(204, {
    description: 'SitesExluded DELETE success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy'],
    voters: [basicAuthorization],
  })
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.sitesExludedRepository.deleteById(id);
  }
}
