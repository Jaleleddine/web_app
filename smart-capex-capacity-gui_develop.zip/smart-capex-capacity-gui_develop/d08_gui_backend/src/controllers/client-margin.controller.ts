import {authenticate} from '@loopback/authentication';
import {authorize} from '@loopback/authorization';
import {inject} from '@loopback/core';
import {
  Count,
  CountSchema,
  Filter,
  FilterExcludingWhere,
  repository,
  Where
} from '@loopback/repository';
import {
  del, get,
  getModelSchemaRef, param,
  patch, post,
  put,
  requestBody,
  response,
  Response,
  RestBindings
} from '@loopback/rest';
import {basicAuthorization} from '../middlewares/auth.midd';
import {ClientMargin} from '../models';
import {ClientMarginRepository} from '../repositories';

export class ClientMarginController {
  constructor(
    @repository(ClientMarginRepository)
    public clientMarginRepository: ClientMarginRepository,
    @inject(RestBindings.Http.RESPONSE)
    private respo: Response,
  ) { }

  @post('/client-margins')
  @response(200, {
    description: 'ClientMargin model instance',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(ClientMargin),
        },
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'strategy'],
    voters: [basicAuthorization],
  })
  async createAll(
    @requestBody({
      content: {
        'application/json': {
          schema: {
            type: 'array',
            items: getModelSchemaRef(ClientMargin, {includeRelations: true}),
          },
        },
      },
    })
    clientMargins: ClientMargin[],
  ): Promise<ClientMargin[]> {
    // Save many item to the data base
    // build our sql query for multiple insert
    // SMS strategy,ser, admin, validator
    await this.clientMarginRepository.execute('TRUNCATE ClientMargin;');
    // check if data ids are corrects
    const ids = ['A1', 'A2', 'A3', 'B1', 'B2', 'B3', 'B4', 'C1', 'C2', 'C3', 'C4', 'D1', 'D2', 'D3', 'D4', 'E1', 'E2', 'E3', 'E4', 'F1', 'G1', 'G2', 'G3', 'H1', 'H2', 'I1'];
    clientMargins.forEach(item => {
      if (!ids.includes(item.identifiant)) {
        return this.respo.status(400).send({
          message: `Identifiant ${item.identifiant} incorrect`,
          status: 400,
        });
      }
    })
    return this.clientMarginRepository.createAll(clientMargins)
  }


  @get('/client-margins/count')
  @response(200, {
    description: 'ClientMargin model count',
    content: {'application/json': {schema: CountSchema}},
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async count(
    @param.where(ClientMargin) where?: Where<ClientMargin>,
  ): Promise<Count> {
    return this.clientMarginRepository.count(where);
  }

  @get('/client-margins')
  @response(200, {
    description: 'Array of ClientMargin model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(ClientMargin, {includeRelations: true}),
        },
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async find(
    @param.filter(ClientMargin) filter?: Filter<ClientMargin>,
  ): Promise<ClientMargin[]> {
    return this.clientMarginRepository.find(filter);
  }

  @get('/client-margins/{id}')
  @response(200, {
    description: 'ClientMargin model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(ClientMargin, {includeRelations: true}),
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async findById(
    @param.path.string('id') id: string,
    @param.filter(ClientMargin, {exclude: 'where'}) filter?: FilterExcludingWhere<ClientMargin>
  ): Promise<ClientMargin> {
    return this.clientMarginRepository.findById(id, filter);
  }

  @patch('/client-margins/{id}')
  @response(204, {
    description: 'ClientMargin PATCH success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'strategy'],
    voters: [basicAuthorization],
  })
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(ClientMargin, {partial: true}),
        },
      },
    })
    clientMargin: ClientMargin,
  ): Promise<void> {
    await this.clientMarginRepository.updateById(id, clientMargin);
  }

  @put('/client-margins/{id}')
  @response(204, {
    description: 'ClientMargin PUT success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'strategy'],
    voters: [basicAuthorization],
  })
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() clientMargin: ClientMargin,
  ): Promise<void> {
    await this.clientMarginRepository.replaceById(id, clientMargin);
  }

  @del('/client-margins/{id}')
  @response(204, {
    description: 'ClientMargin DELETE success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['admin', 'validator', 'strategy'],
    voters: [basicAuthorization],
  })
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.clientMarginRepository.deleteById(id);
  }
}
