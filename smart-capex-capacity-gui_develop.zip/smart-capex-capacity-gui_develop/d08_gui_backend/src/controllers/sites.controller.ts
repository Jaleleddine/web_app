/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/naming-convention */
/* eslint-disable @typescript-eslint/no-explicit-any */
import {authenticate} from '@loopback/authentication';
import {authorize} from '@loopback/authorization';
import {inject} from '@loopback/core';
import {
  Count, CountSchema,
  Filter,
  FilterExcludingWhere,
  repository, Where
} from '@loopback/repository';
import {
  del, get,
  getModelSchemaRef, param,
  patch, post,
  put,
  Request, requestBody,
  response,
  Response,
  RestBindings
} from '@loopback/rest';
// import {dbConnect} from '../datasources/poolConnect.db';
import {basicAuthorization} from '../middlewares/auth.midd';
import {DfPredictedTrafficKpis, Locations, Sites} from '../models';
import {SitesRepository} from '../repositories';
const z = require("zebras");
const _ = require('lodash');
const moment = require('moment');
/*const mysql = require('mysql')*/
// const stream = require('stream');

export class SitesController {
  constructor(
    @repository(SitesRepository)
    public sitesRepository: SitesRepository,
    @inject(RestBindings.Http.RESPONSE) private respo: Response,
    @inject(RestBindings.Http.REQUEST) private request: Request
  ) {
  }

  @get('/indicateurs/{locationType}/{location}/{periodeType}/{periode}/{periodeEnd}')
  @response(200, {
    description: 'Traffic Forecasting KPIs',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(DfPredictedTrafficKpis, {includeRelations: true}),
        },
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async getForecastingKPIs(
    @param.path.string('locationType') locationType: string,
    @param.path.string('location') location: string,
    @param.path.string('periodeType') periodeType: string,
    @param.path.string('periode') periode: string | number,
    @param.path.string('periodeEnd') periodeEnd: string | number,
  ): Promise<unknown> {
    // Les sites congestionnés
    // periodeType = date | year | week_period
    const sql = periodeType === 'date' ? `SELECT * FROM sites AS a LEFT JOIN df_predicted_traffic_kpis AS b ON a.site_id = b.site_id WHERE a.${locationType} = ? AND (b.${periodeType} >= ? AND b.${periodeType} <= ? );` :
      `SELECT * FROM sites AS a LEFT JOIN df_predicted_traffic_kpis AS b ON a.site_id = b.site_id WHERE a.${locationType} = ? AND (b.${periodeType} >= ? AND b.${periodeType} <= ?);`;
    try {
      const result: any = await this.sitesRepository.execute(sql,
        [location, periode, periodeEnd]);
      // console.log(result.sql);
      const sitesCongestions: any = await this.sitesRepository.execute(`SELECT * FROM Sites_congestion_status`)
      //console.log(sitesCongestions)
      return this.getKPIS(result, periodeType, sitesCongestions);
    } catch (err) {
      // handle the error
      //console.log(err)
    } finally {
      // d'autres actions finales ici
    }
  }

  @get('/all-indicateurs/{periodeType}/{periode}/{periodeEnd}')
  @response(200, {
    description: 'Traffic Forecasting KPIs',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(DfPredictedTrafficKpis, {includeRelations: true}),
        },
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async getALLForecastingKPIs(
    @param.path.string('periodeType') periodeType: string,
    @param.path.string('periode') periode: string | number,
    @param.path.string('periodeEnd') periodeEnd: string | number,
  ): Promise<unknown> {
    // periodeType = date | year | week_period
    const sql = periodeType === 'date' ? `SELECT * FROM sites AS a LEFT JOIN df_predicted_traffic_kpis AS b ON a.site_id = b.site_id WHERE b.${periodeType} >= ? AND b.${periodeType} <= ?;` :
      `SELECT * FROM sites AS a LEFT JOIN df_predicted_traffic_kpis AS b ON a.site_id = b.site_id WHERE b.${periodeType} >= ? AND b.${periodeType} <= ?;`
    try {
      const result: any = await this.sitesRepository.execute(sql,
        [periode, periodeEnd]);
      //console.log(result.slice(0, 1))
      // Les sites congestionnés
      const sitesCongestions: any = await this.sitesRepository.execute(`SELECT * FROM Sites_congestion_status`)
      // console.log(sitesCongestions)
      // return result[0];
      const KPIS = this.getKPIS(result, periodeType, sitesCongestions);
      //console.log(KPIS);
      return this.respo.send(KPIS)
    } catch (err) {
      // handle the error
      console.log(err)
    } finally {
      // d'autres actions finales ici
    }

  }

  // Obtenir les KPIS
  getKPIS(result: any[], periodeType: string, sitesCongestion: any[]) {
    // let GROUPDATA = [];
    let TRAFFICVOICE = [];
    let TRAFFICDATA = [];
    let TRAFFICDATATECH = [];
    let TRAFFICDATABAND = [];
    let TRAFFICVOICETECH = [];
    let TRAFFICVOICEBAND = [];
    let CELLOCCUPATIONBAND = [];
    let CELLOCCUPATIONTECH = [];
    let DEBITBAND = [];
    let DEBITTECH = [];
    // KPIS
    let TRAFICDATA_BEGIN: string | number = 0;
    let TRAFICDATA_END: string | number = 0;
    // TRAFIC VOICE KPI
    let TRAFICVOICE_BEGIN: string | number = 0;
    let TRAFICVOICE_END: string | number = 0;
    let EVOL_TRAFICDATA = 0;
    let EVOL_TRAFICVOICE = 0;
    if (result.length > 0) {
      // Calcul du traffic Data et Voix sur la période
      switch (periodeType) {
        case 'week_period':
          // GROUPDATA = _.groupBy(result, (item: any) => item.week_period);
          TRAFFICVOICE = z.gbSum("total_voice_traffic_kerlands", z.groupBy((d: any) => d.week_period, result));
          TRAFFICVOICETECH = _.groupBy(result, (item: any) => item.week_period);
          TRAFFICVOICEBAND = _.groupBy(result, (item: any) => item.week_period);
          TRAFFICDATA = z.gbSum("total_data_traffic_dl_gb", z.groupBy((d: any) => d.week_period, result));
          TRAFFICDATATECH = _.groupBy(result, (item: any) => item.week_period);
          TRAFFICDATABAND = _.groupBy(result, (item: any) => item.week_period);
          CELLOCCUPATIONBAND = _.groupBy(result, (item: any) => item.week_period);
          CELLOCCUPATIONTECH = _.groupBy(result, (item: any) => item.week_period);
          DEBITBAND = _.groupBy(result, (item: any) => item.week_period);
          DEBITTECH = _.groupBy(result, (item: any) => item.week_period);
          break;
        case 'date':
          // GROUPDATA = _.groupBy(result, (item: any) => moment(item.date).format('YYYY-MM'));
          TRAFFICVOICE = z.gbSum("total_voice_traffic_kerlands", z.groupBy((d: any) => moment(d.date).format('YYYY-MM'), result));
          TRAFFICVOICETECH = _.groupBy(result, (item: any) => moment(item.date).format('YYYY-MM'));
          TRAFFICVOICEBAND = _.groupBy(result, (item: any) => moment(item.date).format('YYYY-MM'));
          TRAFFICDATA = z.gbSum("total_data_traffic_dl_gb", z.groupBy((d: any) => moment(d.date).format('YYYY-MM'), result));
          TRAFFICDATATECH = _.groupBy(result, (item: any) => moment(item.date).format('YYYY-MM'))
          TRAFFICDATABAND = _.groupBy(result, (item: any) => moment(item.date).format('YYYY-MM'));
          CELLOCCUPATIONBAND = _.groupBy(result, (item: any) => moment(item.date).format('YYYY-MM'));
          CELLOCCUPATIONTECH = _.groupBy(result, (item: any) => moment(item.date).format('YYYY-MM'));
          DEBITBAND = _.groupBy(result, (item: any) => moment(item.date).format('YYYY-MM'));
          DEBITTECH = _.groupBy(result, (item: any) => moment(item.date).format('YYYY-MM'));
          break;
        case 'year':
          // GROUPDATA = _.groupBy(result, (item: any) => item.year);
          TRAFFICVOICE = z.gbSum("total_voice_traffic_kerlands", z.groupBy((d: any) => d.year, result));
          TRAFFICVOICETECH = _.groupBy(result, (item: any) => item.year);
          TRAFFICVOICEBAND = _.groupBy(result, (item: any) => item.year);
          TRAFFICDATA = z.gbSum("total_data_traffic_dl_gb", z.groupBy((d: any) => d.year, result));
          TRAFFICDATATECH = _.groupBy(result, (item: any) => item.year);
          TRAFFICDATABAND = _.groupBy(result, (item: any) => item.year);
          CELLOCCUPATIONBAND = _.groupBy(result, (item: any) => item.year);
          CELLOCCUPATIONTECH = _.groupBy(result, (item: any) => item.year);
          DEBITBAND = _.groupBy(result, (item: any) => item.year);
          DEBITTECH = _.groupBy(result, (item: any) => item.year);
          break;
        default:
          break;
      }

      // CALCUL KPIs
      TRAFICDATA_BEGIN = TRAFFICDATA[0]['sum'] ? parseFloat(TRAFFICDATA[0]['sum']).toFixed(2) : 0;
      TRAFICDATA_END = TRAFFICDATA[TRAFFICDATA.length - 1]['sum'] ? parseFloat(TRAFFICDATA[TRAFFICDATA.length - 1]['sum']).toFixed(2) : 0;
      EVOL_TRAFICDATA = (TRAFFICDATA[TRAFFICDATA.length - 1]['sum'] - TRAFFICDATA[0]['sum']) * 100 / TRAFFICDATA[0]['sum'];
      // TRAFIC VOICE KPI
      TRAFICVOICE_BEGIN = TRAFFICVOICE[0]['sum'] ? parseFloat(TRAFFICVOICE[0]['sum']).toFixed(2) : 0;
      TRAFICVOICE_END = TRAFFICVOICE[TRAFFICVOICE.length - 1]['sum'] ? parseFloat(TRAFFICVOICE[TRAFFICVOICE.length - 1]['sum']).toFixed(2) : 0;
      EVOL_TRAFICVOICE = (TRAFFICVOICE[TRAFFICVOICE.length - 1]['sum'] - TRAFFICVOICE[0]['sum']) * 100 / TRAFFICVOICE[0]['sum'];
      // Calcul des stats par BANDs et Technologies
      // TRAFFIC VOICE // prop is the date dimension (week_period, month or year)
      for (const prop in TRAFFICVOICETECH) {
        // console.log(TRAFFICVOICETECH)
        TRAFFICVOICETECH[prop] = z.gbSum("total_voice_traffic_kerlands", z.groupBy((d: any) => d.cell_tech, TRAFFICVOICETECH[prop]));
      }

      for (const prop in TRAFFICVOICEBAND) {
        TRAFFICVOICEBAND[prop] = z.gbSum("total_voice_traffic_kerlands", z.groupBy((d: any) => d.cell_band, TRAFFICVOICEBAND[prop]));
      }

      // TRAFFIC DATA
      for (const prop in TRAFFICDATABAND) {
        TRAFFICDATABAND[prop] = z.gbSum("total_data_traffic_dl_gb", z.groupBy((d: any) => d.cell_band, TRAFFICDATABAND[prop]));
      }

      for (const prop in TRAFFICDATATECH) {
        // console.log(TRAFFICDATATECH)
        TRAFFICDATATECH[prop] = z.gbSum("total_data_traffic_dl_gb", z.groupBy((d: any) => d.cell_tech, TRAFFICDATATECH[prop]));
      }

      // CELL OCCUPATION
      for (const prop in CELLOCCUPATIONTECH) {
        CELLOCCUPATIONTECH[prop] = z.gbMean("cell_occupation_dl_percentage", z.groupBy((d: any) => d.cell_tech, CELLOCCUPATIONTECH[prop]));
      }
      for (const prop in CELLOCCUPATIONBAND) {
        CELLOCCUPATIONBAND[prop] = z.gbMean("cell_occupation_dl_percentage", z.groupBy((d: any) => d.cell_band, CELLOCCUPATIONBAND[prop]));
      }

      // DEBIT
      for (const prop in DEBITTECH) {
        DEBITTECH[prop] = z.gbMean("average_throughput_user_dl_kbps", z.groupBy((d: any) => d.cell_tech, DEBITTECH[prop]));
      }
      for (const prop in DEBITBAND) {
        DEBITBAND[prop] = z.gbMean("average_throughput_user_dl_kbps", z.groupBy((d: any) => d.cell_band, DEBITBAND[prop]));
      }

    }

    // Trouver nos sites faisant partie de la recherche
    const GROUPBYSITES = _.groupBy(result, (item: any) => item.site_id);
    const sites: any[] = [];
    for (const property in GROUPBYSITES) {
      const CELLS = GROUPBYSITES[property];
      const sCongestion = sitesCongestion.filter(item => item.site_id === property); // All sites with congestions
      //const congest = z.gbMean("cell_occupation_dl_percentage", z.groupBy((d: any) => d.site_id, CELLS));
      //const trafficlost = z.gbMax("lost_traffic_kerland", z.groupBy((d: any) => d.site_id, CELLS));

      // If there are site with congestion
      if (sCongestion.length > 0) {
        sCongestion.forEach(sCongest => {
          // We add our site to the list for the GUI
          sites.push({
            latitude: CELLS[0]['site_latitude'],
            longitude: CELLS[0]['site_longitude'],
            //congestion: congest[0].mean,
            //trafficlost: trafficlost[0].max,
            site_id: CELLS[0]['site_id'],
            sitename: CELLS[0]['site_physique'],
            siteville: CELLS[0]['site_ville'],
            sitequartier: CELLS[0]['site_quartier'],
            sitecommune: CELLS[0]['site_commune'],
            sitedepartement: CELLS[0]['site_department'],
            siteregion: CELLS[0]['site_region'],
            sitezone: CELLS[0]['site_zone_commerciale'],
            sitedistrict: CELLS[0]['site_district'],
            sitegestionnaire: CELLS[0]['site_gestionnaire'],
            sitestatus: CELLS[0]['site_status'],
            siteGeotype: CELLS[0]['site_geotype'],
            bandsUpgraded: sCongest.bands_upgraded,
            congestion: sCongest.congestion,
            date: sCongest.date,
            siteTech: sCongest.site_tech,
            techUpgraded: sCongest.tech_upgraded,
            weekPeriod: sCongest.week_period
          }
          );
        })
      } else {
        // We add our site to the list for the GUI / site is not congested
        sites.push({
          latitude: CELLS[0]['site_latitude'],
          longitude: CELLS[0]['site_longitude'],
          //congestion: congest[0].mean,
          //trafficlost: trafficlost[0].max,
          site_id: CELLS[0]['site_id'],
          sitename: CELLS[0]['site_physique'],
          siteville: CELLS[0]['site_ville'],
          sitequartier: CELLS[0]['site_quartier'],
          sitecommune: CELLS[0]['site_commune'],
          sitedepartement: CELLS[0]['site_department'],
          siteregion: CELLS[0]['site_region'],
          sitezone: CELLS[0]['site_zone_commerciale'],
          sitedistrict: CELLS[0]['site_district'],
          sitegestionnaire: CELLS[0]['site_gestionnaire'],
          sitestatus: CELLS[0]['site_status'],
          siteGeotype: CELLS[0]['site_geotype'],
        }
        );
      }

    }
    return {sitesCongestion, nbreResult: result.length, sites, EVOL_TRAFICDATA, EVOL_TRAFICVOICE, TRAFICDATA_BEGIN, TRAFICDATA_END, TRAFICVOICE_BEGIN, TRAFICVOICE_END, TRAFFICVOICE, TRAFFICDATA, TRAFFICDATATECH, TRAFFICDATABAND, TRAFFICVOICETECH, TRAFFICVOICEBAND, CELLOCCUPATIONBAND, CELLOCCUPATIONTECH, DEBITBAND, DEBITTECH};

  }




  @get('/locations')
  @response(200, {
    description: 'Get Locations (villes, communes, quartiers, régions, districts etc...',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Locations, {includeRelations: true}),
        },
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async getLocations(
  ): Promise<Locations> {
    const locations = new Locations;
    const sites = await this.sitesRepository.find();
    if (sites.length > 0) {
      // sites phyqiques
      const orderedBySitesPhysiques = _.groupBy(sites, (item: Sites) => item.sitePhysique);
      locations.sitePhysiques = _.keys(orderedBySitesPhysiques);
      // quartiers
      const orderedByQuartiers = _.groupBy(sites, (item: Sites) => item.siteQuartier);
      locations.quartiers = _.keys(orderedByQuartiers);
      // villes
      const orderedByVilles = _.groupBy(sites, (item: Sites) => item.siteVille);
      locations.villes = _.keys(orderedByVilles);
      // Communes
      const orderedByCommunes = _.groupBy(sites, (item: Sites) => item.siteCommune);
      locations.communes = _.keys(orderedByCommunes);
      // departements
      const orderedByDepartements = _.groupBy(sites, (item: Sites) => item.siteDepartment);
      locations.departements = _.keys(orderedByDepartements);
      // Regions
      const orderedByRegions = _.groupBy(sites, (item: Sites) => item.siteRegion);
      locations.regions = _.keys(orderedByRegions);
      // Districts
      const orderedByDistricts = _.groupBy(sites, (item: Sites) => item.siteDistrict);
      locations.districts = _.keys(orderedByDistricts);
      // Zones Commerciales
      const orderedByZonesCommerciales = _.groupBy(sites, (item: Sites) => item.siteZoneCommerciale);
      locations.zonesCommerciales = _.keys(orderedByZonesCommerciales);

    }

    return locations;
  }

  @post('/sites')
  @response(200, {
    description: 'Sites model instance',
    content: {'application/json': {schema: getModelSchemaRef(Sites)}},
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async create(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Sites, {
            title: 'NewSites',

          }),
        },
      },
    })
    sites: Sites,
  ): Promise<Sites> {
    return this.sitesRepository.create(sites);
  }

  @get('/sites/count')
  @response(200, {
    description: 'Sites model count',
    content: {'application/json': {schema: CountSchema}},
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async count(
    @param.where(Sites) where?: Where<Sites>,
  ): Promise<Count> {
    return this.sitesRepository.count(where);
  }

  @get('/sites')
  @response(200, {
    description: 'Array of Sites model instances',
    content: {
      'application/json': {
        schema: {
          type: 'array',
          items: getModelSchemaRef(Sites, {includeRelations: true}),
        },
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async find(
    @param.filter(Sites) filter?: Filter<Sites>,
  ): Promise<Sites[]> {
    return this.sitesRepository.find(filter);
  }

  @patch('/sites')
  @response(200, {
    description: 'Sites PATCH success count',
    content: {'application/json': {schema: CountSchema}},
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async updateAll(
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Sites, {partial: true}),
        },
      },
    })
    sites: Sites,
    @param.where(Sites) where?: Where<Sites>,
  ): Promise<Count> {
    return this.sitesRepository.updateAll(sites, where);
  }

  @get('/sites/{id}')
  @response(200, {
    description: 'Sites model instance',
    content: {
      'application/json': {
        schema: getModelSchemaRef(Sites, {includeRelations: true}),
      },
    },
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async findById(
    @param.path.string('id') id: string,
    @param.filter(Sites, {exclude: 'where'}) filter?: FilterExcludingWhere<Sites>
  ): Promise<Sites> {
    return this.sitesRepository.findById(id, filter);
  }

  @patch('/sites/{id}')
  @response(204, {
    description: 'Sites PATCH success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async updateById(
    @param.path.string('id') id: string,
    @requestBody({
      content: {
        'application/json': {
          schema: getModelSchemaRef(Sites, {partial: true}),
        },
      },
    })
    sites: Sites,
  ): Promise<void> {
    await this.sitesRepository.updateById(id, sites);
  }

  @put('/sites/{id}')
  @response(204, {
    description: 'Sites PUT success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async replaceById(
    @param.path.string('id') id: string,
    @requestBody() sites: Sites,
  ): Promise<void> {
    await this.sitesRepository.replaceById(id, sites);
  }

  @del('/sites/{id}')
  @response(204, {
    description: 'Sites DELETE success',
  })
  @authenticate('jwt')
  @authorize({
    allowedRoles: ['viewer', 'admin', 'validator', 'editor', 'finance', 'ser', 'strategy', 'modeling', 'marketing'],
    voters: [basicAuthorization],
  })
  async deleteById(@param.path.string('id') id: string): Promise<void> {
    await this.sitesRepository.deleteById(id);
  }
}
