export const UserProfileSchema = {
  type: 'object',
  required: ['id'],
  properties: {
    id: {type: 'string'},
    email: {type: 'string'},
    login: {type: 'string'},
  },
};

export const CredentialsSchema = {
  type: 'object',
  required: ['login', 'password'],
  properties: {
    email: {
      type: 'string',
      format: 'email',
    },
    login: {
      type: 'string',
    },
    password: {
      type: 'string',
      // minLength: 8,
    },
  },
};

export const CredentialsRequestBody = {
  description: 'The input of login function',
  required: true,
  content: {
    'application/json': {schema: CredentialsSchema},
  },
};
