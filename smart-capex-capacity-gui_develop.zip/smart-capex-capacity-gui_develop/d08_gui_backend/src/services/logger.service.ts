import * as winston from 'winston';
const path = require('path');
// eslint-disable-next-line @typescript-eslint/no-unused-vars
// import DailyRotateFile = require('winston-daily-rotate-file');

/*const transport = new DailyRotateFile({
  filename: 'smartcapex-%DATE%.log',
  datePattern: 'YYYY-MM-DD',
  zippedArchive: false,
  dirname: '../SmartCAPEXLogs',
  utc: true,
  maxFiles: '14d'
});
*/
const dir = path.join(__dirname, '../../logs/');
export interface LoggerService {
  logger: object;
}

export class WinstonLoggerService implements LoggerService {
  logger: winston.Logger = winston.createLogger({
    level: 'info',
    exitOnError: false,
    format: winston.format.combine(
      winston.format.timestamp(),
      winston.format.json(),
    ),
    transports: [
      new winston.transports.File({filename: `${dir}error.log`, level: 'error'}),
      new winston.transports.File({filename: `${dir}combined.log`})
    ],
  });
}
