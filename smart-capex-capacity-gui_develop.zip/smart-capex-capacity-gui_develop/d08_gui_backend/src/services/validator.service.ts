import {HttpErrors} from '@loopback/rest';
// import {Credentials} from '../repositories';
import {LoginModel} from '../models';

export function validateCredentials(credentials: LoginModel) {
  // Validate Email
  /*if (!isemail.validate(credentials.email)) {
    throw new HttpErrors.UnprocessableEntity('invalid email');
  }*/

  // Validate Password Length
  if (!credentials.password || credentials.password.length < 8) {
    throw new HttpErrors.UnprocessableEntity(
      'password must be minimum 8 characters',
    );
  }
}
