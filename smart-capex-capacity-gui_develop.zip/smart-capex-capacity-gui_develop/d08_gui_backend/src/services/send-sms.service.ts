const axios = require('axios').default;

export function sendSMS(phonenumber: string, smsContent: string) {
  const uri = `http://10.1.60.190:9802/dispatcher/httpconnectserver/smsaffaires.jsp?UserName=application_smsaffaires_sva&Password=sva&SenderAppId=1&DA=${phonenumber}&SOA=SmartCAPEX&Flags=264192&Content=${smsContent}`;
  axios.get(uri)
    .then(function (response: unknown) {
      // handle success
      // console.log(response);
    })
    .catch(function (error: unknown) {
      // handle error
      console.log(error);
    })
    .then(function () {
      // always executed
    });
}
