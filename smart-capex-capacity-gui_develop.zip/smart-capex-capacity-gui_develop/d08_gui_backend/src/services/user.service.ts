import {UserService} from '@loopback/authentication';
import {inject} from '@loopback/context';
import {repository} from '@loopback/repository';
import {HttpErrors} from '@loopback/rest';
import {securityId, UserProfile} from '@loopback/security';
import {PasswordHasherBindings} from '../keys';
import {LoginModel, User} from '../models';
import {UserRepository} from '../repositories';
import {PasswordHasher} from './hash-password.service';

export class MyUserService implements UserService<User, LoginModel> {
  constructor(
    @repository(UserRepository) public userRepository: UserRepository,
    @inject(PasswordHasherBindings.PASSWORD_HASHER)
    public passwordHasher: PasswordHasher,
  ) {
  }

  async verifyCredentials(credentials: LoginModel): Promise<User> {
    const invalidCredentialsError = 'Mot de passe ou Login Applicatif incorrect.';

    const foundUser = await this.userRepository.findOne({
      where: {uLogin: credentials.login},
    });
    if (!foundUser) {
      throw new HttpErrors.Unauthorized(invalidCredentialsError);
    }

    if (!foundUser.isActive) {
      throw new HttpErrors.Unauthorized('Désolé, votre compte est désactivé.');
    }

    // console.log(authL);

    /*const credentialsFound = await this.userRepository.findCredentials(
      foundUser.id,
    );
    if (!credentialsFound) {
      throw new HttpErrors.Unauthorized(invalidCredentialsError);
    }

    const passwordMatched = await this.passwordHasher.comparePassword(
      credentials.password,
      credentialsFound.password,
    );

    if (!passwordMatched) {
      throw new HttpErrors.Unauthorized(invalidCredentialsError);
    }*/
    return foundUser;
  }

  convertToUserProfile(user: User): UserProfile {
    return {
      [securityId]: user.id,
      id: user.id,
      role: user.role,
      username: user.uLogin,
      name: user.uName,
      firstname: user.firstname
    };
  }
}
