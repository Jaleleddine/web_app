export const environment = {
  production: false, // for OCI PREPROD
  APIEndpoint: 'https://apismartcapex.gtm.ocitnetad.ci/',//'http://10.238.36.25:3000/'//'https://10.240.33.55:443/'
  AEndpoint: 'http://10.238.36.20:5000/'
};
