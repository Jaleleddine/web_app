import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CoverageNpvComponent } from './coverage-npv.component';

describe('CoverageNpvComponent', () => {
  let component: CoverageNpvComponent;
  let fixture: ComponentFixture<CoverageNpvComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CoverageNpvComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CoverageNpvComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
