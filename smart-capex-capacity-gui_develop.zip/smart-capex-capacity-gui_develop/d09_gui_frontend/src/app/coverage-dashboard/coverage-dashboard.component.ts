import { Component, OnInit } from '@angular/core';
import { NgxUiLoaderService } from "ngx-ui-loader";
import { ToastrService } from 'ngx-toastr';
import { BackendService } from '../services/backend.service';
import * as L from 'leaflet';
import 'node_modules/leaflet.tilelayer.colorfilter/src/leaflet-tilelayer-colorfilter.js';
import 'node_modules/leaflet.markercluster/dist/leaflet.markercluster.js';
import { DashboardService } from '../services/dashboard.service';
import { SitesService } from '../services/sites.service';
import { AuthService } from '../services/auth.service';
import { UserService } from '../services/user.service';
import { forkJoin } from 'rxjs';
import * as XLSX from 'xlsx';
//import * as moment from 'moment';
import * as _ from 'lodash';

@Component({
  selector: 'app-coverage-dashboard',
  templateUrl: './coverage-dashboard.component.html',
  styleUrls: ['./coverage-dashboard.component.css']
})
export class CoverageDashboardComponent implements OnInit {

  fr: any;
  user: any;
  token: string;
  isTabOneVisible = true;
  isTabTwoVisible = false;
  legend: any;
  /*************** GRAPHIQUES **************/
  chart: any;
  voixByTechnoChart: any;
  dataByTechnoChart: any;
  dataVSChart: any;
  congestBandChart: any;
  congestTechnoChart: any;
  debitBandChart: any;
  debitTechnoChart: any;
  existing_cells_position = 0;
  new_cells_position

  map: any;
  congestMap: any;
  sites: any[];
  KPIs: any;
  mapLayer: any;
  newMapLayer: any;
  spLayer: any;
  simulLayer: any;
  newSimulLayer: any;
  data: any[]
  /******************** KPIS ***************/
  TRAFICVOICE_BEGIN: string | number = 0;
  TRAFICVOICE_END: string | number = 0;
  TRAFICDATA_BEGIN: string | number = 0;
  TRAFICDATA_END: string | number = 0;
  EVOL_TRAFICVOICE: string | number = 0;
  EVOL_TRAFICDATA: string | number = 0;

  locations: any; // Les différentes localisations (sites, quartiers, villes, communes etc ...)
  currentLocations: any[]; // Le filtre courant sur les localisations
  selectedLocation: string; // La localisation choisie pour le dashboard
  periode: string | number;
  periodeEnd: string | number;
  start: any;
  end: any;
  monthSelected: Date; // Le mois choisi
  weekSelected: Date = new Date(); // La semaine choisie
  weekPeriode: string | number; // La période de la semaine
  periodeType: string; // Le type de période (date, year, week_period)
  locationType: string; // Le type de localisation (site_physique, site_ville, site_quartier, site_commune, site_department, site_region, site_district, site_zone_commerciale)
  yearSelected: string; // L'année choisie
  isWeekSelected = true;
  isMonthSelected = false;
  isYearSelected = false;
  nbreSiteCongested = 0; // Nombre de sites congestionnés
  sitesCongested = []; // sites congestionnés

  //LOCALITY
  sousprefectures!: any[];
  departements!: any[];
  regions!: any[]
  selectedSP: any;

  constructor(
    private userService: UserService,
    private ngxService: NgxUiLoaderService,
    private backendService: BackendService,
    private dashboardService: DashboardService,
    private siteService: SitesService,
    private authService: AuthService,
    private toastr: ToastrService
    ) { }

  ngOnInit(): void {
    this.fr = this.backendService.translateInFrench();
    this.user = this.authService.getUser();
    this.weekPeriode = this.backendService.getWeekPeriod();
    this.heatMap();
     // Get token first and after initial data
     if(this.authService.isProd){
      this.userService.refreshToken().subscribe(data => {
        //console.log(data)
        this.token = data.token;
        this.authService.token.next(data.token)
        // Get initial data
        this.getData();
      }, (err => {
        console.log(err);
        this.toastr.error('Une erreur est survenue pendant le chargement de la page.', '', {
          timeOut: 10000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      }))
    } else {
        this.token = this.authService.getToken();
        this.authService.token.next(this.token)
        // Get initial data
        this.getData();
    }
  }

  // voir les couvertures existantes
  viewExitedCoverages(e){
    const isChecked = e ? e.target.checked : true;
    if(isChecked){
      if(this.mapLayer){
        this.map.addLayer(this.mapLayer);
      }
       if(this.simulLayer){
        this.map.addLayer(this.simulLayer);
      }
    } else {
      if(this.mapLayer){
        this.map.removeLayer(this.mapLayer);
      }
       if(this.simulLayer){
        this.map.removeLayer(this.simulLayer);
      }
    }
  }

  // voir les nouvelles couvertures
  viewNewCoverages(e){
    const isChecked = e ? e.target.checked : true;
    if(isChecked){
      if(this.newMapLayer){
        this.map.addLayer(this.newMapLayer);
      }
      
      if(this.newSimulLayer){
        this.map.addLayer(this.newSimulLayer);
      }
    } else {
      if(this.newMapLayer){
        this.map.removeLayer(this.newMapLayer);
      }     
      if(this.newSimulLayer){
        this.map.removeLayer(this.newSimulLayer);
      }
    }
  }

  // Obtenir les géométries
  getGeometries(){
    forkJoin(
      {
        existedCoverageCells: this.backendService.getExistedCellsCoverage(this.token, this.selectedLocation),
        existedCellsPosition: this.backendService.getExistedCellsPosition(this.token, this.selectedLocation),
        newCoverageCells: this.backendService.getNewCellsCoverage(this.token, this.selectedLocation),
        newCellsPosition: this.backendService.getNewCellsPosition(this.token, this.selectedLocation),
      }
    ).subscribe((data) =>{
      //console.log(this.selectedSP)
      //console.log(data)
      this.spMapping(this.selectedSP?.coordinates.coordinates);
      const existedCellsPosition = data.existedCellsPosition;
      const existedCoverageCells = data.existedCoverageCells;
      const newCoverageCells = data.newCoverageCells;
      const newCellsPosition = data.newCellsPosition;
      
      this.cellMapping(existedCellsPosition, '#FF7900');
      this.simulationMapping(existedCoverageCells, '#50BE87');
      //console.log(existedCoverageCells)
      //
      this.newCellMapping(newCellsPosition, '#FFB400');
      this.newSimulationMapping(newCoverageCells, '#A885D8');
      //console.log(newCoverageCells)

    }, (error)=> console.log(error))
  }

  // Get loca
  getLocationData(){
    this.backendService.getGeometries(this.token, this.selectedLocation).subscribe((data)=> {
      console.log(data)
      const coordinates = data[0]?.sous_prefecture_coordinates;
      const existedCoverageCells = data[0]?.existing_cells_coverage;
      const existedCellsPosition = data[0]?.existing_cells_position;
      this.existing_cells_position =data[0]?.existing_cells_position.length;
      const newCoverageCells = data[0]?.new_cells_coverage;
      const newCellsPosition = data[0]?.new_cells_position;
      this.new_cells_position = data[0]?.new_cells_position.length;
      this.selectedSP =  _.omit(data[0], ['existing_cells_coverage', 'existing_cells_position', 'new_cells_coverage', 'new_cells_position']);
     
      this.spMapping(coordinates?.coordinates);
      this.cellMapping(existedCellsPosition, '#FF7900');
      this.simulationMapping(existedCoverageCells, '#50BE87');
      //console.log(existedCoverageCells)
      //
      this.newCellMapping(newCellsPosition, '#FFB400');
      this.newSimulationMapping(newCoverageCells, '#A885D8');
      
      //console.log(this.selectedSP)
    }, (error)=> console.log(error))
  }

  // Reset search data
  resetData(){

  }

  scrollToFixed(){
    // Get the header
  const header = document.getElementById("filter");
// Get the offset position of the navbar
  const sticky = header.offsetTop;

// Add the sticky class to the header when you reach its scroll position. Remove "sticky" when you leave the scroll position
  if (window.pageYOffset > sticky) {
      header.classList.add("fix");
  } else {
      header.classList.remove("fix");
    }
}


  exportToExcel(data: any[]): void {
    console.log(data);
   const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(data);
   const wb: XLSX.WorkBook = XLSX.utils.book_new();
   XLSX.utils.book_append_sheet(wb, ws, 'SITES_CONGESTIONNES');
   XLSX.writeFile(wb, 'SITES_CONGESTIONNES.xlsx');
}
// Choisir la période de recherche
togglePeriode(periode: string){
  switch (periode) {
    case 'week':
      this.isWeekSelected = true;
      this.isMonthSelected = false;
      this.isYearSelected = false;
      this.periodeType = 'week_period';
      break;
    case 'month':
      this.isWeekSelected = false;
      this.isMonthSelected = true;
      this.isYearSelected = false;
      this.periodeType = 'date';
      break;
    case 'year':
      this.isWeekSelected = false;
      this.isMonthSelected = false;
      this.isYearSelected = true;
      this.periodeType = 'year';
      break;
    default:
      break;
  }
}

// Charger nos données
getData(){
  //this.getLocations();
  this.getInitialData()
}


  getLocations(){
    this.dashboardService.getLocations(this.token).subscribe(data => {
      console.log(data);
      this.locations = data;
    }, (err) => {
      console.log(err);
      this.toastr.error('Une erreur est survenue pendant le chargement des localisations', '', {
        timeOut: 10000,
        closeButton: true,
        positionClass: 'toast-top-center',
        progressBar: true,
      });
    })
  }

  getColor(congestion) {
    let color = '';
    if (congestion === undefined) {
      color = '#50BE87';
    } else {
      color = '#CD3C14';
    }
    return color;
  }

  simulationMapping(data: any[], color: string) {
   //console.log(data)
    if (data.length > 0) {
        // Créer notre layer
        const layerGrp = new L.LayerGroup();
         data.forEach(feat => {
          //const coords = feat?.coordinates;
           const coordinates = feat?.coordinates?.coordinates;

           if(coordinates != null){
            const polygon = L.polygon(coordinates, {color: color,fillOpacity: 0.01});
            polygon.bindTooltip(`
            <div style="background:#FFF">
            <div style="color:#000;text-align: center;font-size: 14px;margin:0px auto;">
            ${feat?.cell_name}
            </div>
            <table class="tooltip-table">
              <tr>
                <td>Nom Cellule:</td>
                <td>${feat?.cell_name}</td>
              </tr>
            </table>
            </div>
            `, {className: 'tooltip'});
            layerGrp.addLayer(polygon)
           }
         })
          // On supprime une éventuelle couche sur la carte
        if (this.simulLayer) {
          this.map.removeLayer(this.simulLayer);
        }
        this.simulLayer = layerGrp;
        this.map.addLayer(this.simulLayer)
    }
  }


  newSimulationMapping(data: any[], color: string) {
    if (data.length > 0) {
        // Créer notre layer
        const layerGrp = new L.LayerGroup();
         // Positionner le quad sur la carte
         data.forEach(feat => {
           //const coords = feat?.coordinates;
           const coordinates = feat?.coordinates?.coordinates;
           //console.log(coordinates)
           if(coordinates){
            const polygon = L.polygon(coordinates, {color: color,fillOpacity: 0.01});
            polygon.bindTooltip(`
            <div style="background:#FFF">
            <div style="color:#000;text-align: center;font-size: 14px;margin:0px auto;">
            ${feat?.cell_name}
            </div>
            <table class="tooltip-table">
              <tr>
                <td>Nom Cellule:</td>
                <td>${feat?.cell_name}</td>
              </tr>
            </table>
            </div>
            `, {className: 'tooltip'});
            layerGrp.addLayer(polygon)
           }
         })

         // On supprime une éventuelle couche sur la carte
        if (this.newSimulLayer) {
          this.map.removeLayer(this.newSimulLayer);
        }
        this.newSimulLayer = layerGrp;
        this.map.addLayer(this.newSimulLayer)
    }
  }

  spMapping(data: any[]) {
    //console.log(data)
    if (data.length > 0) {
         // Positionner le quad sur la carte
         const polygon = L.polygon(data, {color: '#4BB4E6',fillOpacity: 0.1});
         polygon.bindPopup(`
            <div style="background:#FFF">
            <div style="color:#000;text-align: center;font-size: 14px;margin:0px auto;">
            ${this.selectedSP?.sous_prefecture_name}
            </div>
            <table class="tooltip-table">
              <tr>
                <td>Région:</td>
                <td>${this.selectedSP?.region}</td>
              </tr>
              <tr>
                <td>Département:</td>
                <td>${this.selectedSP?.departement}</td>
              </tr>
              <tr>
                <td>Zone Commerciale:</td>
                <td>${this.selectedSP?.zone_commerciale}</td>
              </tr>
              <tr>
                <td>Population Couverte:</td>
                <td>${parseFloat(this.selectedSP?.population_covered).toFixed(0)}</td>
              </tr>
              
            </table>
            </div>
            `, {className: 'tooltip'});
         polygon.bindTooltip(`
            <div style="background:#FFF">
            <div style="color:#000;text-align: center;font-size: 14px;margin:0px auto;">
            ${this.selectedSP?.sous_prefecture_name}
            </div>
            <table class="tooltip-table">
              <tr>
                <td>Région:</td>
                <td>${this.selectedSP?.region}</td>
              </tr>
              <tr>
                <td>Département:</td>
                <td>${this.selectedSP?.departement}</td>
              </tr>
              <tr>
                <td>Zone Commerciale:</td>
                <td>${this.selectedSP?.zone_commerciale}</td>
              </tr>
              <tr>
                <td>Population Couverte:</td>
                <td>${parseFloat(this.selectedSP?.population_covered).toFixed(2)}</td>
              </tr>
              
            </table>
            </div>
            `, {className: 'tooltip'});
      // On supprime une éventuelle couche sur la carte
      if (this.spLayer) {
        this.map.removeLayer(this.spLayer);
      }
     // this.map.removeLayer(this.mapLayer);
     this.spLayer = polygon;
     this.map.addLayer(this.spLayer);
     this.map.fitBounds(polygon.getBounds());
    }
  }

  cellMapping(data: any[], color: string) {
    if (data.length > 0) {
      const markersCluster = new (L as any).MarkerClusterGroup(); // Un groupe de marker
  
      data.forEach(site => {
        const coordinates = site.coordinates?.coordinates
        if (coordinates) {
          // Classifier les sites par des couleurs (Les couleurs affichées sur la carte)
          //const color = this.getColor(site.congestion);
          const Dicon = L.divIcon({
              className: 'custom-div-icon',
              html: `<div style='background-color:${color};
              'class='marker-pin'><i class=""></i></div>`,
              iconSize: [30, 42],
              iconAnchor: [15, 42]
          });
            // Positionner le site sur la carte
          const marker = L.marker([coordinates[0], coordinates[1]], {icon: Dicon});
  
          marker.bindTooltip(`
              <div style="background:#FFF">
              <div style="color:#000;text-align: center;font-size: 14px;margin:0px auto;">
              ${site?.cell_name}
              </div>
              <table class="tooltip-table">
                <tr>
                  <td>Nom Cellule:</td>
                  <td>${site?.cell_name}</td>
                </tr>
                
              </table>
              </div>
              `, {className: 'tooltip'});
  
            markersCluster.addLayer(marker);
              // Ajout du site à sa catégorie
            }
      });
  
      // On suprrime une éventuelle couche sur la carte
      if (this.mapLayer) {
        this.map.removeLayer(this.mapLayer);
      }
     // this.map.removeLayer(this.mapLayer);
     this.mapLayer = markersCluster;
     this.map.addLayer(this.mapLayer);
  
    }
  }


  newCellMapping(data: any[], color: string) {
    if (data.length > 0) {
      const markersCluster = new (L as any).MarkerClusterGroup(); // Un groupe de marker
  
      data.forEach(site => {
        const coordinates = site.coordinates?.coordinates
        if (coordinates) {
          // Classifier les sites par des couleurs (Les couleurs affichées sur la carte)
          //const color = this.getColor(site.congestion);
          const Dicon = L.divIcon({
              className: 'custom-div-icon',
              html: `<div style='background-color:${color};
              'class='marker-pin'><i class=""></i></div>`,
              iconSize: [30, 42],
              iconAnchor: [15, 42]
          });
  
          /*const lat = site.site_latitude.replace(',', '.');
          const long = site.site_longitude.replace(',', '.');*/
            // Positionner le site sur la carte
          const marker = L.marker([coordinates[0], coordinates[1]], {icon: Dicon});
  
          marker.bindTooltip(`
              <div style="background:#FFF">
              <div style="color:#000;text-align: center;font-size: 14px;margin:0px auto;">
              ${site?.cell_name}
              </div>
              <table class="tooltip-table">
                <tr>
                  <td>Nom Cellule:</td>
                  <td>${site?.cell_name}</td>
                </tr>
                
              </table>
              </div>
              `, {className: 'tooltip'});
  
            markersCluster.addLayer(marker);
              // Ajout du site à sa catégorie
            }
      });
  
      // On suprrime une éventuelle couche sur la carte
      if (this.newMapLayer) {
        this.map.removeLayer(this.newMapLayer);
      }
     // this.map.removeLayer(this.mapLayer);
     this.newMapLayer = markersCluster;
     this.map.addLayer(this.newMapLayer);
  
    }
  }

  drawLegend() {
    // <span><i style="background:#2ca961;color:#2ca961;">color</i> SANS DÉPHASAGE<span/> <br/> <br/>
    // Création de légende
   return `
    <span>[ LÉGENDE ]<span/> <br/><br/>
    <span><i style="background:#50BE87;color:#50BE87;display:inline-block;width: 15px;height: 15px;border-radius: 0%;"></i> COUVERTURE EXISTANTE <span/><br/>
    <span><i style="background:#A885D8;color:#A885D8;display:inline-block;width: 15px;height: 15px;border-radius: 0%;"></i> NOUVELLE COUVERTURE <span/><br/>
     
    <span><i style="background:#FF7900;color:#FF7900;display:inline-block;width: 15px;height: 15px;border-radius: 0%;"></i> CELLULE EXISTANTE <span/><br/>
    <span><i style="background:#FFB400;color:#FFB400;display:inline-block;width: 15px;height: 15px;border-radius: 0%;"></i> NOUVELLE CELLULE <span/><br/>
   
    `;
  }
  

  heatMap(site?): void{
    // this.ngxService.start();
    if (!this.map){
      this.map = L.map('map', { zoomControl: false }).setView([this.backendService.latitude, this.backendService.longitude], 6);
      (L.tileLayer as any).colorFilter(this.backendService.tileUrl, {
    minZoom: 5,
    maxZoom: 20,
    // filter: ['grayscale:100%', 'invert:0%']
    }).addTo(this.map);
     // Positionner le zoom panel
      new L.Control.Zoom({ position: 'bottomleft' }).addTo(this.map);
      // Positionner la légende
      const div = L.DomUtil.create('div', 'info legend');
      div.innerHTML += this.drawLegend();
      this.legend = L.Control.extend({
              options: {
                position: 'bottomright'
                // control position - allowed: 'topleft', 'topright', 'bottomleft', 'bottomright'
              },
              onAdd(map) {
                return div;
              },
            });
      this.map.addControl(new this.legend());
      L.control.scale({position: 'topright'}).addTo(this.map);
      // Le découpage commercial
      this.initDecoupageCommercial(this.map);
    }
  }

  // Rechercher les géométries d'une sous-prefecture
 search(){
  this.selectedSP = this.sousprefectures.find(sp => sp.sous_prefecture_name == this.selectedLocation);
  this.getGeometries()
 }

  getInitialData(){
    this.backendService.getSousPrefectures(this.token).subscribe((sP)=> {
      //console.log(sP);
      //console.log(sP[0].coordinates)
      this.sousprefectures = sP;
      this.selectedLocation = sP[0].sous_prefecture_name;
      this.selectedSP = sP[0];
      // Get the simulation
      //this.getLocationData();
      this.getGeometries()
    }, (error) => {console.log(error)})
  }

  onEachFeature(feature, layer): void {
    // console.log('count');
    // does this feature have a property named popupContent?
    // feature.properties.QUARTIER && feature.properties.COMMUNE
    if (feature.properties.ZC) {
        layer.
        bindTooltip(`
            <div style="background:#FFF">
            <div style="color:#000;text-align: center;font-weight: bold;font-size: 14px;margin:0px auto;">
            ${feature.properties.ZC}
            </div>

            <table class="tooltip-table">
              <tr>
                <td>${feature.properties.Superf} KM²</td>
              </tr>
            </table>
            </div>
            `, {className: 'small-tooltip'});
        }
  }

  initDecoupageCommercial(map): void {
    const colors = ['#085EBD', '#0A6E31', '#FF8AD4', '#FFB400', '#492191', '#595959', '#000000', '#4BB4E6', '#A885D8',
  '#FF7900', '#62342D', '#FFD200', '#FFF6B6', '#880E4F', '#FFAB91'];
    this.backendService.getZoneCommerciale().subscribe((zones) => {
      zones.features.forEach((feacture, index) => {
        feacture.properties.index = index;
      });
      console.log(zones);
      L.geoJSON(zones, {
        style: (feature) => {
            return {color: colors[feature.properties.index], weight: 0.3, opacity: 0.3,fillOpacity: 0.1};
        },
        onEachFeature: this.onEachFeature
    }).addTo(map);
    });
  }




}
