import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
//import * as $ from 'jquery';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { BackendService } from '../services/backend.service';
import { AuthService } from '../services/auth.service';
import { UserService } from '../services/user.service'
import { PlanificationsService } from '../services/planifications.service';
import * as _ from 'lodash';
//import { forkJoin, zip} from 'rxjs';
import * as echarts from 'echarts';
import * as L from 'leaflet';
import 'node_modules/leaflet.tilelayer.colorfilter/src/leaflet-tilelayer-colorfilter.js';
import * as XLSX from 'xlsx';
import { SitesService } from '../services/sites.service';


@Component({
  selector: 'app-result-planif',
  templateUrl: './result-planif.component.html',
  styleUrls: ['./result-planif.component.css']
})
export class ResultPlanifComponent implements OnInit {

  p =1;
  data: any[];
  dataForTable: any[]
  item: any;
  title = '';
  isUpdate = false;
  macarte: any;
  token = '';
  sites: any[];
  user: any;
  fr: any;
  npvChart: any;
  siteMarker: any;
  planificationName = ''; // Le nom de la plannification courante
  totalCAPEX = 0; // Le total des capex de la plannification
  budget = 0; // Le budget de la planification
  EBITDA = 0; //L'EBITDA
  IRR = 0; // L'IRR
  NPV = 0;
  gNPVChart: any // Le graphique du npv global

  constructor(
    private backendService: BackendService,
    private ngxService: NgxUiLoaderService,
    private toastr: ToastrService,
    private route: ActivatedRoute,
    private router: Router,
    private authService: AuthService,
    private planifService: PlanificationsService,
    private siteService: SitesService,
    private userService: UserService
  ) { }

  ngOnInit(): void {
    // Get token first and after initial data
    if(this.authService.isProd){
      this.userService.refreshToken().subscribe(data => {
      this.token = data.token;
      this.authService.token.next(data.token)
      this.getPlannificationExecResult();
      this.getSites();
      }, (err => {
        console.log(err);
        this.toastr.error('Une erreur est survenue pendant le chargement de la page.', '', {
          timeOut: 10000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      }))
    } else {
        this.token = this.authService.getToken();
        this.authService.token.next(this.token)
        // Get initial data
        this.getPlannificationExecResult();
        this.getSites();
    }
  }

  exportToExcel(data: any[]): void {
    //console.log(data);
   const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(data);
   // const wsDetails: XLSX.WorkSheet = XLSX.utils.json_to_sheet(details);
   const wb: XLSX.WorkBook = XLSX.utils.book_new();
   XLSX.utils.book_append_sheet(wb, ws, 'PLANIFICATION_RESULT');
   XLSX.writeFile(wb, 'PLANIFICATION_RESULT.xlsx');
}

getSites(){
  this.siteService.getItems(this.token).subscribe(data => {
    this.sites = data;
    console.log(this.sites);
  }, (err) => {
    console.log(err);
    this.toastr.error('Une erreur est survenue pendant le chargement des sites', '', {
      timeOut: 10000,
      closeButton: true,
      positionClass: 'toast-top-center',
      progressBar: true,
    });
  })
}

  getPlannificationExecResult(){
    const id = this.route.snapshot.paramMap.get('id');
    console.log(id);
    this.planifService.getPlanificationExecutionResult(id,this.token).subscribe(data => {
      /*console.log(data)
      this.data = data;
      this.planificationName = data[0].name; // Le nom de la planification
      this.budget = data[0].budget;
      
      // Calcul du CAPEX
      this.totalCAPEX = Math.abs(_.sumBy(data, function(o) { return parseFloat(o.cash_flow_year_0); }));
      this.EBITDA = _.sumBy(data, function(o) { if(o.EBITDAT_Value !== null){return parseFloat(o.EBITDA_Value)}; });
      this.IRR = _.meanBy(data, function(o) { if(o.IRR_TOTAL !== null){return parseFloat(o.IRR_TOTAL)}; })*100;
    
      // console.log(this.totalCAPEX);
      // Caster nos npv en nombre valeur partielle*100/valeur totale
      this.data.forEach(item => {
        item.npv = item.npv == null ? 0: parseFloat(parseFloat(item.npv).toFixed(2)) ;
        item.cash_flow_year_0 = parseFloat(item.cash_flow_year_0).toFixed(2);
        item.cash_flow_year_1 = parseFloat(item.cash_flow_year_1).toFixed(2);
        item.cash_flow_year_2 = parseFloat(item.cash_flow_year_2).toFixed(2);
        item.cash_flow_year_3 = parseFloat(item.cash_flow_year_3).toFixed(2);
        item.cash_flow_year_4 = parseFloat(item.cash_flow_year_4).toFixed(2);
        item.cash_flow_year_5 = parseFloat(item.cash_flow_year_5).toFixed(2);
        item.cash_flow_year_6 = item.cash_flow_year_6 == 'NA' ? 0 : parseFloat(item.cash_flow_year_6).toFixed(2)
      });
      this.NPV = _.sumBy(data, function(o) { if(o.npv !== null){return parseFloat(o.npv)}; });
      // Ordonner nos résultats
      this.data = _.orderBy(this.data, 'npv', 'desc');
    
      this.dataForTable = this.data;
      // Construction de notre courbe d'évolution
      this.globalNPVChart(this.data, data[0].name);
      console.log(this.data);*/
       //this.data = data;
       console.log(data)
       this.planificationName = data[0].name; // Le nom de la planification
       this.budget = data[0].budget;
       
       // Caster nos npv en nombre
       let finalData = [];
       let capex = 0;
       const budget = data[0].budget ? parseFloat(data[0].budget) : 0;
 
       // caster nos données
       data.forEach(item => {
         item.npv = item.npv == null ? 0: parseFloat(parseFloat(item.npv).toFixed(2));
         item.cash_flow_year_0 = parseFloat(item.cash_flow_year_0).toFixed(2);
         item.cash_flow_year_1 = parseFloat(item.cash_flow_year_1).toFixed(2);
         item.cash_flow_year_2 = parseFloat(item.cash_flow_year_2).toFixed(2);
         item.cash_flow_year_3 = parseFloat(item.cash_flow_year_3).toFixed(2);
         item.cash_flow_year_4 = parseFloat(item.cash_flow_year_4).toFixed(2);
         item.cash_flow_year_5 = parseFloat(item.cash_flow_year_5).toFixed(2);
         item.cash_flow_year_6 = item.cash_flow_year_6 == 'NA' ? 0 : parseFloat(item.cash_flow_year_6).toFixed(2)  
       });
       // Ordonner nos résultats
       this.data = _.orderBy(data, 'npv', 'desc');
       // si le budget a été renseigné dans la planification
       //console.log(budget)
       console.log(this.data)
       if(budget > 0){
         this.data.every(item => {
           // nous cumulons les capex
           capex += Math.abs(parseFloat(item.cash_flow_year_0));
           //console.log(capex)
           // si le budget est inférieur au cumul du capex de chaque action, nous la prenons en compte
           if(capex <= budget){
             // nous prenons cette actions en compte
             finalData.push(item)
             //we return true the loop continue
             return true;
           } else {
             return false;
           } 
         });
       } else {
           finalData = this.data;
       }
     
       // our final data
       this.dataForTable = finalData;
       this.data = finalData;
       // select only actions with capex <= plnaifications budget
        // Calcul du CAPEX
        this.totalCAPEX = Math.abs(_.sumBy(finalData, function(o) { return parseFloat(o.cash_flow_year_0); }));
        this.EBITDA = _.sumBy(finalData, function(o) { if(o.EBITDAT_Value !== null){return parseFloat(o.EBITDA_Value)}; });
        this.IRR = _.meanBy(finalData, function(o) { if(!isNaN(o.IRR_TOTAL)){return parseFloat(o.IRR_TOTAL)}; })*100;
        this.NPV = _.sumBy(finalData, function(o) { if(!isNaN(o.npv)){return parseFloat(o.npv)}; });
       // Construction de notre courbe d'évolution
       this.globalNPVChart(finalData, data[0].name);
    }, (error) => {console.log(error)})
  }

  close(){
    document.getElementById("myModal").style.display = "none";
  }

  closeCompare(){
    document.getElementById("compareModal").style.display = "none";
  }

  globalFilter(value: any): any {
    if (!value) {
      this.dataForTable = this.data;
    } else {
      this.dataForTable = this.data.filter((val) => {
        const rVal = (
          val.site_id.includes(value) || val.cell_band.includes(value)
         );
        return rVal;
      });
    }
  }

  heatMap(site?): void{
    // this.ngxService.start();
    if (!this.macarte){
      this.macarte = L.map('macarte', { zoomControl: false }).setView([this.backendService.latitude, this.backendService.longitude], 6);
      (L.tileLayer as any).colorFilter(this.backendService.tileUrl, {
    minZoom: 5,
    maxZoom: 20,
    // filter: ['grayscale:100%', 'invert:0%']
    }).addTo(this.macarte);
     // Positionner le zoom panel
      new L.Control.Zoom({ position: 'bottomleft' }).addTo(this.macarte);
      // Le découpage commercial
      this.initDecoupageCommercial(this.macarte);
    }
  }

  onEachFeature(feature, layer): void {
    // console.log('count');
    // does this feature have a property named popupContent?
    // feature.properties.QUARTIER && feature.properties.COMMUNE
    if (feature.properties.ZC) {
        layer.
        bindTooltip(`
            <div style="background:#FFF">
            <div style="color:#000;text-align: center;font-weight: bold;font-size: 14px;margin:0px auto;">
            ${feature.properties.ZC}
            </div>

            <table class="tooltip-table">
              <tr>
                <td>${feature.properties.Superf} KM²</td>
              </tr>
            </table>
            </div>
            `, {className: 'small-tooltip'});
        }
  }

  initDecoupageCommercial(map): void {
    const colors = ['#085EBD', '#0A6E31', '#FF8AD4', '#FFB400', '#492191', '#595959', '#000000', '#4BB4E6', '#A885D8',
  '#FF7900', '#62342D', '#FFD200', '#FFF6B6', '#880E4F', '#FFAB91'];
    this.backendService.getZoneCommerciale().subscribe((zones) => {
      zones.features.forEach((feacture, index) => {
        feacture.properties.index = index;
      });
      console.log(zones);
      L.geoJSON(zones, {
        style: (feature) => {
            return {color: colors[feature.properties.index], weight: 0.3, opacity: 0.3,fillOpacity: 0.1};
        },
        onEachFeature: this.onEachFeature
    }).addTo(map);
    });
  }

  showDetails(result?){
    console.log(result);
    this.item = result;
    document.getElementById("myModal").style.display='block';
    this.heatMap();
    // Rechercher tous les résultats concernant le site
    const datas = this.data.filter(item => item.site_id == result.site_id);
    console.log(datas);
    // On crée notre courbe d'évolution
    this.evolCashFlow(datas);
    // Search siteLocation
    const siteLocated = this.sites.filter(item => item.siteId == result.site_id);
    console.log(siteLocated[0]);
    if(siteLocated.length > 0){
      // Supprimer un ancien site positionné
      if(this.siteMarker){
        this.macarte.removeLayer(this.siteMarker)
      }
      const Dicon = L.divIcon({
        className: 'custom-div-icon',
        html: `<div style='background-color:#FF7900;
        'class='marker-pin'><i class=""></i></div>`,
        iconSize: [30, 42],
        iconAnchor: [15, 42]
    });
      const site = siteLocated[0];
      this.siteMarker = L.marker([site.siteLatitude, site.siteLongitude], {icon: Dicon}).addTo(this.macarte); 
      this.siteMarker.bindTooltip(`
      <div style="background:#FFF">
      <div style="color:#000;text-align: center;font-size: 14px;margin:0px auto;">
      ${site.siteId} | ${site.sitePhysique}
      </div>
      <table class="tooltip-table">
        <tr>
          <td>Geo Type:</td>
          <td>${site.siteGeotype}</td>
        </tr>
        <tr>
          <td>Type Baie:</td>
          <td>${site.siteTypeBaie}</td>
        </tr>
        <tr>
          <td>Zone Commerciale:</td>
          <td>${site.siteZoneCommerciale}</td>
        </tr>
        <tr>
          <td>Site Gestionnaire:</td>
          <td>${site.siteGestionnaire}</td>
        </tr>
        <tr>
          <td>District:</td>
          <td>${site.siteDistrict}</td>
        </tr>
        <tr>
          <td>Région:</td>
          <td>${site.siteRegion}</td>
        </tr>
        <tr>
          <td>Département:</td>
          <td>${site.siteDepartment}</td>
        </tr>
        <tr>
          <td>Ville:</td>
          <td>${site.siteVille}</td>
        </tr>
        <tr>
          <td>Commune:</td>
          <td>${site.siteCommune}</td>
        </tr>
        <tr>
          <td>Quartier:</td>
          <td>${site.siteQuartier}</td>
        </tr>
        <tr>
          <td>Status:</td>
          <td>${site.siteStatus}</td>
        </tr>
      </table>
      </div>
      `, {className: 'tooltip'});
    }
  }

  globalNPVChart(data: any[], name: string){
    if(!this.gNPVChart){
      this.gNPVChart = echarts.init(document.getElementById('evol-globalnpv'));
    }
    const yVALUES = [];
    const xAXIS = [];
    let dataset: any[] = data;
    // dataset.forEach(item => {item.npv = parseFloat(item.npv)});
    // Ordonner nos npv
    dataset = _.orderBy(dataset, 'npv', 'desc');
    // console.log(dataset)
    // Calculer nos NPV par actions cumulées
    for (let i = 0; i < dataset.length; i = i+10) {
      const actions = dataset.filter((item, index) => index <= i ); // Les elements de i à i+10
      // console.log(i);
      // console.log(actions);
      if(actions.length > 0){
        let npv  = _.sumBy(actions, 'npv');
        npv = npv/1000000;
        yVALUES.push(parseFloat(npv).toFixed(2));
        xAXIS.push(i);
      }
      
    } 

    // console.log(yVALUES);
    // Le cumul de tous les npv; nous les ajoutons pour avoir le cumul total de toutes les actions
    let npv  = _.sumBy(dataset, 'npv');
    npv = npv/1000000;
    yVALUES.push(parseFloat(npv).toFixed(2));
    xAXIS.push(dataset.length);
    
    const option = {
      title:{
        text: 'Évolution NPV par nombre d\'actions',
      },
      xAxis: {
          type: 'category',
          data: xAXIS,
          name: 'Nombre d\'actions',
          nameLocation: 'end'
      },
      legend:{
        bottom: 0
      },
      tooltip:{
        trigger: 'axis'
      },
      grid: {
        right: '20%'
      },
      yAxis: {
          type: 'value',
          name: 'NPV cumulé (Millions XOF)'
      },
      series: {
        data: yVALUES,
        type: 'line',
        name: 'NPV' + ' ' + name,
        smooth: true,
        showSymbol: false,
        itemStyle:{
          color: '#FF7900'
        }
      }
  };
  
    // use configuration item and data specified to show chart
    this.gNPVChart.setOption(option);
  }

  evolCashFlow(data: any[]){
    if(!this.npvChart){
      this.npvChart = echarts.init(document.getElementById('cashflowchart'));
    }
    const series = [];
    const colors = ['#FF7900', '#4BB4E6', '#50BE87', '#A885D8', '#FFD200', '#0000'];
    data.forEach((item, index) => {
      // Si le cashFlow de l'année 6 est égal à 0 alors on le supprime du graphe
      if(item.cash_flow_year_6 == 0){
        series.push({
          data: [(parseFloat(item.cash_flow_year_0)/1000000).toFixed(2), (parseFloat(item.cash_flow_year_1)/1000000).toFixed(2), (parseFloat(item.cash_flow_year_2)/1000000).toFixed(2),
            (parseFloat(item.cash_flow_year_3)/1000000).toFixed(2), (parseFloat(item.cash_flow_year_4)/1000000).toFixed(2), (parseFloat(item.cash_flow_year_5)/1000000).toFixed(2)],
          type: 'line',
          name: item.site_id + '-' + item.cell_band,
          smooth: true,
          itemStyle:{
            color: colors[index]
          }
      })
      } else {
        series.push({
          data: [(parseFloat(item.cash_flow_year_0)/1000000).toFixed(2), (parseFloat(item.cash_flow_year_1)/1000000).toFixed(2), (parseFloat(item.cash_flow_year_2)/1000000).toFixed(2),
            (parseFloat(item.cash_flow_year_3)/1000000).toFixed(2), (parseFloat(item.cash_flow_year_4)/1000000).toFixed(2), (parseFloat(item.cash_flow_year_5)/1000000).toFixed(2), (parseFloat(item.cash_flow_year_6)/1000000)],
          type: 'line',
          name: item.site_id + '-' + item.cell_band,
          smooth: true,
          itemStyle:{
            color: colors[index]
          }
      })

      }
    });
    const option = {
      title:{
        text: 'Évolution CashFlow par année',
      },
      xAxis: {
          type: 'category',
          data: ['Annee 0', 'Annee 1', 'Annee 2', 'Annee 3', 'Annee 4', 'Annee 5', 'Annee 6'],
          name: 'Période',
          nameLocation: 'end'
      },
      legend:{
        bottom: 0
      },
      tooltip:{
        trigger: 'axis'
      },
      grid: {
        right: '20%'
      },
      yAxis: {
          type: 'value',
          name: 'CashFlow (Millions XOF)'
      },
      series
  };
  
    // use configuration item and data specified to show chart
    this.npvChart.setOption(option);
  }


}
