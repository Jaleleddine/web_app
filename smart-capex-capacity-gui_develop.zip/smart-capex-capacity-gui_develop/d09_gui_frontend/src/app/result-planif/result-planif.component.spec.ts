import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ResultPlanifComponent } from './result-planif.component';

describe('ResultPlanifComponent', () => {
  let component: ResultPlanifComponent;
  let fixture: ComponentFixture<ResultPlanifComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ResultPlanifComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ResultPlanifComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
