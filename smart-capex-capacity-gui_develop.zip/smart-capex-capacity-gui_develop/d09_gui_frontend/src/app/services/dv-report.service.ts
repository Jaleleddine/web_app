import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthService } from './auth.service';


@Injectable({
  providedIn: 'root'
})
export class DvReportService {

  constructor(
    private http: HttpClient,
    private authService: AuthService
    ) { }

    getItems(token, periodeStart, periodeEnd) {
      return this.http.get<any>(this.authService.BASE_URL + `dv-reports/all/${periodeStart}/${periodeEnd}`, {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        })});
    }

    getHeatMapData(token, anomalie, periodeStart, periodeEnd) {
      return this.http.get<any>(this.authService.BASE_URL + `dv-reports/${anomalie}/${periodeStart}/${periodeEnd}`, {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        })});
    }

    getDvExemplesData(token, anomalyId) {
      return this.http.get<any>(this.authService.BASE_URL + `dv-reports/exemples/${anomalyId}`, {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        })});
    }

    getTreeMapData(token, periodeStart, periodeEnd) {
      return this.http.get<any>(this.authService.BASE_URL + `dv-reports/${periodeStart}/${periodeEnd}`, {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        })});
    }

  
}
