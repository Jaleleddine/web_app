import { TestBed } from '@angular/core/testing';

import { CapexCostService } from './capex-cost.service';

describe('CapexCostService', () => {
  let service: CapexCostService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CapexCostService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
