import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of, BehaviorSubject } from 'rxjs';
import { users } from '../data/users';
import { environment } from '../../environments/environment';


@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private http: HttpClient) {
    this.httpOptions = {
      headers: new HttpHeaders(
        {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin':'*',
      },
      ),
      withCredentials: true,
    };

    this.authHttOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: `Bearer ${this.token}`,
        'Access-Control-Allow-Origin':'*',
      })}
   
  }
  redirectUrl: string;
  errorData: {};
  username = '';
  authenticationState = new BehaviorSubject(false);
  BASE_URL = environment.APIEndpoint;
  AE_URL = environment.AEndpoint;
  isProd = environment.production;
  STORAGE_ID = this.utf8_to_b64('stockage en local username');
  token = new BehaviorSubject(null); //this.getToken(); // this.authService.getToken();
  httpOptions: any;
  authHttOptions: any;

  getUsers(): Observable<any> {
    return of(users);
  }

  // Obtenir les vues autorisées pour chaque utilisateur connecté
getViews(role: string){
  switch(role) {
    case 'validator':
      return ['VALIDATEUR','validator', 'admin', 'viewer','editor','config'];
      //break;
    case 'admin':
      return ['ADMIN','admin', 'viewer','editor', 'config'];
      //break;
    case 'editor':
      return ['EDITEUR','viewer','editor','config'];
      //break;
    case 'viewer':
      return ['VISUALISEUR','viewer'];
      //break;
    case 'ser':
      return ['SER','viewer', 'ser','editor','config'];
        //break;
    case 'modeling':
      return ['MODELING','viewer', 'modeling','config'];
      //break;
    case 'marketing':
      return ['MARKETING','viewer', 'marketing','config'];
        //break;
    case 'finance':
      return ['FINANCE','viewer', 'finance','config'];
            //break;
    case 'strategy':
      return ['STRATEGIE','viewer', 'strategy','config'];
                    //break;
    default:
      break;
  }
}

isAuth(expectedRole: string, role: string){
  const views = this.getViews(role);
  // Vérifier si l'user a le role requis
  if(views.includes(expectedRole)){
    //console.log('view')
    return true;
  }else{
   // console.log('noview')
    return false
  }
}

  isLoggedIn() {
   /* if (window.sessionStorage.getItem(this.STORAGE_ID)) {
      return true;
    }
    return false;*/
    const state = window.sessionStorage.getItem('state');
    if (Number(state) === 1){
      return true;
    } else {
      return false;
    }
  }

  // Obtenir les rôles de l'utilisateur
  getRoles(): any {
    const data = JSON.parse(window.sessionStorage.getItem(this.STORAGE_ID));
    return data.role;
  }

  getUsername(): any {
    const user = JSON.parse(window.sessionStorage.getItem(this.STORAGE_ID));
    return user.username;
  }

  // Codage
  utf8_to_b64( str ): string {
    return window.btoa(unescape(encodeURIComponent( str )));
  }

  // Décodage
  b64_to_utf8( str ): string {
    return decodeURIComponent(escape(window.atob( str )));
  }

  // Obtenir le token de l'user
  getToken() {
    // if App is in dev environment we get the token from the session storage else if in app runtine memory
    const data = JSON.parse(window.sessionStorage.getItem(this.STORAGE_ID));
    const token = this.isProd ? this.token.getValue() : data.token;
    return token;
  }

  login(credentials): Observable<any> {
    return this.http.post<any>(this.BASE_URL + 'users/login', credentials, this.httpOptions);
  }

  // Déconnecter l'utilisateur
  logout() {
    window.sessionStorage.removeItem('state');
    window.sessionStorage.removeItem(this.STORAGE_ID);
    this.authenticationState.next(false);
  }

  isAuthenticated() {
    const state = window.sessionStorage.getItem('state');
    if (Number(state) === 1){
      return true;
    } else {
      return false;
    }
  }

  // Obtenir l'user courant
  getUser() {
    return JSON.parse(window.sessionStorage.getItem(this.STORAGE_ID));
  }

}
