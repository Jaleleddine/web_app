import { TestBed } from '@angular/core/testing';

import { IhsOpexService } from './ihs-opex.service';

describe('IhsOpexService', () => {
  let service: IhsOpexService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(IhsOpexService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
