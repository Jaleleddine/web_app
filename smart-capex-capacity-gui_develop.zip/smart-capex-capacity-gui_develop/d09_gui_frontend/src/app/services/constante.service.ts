import { Injectable } from '@angular/core';
import { Observable, of, BehaviorSubject } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthService } from './auth.service';
import { Constante } from '../interfaces/interfaces';
import { BackendService } from './backend.service';

@Injectable({
  providedIn: 'root'
})
export class ConstanteService {

 data:Constante[];
 
  constructor(
    private http: HttpClient,
    private authService: AuthService,
    private backendService: BackendService,
    ) { }

    showDetails(){
      this.backendService.title = 'Factor Parameters';
    }

    postItem(formData, token): Observable<any> {
      return this.http.post<any>(this.authService.BASE_URL+ 'constantes', formData, {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
          'Access-Control-Allow-Origin':'*',
        })});
    }
  
    getItems(token) {
      console.log(this.authService.authHttOptions);
      return this.http.get<any>(this.authService.BASE_URL + `constantes`, {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
          'Access-Control-Allow-Origin':'*',
        })});
    }
  
    // Mise à jour  de l'item
    updateItem(formData, id, token) {
      return this.http.patch<any>(this.authService.BASE_URL + `constantes/${id}`, formData, {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
          'Access-Control-Allow-Origin':'*',
        })});
    }

    // Mise à jour  de plusieurs items
  updateAll(formData, token) {
    return this.http.patch<any>(this.authService.BASE_URL + `constantes`, formData, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
        'Access-Control-Allow-Origin':'*',
      })});
  }
  
     // Suppression
     deleteItem(id, token) {
      return this.http.delete<any>(this.authService.BASE_URL + `constantes/${id}`, {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
          'Access-Control-Allow-Origin':'*',
        })});
    }
}
