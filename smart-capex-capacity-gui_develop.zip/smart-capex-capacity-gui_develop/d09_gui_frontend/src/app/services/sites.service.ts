import { Injectable } from '@angular/core';
import { Observable, of, BehaviorSubject } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class SitesService {
  constructor(
    private http: HttpClient,
    private authService: AuthService,
    ) { }

    postItem(formData, token): Observable<any> {
      return this.http.post<any>(this.authService.BASE_URL+ 'sites', formData, {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
          'Access-Control-Allow-Origin':'*',
        })});
    }
  
    getItems(token) {
      console.log(this.authService.authHttOptions);
      return this.http.get<any>(this.authService.BASE_URL + `sites`, {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
          'Access-Control-Allow-Origin':'*',
        })});
    }
  
    // Mise à jour  de l'item
    updateItem(formData, id, token) {
      return this.http.patch<any>(this.authService.BASE_URL + `sites/${id}`, formData, {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
          'Access-Control-Allow-Origin':'*',
        })});
    }

    // Mise à jour  de plusieurs items
  updateAll(formData, token) {
    return this.http.patch<any>(this.authService.BASE_URL + `sites`, formData, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
        'Access-Control-Allow-Origin':'*',
      })});
  }
  
     // Suppression
     deleteItem(id, token) {
      return this.http.delete<any>(this.authService.BASE_URL + `sites/${id}`, {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
          'Access-Control-Allow-Origin':'*',
        })});
    }
}
