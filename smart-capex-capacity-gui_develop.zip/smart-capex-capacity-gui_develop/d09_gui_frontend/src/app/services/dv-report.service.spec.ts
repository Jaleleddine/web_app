import { TestBed } from '@angular/core/testing';

import { DvReportService } from './dv-report.service';

describe('DvReportService', () => {
  let service: DvReportService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DvReportService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
