import { Injectable } from '@angular/core';
import { Observable, of, BehaviorSubject } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(
    private http: HttpClient,
    private authService: AuthService
    ) { }

    postItem(formData, token): Observable<any> {
      return this.http.post<any>(this.authService.BASE_URL+ 'users', formData, {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
          'Access-Control-Allow-Origin':'*',
        })});
    }
  
    getItems(token) {
      console.log(this.authService.authHttOptions);
      return this.http.get<any>(this.authService.BASE_URL + `users`, {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
          'Access-Control-Allow-Origin':'*',
        })});
    }
  
    // Mise à jour  de l'item
    updateItem(formData, id, token) {
      return this.http.patch<any>(this.authService.BASE_URL + `users/${id}`, formData, {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
          'Access-Control-Allow-Origin':'*',
        })});
    }

    // Refresh user infos in dev Environment
    me(): Observable<any> {
      const data = JSON.parse(window.sessionStorage.getItem(this.authService.STORAGE_ID));
      const token = data.token;
      return this.http.get<any>(this.authService.BASE_URL + `users/me`, {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
          'Access-Control-Allow-Origin':'*',
        }),
        withCredentials: true,
      });
    }

    // Refresh user infos in Production
    refreshToken(): Observable<any> {
      return this.http.get<any>(this.authService.BASE_URL + `users/refresh`, {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin':'*',
        }),
        withCredentials: true,
      });
    }
  
     // Suppression
     deleteItem(id, token) {
      return this.http.delete<any>(this.authService.BASE_URL + `users/${id}`, {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
           Authorization: `Bearer ${token}`,
          'Access-Control-Allow-Origin':'*',
        })});
    }
}
