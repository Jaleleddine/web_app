import { TestBed } from '@angular/core/testing';

import { SteeringNetworkService } from './steering-network.service';

describe('SteeringNetworkService', () => {
  let service: SteeringNetworkService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SteeringNetworkService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
