import { TestBed } from '@angular/core/testing';

import { CagrService } from './cagr.service';

describe('CagrService', () => {
  let service: CagrService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CagrService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
