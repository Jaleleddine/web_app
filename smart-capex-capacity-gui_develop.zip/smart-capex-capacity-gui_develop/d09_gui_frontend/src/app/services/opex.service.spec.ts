import { TestBed } from '@angular/core/testing';

import { OpexService } from './opex.service';

describe('OpexService', () => {
  let service: OpexService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(OpexService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
