import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import * as moment from 'moment';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class BackendService {

  getWeekPeriod(itemDate?) {
    const date = this.getDate(itemDate);
    const year = moment(date).format('YYYY');
    const isoWeek = moment(date).isoWeek() < 10 ? 0 + '' + moment(date).isoWeek(): moment(date).isoWeek();
    return year + '' + isoWeek;
  }

  // check if week of upgrade of the planification is Good
  checkPlanifWeekOfUpgrade(planifWeekOfUpgrade: Date){
    const WEEKOfUpgradeIN2Year =  moment().add(24, 'months').format('YYYY') + '' + moment().add(24, 'months').isoWeek(); // Week of upgrade in two year
    const planifWEEKOfUpgrade = moment(planifWeekOfUpgrade).format('YYYY') + '' + moment(planifWeekOfUpgrade).isoWeek();
    const isValidWEEKOfUpgrade = WEEKOfUpgradeIN2Year < planifWEEKOfUpgrade ? false : true;
    //console.log(planifWEEKOfUpgrade);
    //console.log(WEEKOfUpgradeIN2Year);
    
    return isValidWEEKOfUpgrade;
  }

  // Get weekend period in six month
  getWeekPeriodEnd(itemDate?) {
    const date = this.getDate(itemDate);
    const year = moment(date).add(6, 'months').format('YYYY');
    let weekEnd: any = moment(date).add(6, 'months').isoWeek();
    weekEnd = weekEnd < 10 ? 0 + '' + weekEnd: weekEnd;
    return year + '' + weekEnd;
  }

  getIsoWeek(itemDate?) {
    const date = this.getDate(itemDate);
    const year = moment(date).format('YYYY');
    let weekEnd: any = moment(date).isoWeek();
    weekEnd = weekEnd < 10 ? 0 + '' + weekEnd: weekEnd;
    return year + '' + weekEnd;
  }

  // Obtenir le mois en cours de la recherche
  getMonthPeriode(itemDate?) {
      const date = itemDate ? new Date(itemDate) : new Date();
      const dateTime = moment(date).subtract(0, 'months').format('YYYY-MM-DD 00:00:00')
      return dateTime;
  }

  // Obtenir la date de fin de la recherche
  getMonthPeriodeEnd(itemDate?, periode = 12) {
    const date = itemDate ? new Date(itemDate) : new Date();
    const dateTime = moment(date).add(periode, 'months').format('YYYY-MM-DD 00:00:00')
    return dateTime;
  }
  getYear(itemDate?) {
    const date = itemDate ? new Date(itemDate) : new Date();
    const year = date.getFullYear().toString();
    return year;
  }

    getYearEnd(itemDate?) {
      const date = itemDate ? new Date(itemDate) : new Date();
      const year = date.getFullYear().toString();
      const yearEnd = parseInt(year) + 2;
      return yearEnd;
    }

    getDate(itemDate?) {
      const date = itemDate ? new Date(itemDate) : new Date();
      const year = date.getFullYear().toString();
      let month = (date.getMonth() + 1).toString();
      let day = date.getDate().toString();
      if ( date.getMonth() + 1 < 10) {
        month = '0' + month;
      }
  
      if ( date.getDate() < 10) {
        day = '0' + day;
      }
      return year + '' + month + '' + day;
  }

  translateInFrench() {
    return {
      firstDayOfWeek: 0,
      dayNames: ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'],
      dayNamesShort: ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam'],
      dayNamesMin: ['Di', 'Lu', 'Ma', 'Me', 'Je', 'Ve', 'Sa'],
      monthNames: [ 'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet',
       'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre' ],
      monthNamesShort: [ 'Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Jui', 'Juil', 'Aoû', 'Sep', 'Oct', 'Nov', 'Déc' ],
      today: 'Aujourd\'hui',
      clear: 'Effacer',
      dateFormat: 'dd/mm/aa',
      weekHeader: 'SEM'
  };
  }

  tileUrl = 'http://10.242.79.244/osmbw/{z}/{x}/{y}.png';
  // tileUrl = 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'; //
 // tileUrl = 'https://{s}.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png';
  // tileUrl = 'https://maps.wikimedia.org/osm-intl/{z}/{x}/{y}.png';
  // tileUrl = 'http://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png';
  //tileUrl = 'https://{s}.basemaps.cartocdn.com/rastertiles/light_all/{z}/{x}/{y}.png';
  // tileUrl = 'http://stamen-tiles-{s}.a.ssl.fastly.net/toner/{z}/{x}/{y}.png';
  latitude = 7.5468545;
  longitude = -5.547099500000002;
  /*latitude = 61.6226441;
  longitude = -2.5326854;*/

  fr = this.translateInFrench();

  today = new Date();
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*'
    }),
  };

  // Table header and Table body for the parameters details
  paramTableHeader: string;
  paramTableBody: string;
  paramData: any[];
  title: string;

  /******************* Params Tables details **************/
  showCapexTable: boolean = false;
  showOpexTable: boolean = false;
  showIhsOpexTable: boolean = false;
  showEscoOpexTable: boolean = false;
  showCagrTable: boolean = false;
  showClientMarginTable: boolean = false;
  showUpgradePathParamTable:boolean = false;
  showSteeringNetwork: boolean = false;

  constructor(
    private http: HttpClient,
    private authService: AuthService,
    ) { }

  getZoneCommerciale(): Observable<any> {
    return this.http.get<any>(`../../assets/data/decoupage_commercial.geojson`);
  }

  getDataCell(): Observable<any> {
    return this.http.get<any>(`../../assets/data/cell_position.json`);
  }

  getDataPopulation(): Observable<any> {
    return this.http.get<any>(`../../assets/data/population_quad_coverage_1km_100.json`);
  }

  /*getDataSimulation(): Observable<any> {
    return this.http.get<any>(`../../assets/data/simulation_couverture_comoe_inverted.json`);
  }*/

  getDataSousPrefecture(): Observable<any> {
    return this.http.get<any>(`../../assets/data/sous_pref_cellules_coverage_structured.json`);
  }

  getGeometries(token, sousPrefecture){
    return this.http.get<any>(this.authService.BASE_URL + `final-npv-of-the-coverages/${sousPrefecture}`, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
        'Access-Control-Allow-Origin':'*',
      })});
  }

  getExistedCellsPosition(token, sousPrefecture){
    return this.http.get<any>(this.authService.BASE_URL + `existed-cells-position/${sousPrefecture}`, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
        'Access-Control-Allow-Origin':'*',
      })});
  }

  getExistedCellsCoverage(token, sousPrefecture){
    return this.http.get<any>(this.authService.BASE_URL + `existed-cells-coverage/${sousPrefecture}`, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
        'Access-Control-Allow-Origin':'*',
      })});
  }

  getNewCellsPosition(token, sousPrefecture){
    return this.http.get<any>(this.authService.BASE_URL + `new-cells-position/${sousPrefecture}`, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
        'Access-Control-Allow-Origin':'*',
      })});
  }

  getNewCellsCoverage(token, sousPrefecture){
    return this.http.get<any>(this.authService.BASE_URL + `new-cells-coverage/${sousPrefecture}`, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
        'Access-Control-Allow-Origin':'*',
      })});
  }

  getSousPrefectures(token){
    return this.http.get<any>(this.authService.BASE_URL + `sous-prefectures`, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
        'Access-Control-Allow-Origin':'*',
      })});
  }

  getFinalNPV(token) {
    return this.http.get<any>(this.authService.BASE_URL + `final-npv-of-the-upgrades`, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
        'Access-Control-Allow-Origin':'*',
      })});
  }

  // Obtenir les NPV Coverarages
  getFinalCoverageNPV(token) {
    return this.http.get<any>(this.authService.BASE_URL + `final-npv-of-the-coverages`, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
        'Access-Control-Allow-Origin':'*',
      })});
  }

   // Get coverage KPIs details
  getCoverageNPVDetails(formData, token) {
    return this.http.post<any>(this.authService.BASE_URL + `finali-npv-of-the-coverages-kpis`, formData, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
        'Access-Control-Allow-Origin':'*',
      })
    });
  }

  getConfigs(token) {
    console.log(this.authService.BASE_URL + `getconfigs`)
    return this.http.get<any>(this.authService.BASE_URL + `getconfigs`, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      })});
  }
}
