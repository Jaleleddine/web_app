import { TestBed } from '@angular/core/testing';

import { ClientMarginService } from './client-margin.service';

describe('ClientMarginService', () => {
  let service: ClientMarginService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ClientMarginService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
