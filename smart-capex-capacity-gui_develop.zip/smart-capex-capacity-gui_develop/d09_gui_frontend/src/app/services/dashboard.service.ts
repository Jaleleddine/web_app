import { Injectable } from '@angular/core';
import { Observable, of, BehaviorSubject } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {

  constructor(
    private http: HttpClient,
    private authService: AuthService,
  ) { }

  getLocations(token) {
    // console.log(this.authService.authHttOptions);
    return this.http.get<any>(this.authService.BASE_URL + `locations`, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
        'Access-Control-Allow-Origin':'*',
      })
    });
  }

  getForecastingKPIs(token, locationType, location, periodeType, periode, periodeEnd) {
    console.log(this.authService.BASE_URL + `indicateurs/${locationType}/${location}/${periodeType}/${periode}/${periodeEnd}`);
    return this.http.get<any>(this.authService.BASE_URL + `indicateurs/${locationType}/${location}/${periodeType}/${periode}/${periodeEnd}`, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
        'Access-Control-Allow-Origin':'*',
      })
    });
  }

  // Toutes les prédictions de toutes les zones
  getALLLocationKPIs(token,periodeType, periode, periodeEnd) {
    console.log(this.authService.BASE_URL + `all-indicateurs/${periodeType}/${periode}/${periodeEnd}`);
    return this.http.get<any>(this.authService.BASE_URL + `all-indicateurs/${periodeType}/${periode}/${periodeEnd}`, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
        'Access-Control-Allow-Origin':'*'
      })
    });
  }

  // Toutes les prédictions de toutes les zones
 
}
