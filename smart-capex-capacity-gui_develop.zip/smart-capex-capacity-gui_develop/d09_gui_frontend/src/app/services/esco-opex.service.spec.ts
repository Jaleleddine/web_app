import { TestBed } from '@angular/core/testing';

import { EscoOpexService } from './esco-opex.service';

describe('EscoOpexService', () => {
  let service: EscoOpexService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EscoOpexService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
