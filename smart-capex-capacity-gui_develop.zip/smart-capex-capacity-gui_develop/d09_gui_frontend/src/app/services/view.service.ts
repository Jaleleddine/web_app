import { Injectable } from '@angular/core';
import { UserService } from '../services/user.service';
import { AuthService } from '../services/auth.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ViewService {
  role: string;
  views = [];
  constructor(
    private userService: UserService,
    private authService: AuthService
  ) {
    const refreshData : Observable<any> = this.authService.isProd ? this.userService.refreshToken() : this.userService.me()
    refreshData.subscribe(data => {
      this.role = data.role;
      this.views = this.authService.getViews(this.role);
    })
   }
}
