import { TestBed } from '@angular/core/testing';

import { UpgradePathService } from './upgrade-path.service';

describe('UpgradePathService', () => {
  let service: UpgradePathService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UpgradePathService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
