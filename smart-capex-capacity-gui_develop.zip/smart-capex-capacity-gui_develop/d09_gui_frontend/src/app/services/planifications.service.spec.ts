import { TestBed } from '@angular/core/testing';

import { PlanificationsService } from './planifications.service';

describe('PlanificationsService', () => {
  let service: PlanificationsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PlanificationsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
