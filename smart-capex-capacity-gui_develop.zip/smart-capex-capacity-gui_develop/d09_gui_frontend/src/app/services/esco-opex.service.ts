import { Injectable } from '@angular/core';
import { Observable, of, BehaviorSubject } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthService } from './auth.service';
import { EscoOpex } from '../interfaces/interfaces';
import { BackendService } from './backend.service';

@Injectable({
  providedIn: 'root'
})
export class EscoOpexService {

  data: EscoOpex[];
  constructor(
    private http: HttpClient,
    private authService: AuthService,
    private backendService: BackendService,
    ) { }

    showDetails(){
      this.backendService.title = 'ESCO Opex Parameters';
      this.backendService.showCapexTable = false;
      this.backendService.showIhsOpexTable = false;
      this.backendService.showOpexTable = false;
      this.backendService.showEscoOpexTable = true;
      this.backendService.showCagrTable = false;
      this.backendService.showClientMarginTable = false;
      this.backendService.showUpgradePathParamTable = false;
    }

    postItem(formData, token): Observable<any> {
      return this.http.post<any>(this.authService.BASE_URL+ 'esco-opexes', formData, {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
          'Access-Control-Allow-Origin':'*',
        })});
    }
  
    getItems(token) {
      console.log(this.authService.authHttOptions);
      return this.http.get<any>(this.authService.BASE_URL + `esco-opexes`, {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
           Authorization: `Bearer ${token}`,
          'Access-Control-Allow-Origin':'*',
        })});
    }
  
    // Mise à jour  de l'item
    updateItem(formData, id, token) {
      return this.http.patch<any>(this.authService.BASE_URL + `esco-opexes/${id}`, formData, {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
          'Access-Control-Allow-Origin':'*',
        })});
    }

    // Mise à jour  de plusieurs items
  updateAll(formData, token) {
    return this.http.patch<any>(this.authService.BASE_URL + `esco-opexes`, formData, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
         Authorization: `Bearer ${token}`,
        'Access-Control-Allow-Origin':'*',
      })});
  }
  
     // Suppression
     deleteItem(id, token) {
      return this.http.delete<any>(this.authService.BASE_URL + `esco-opexes/${id}`, {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
           Authorization: `Bearer ${token}`,
          'Access-Control-Allow-Origin':'*',
        })});
    }
}
