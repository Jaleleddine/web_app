import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HistoriquePlanifComponent } from './historique-planif.component';

describe('HistoriquePlanifComponent', () => {
  let component: HistoriquePlanifComponent;
  let fixture: ComponentFixture<HistoriquePlanifComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HistoriquePlanifComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HistoriquePlanifComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
