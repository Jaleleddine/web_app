import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { BackendService } from '../services/backend.service';
import * as _ from 'lodash';
import { forkJoin, zip} from 'rxjs';
import {FormGroup, FormBuilder, Validators} from '@angular/forms';
import * as echarts from 'echarts';
import * as L from 'leaflet';
import 'node_modules/leaflet.tilelayer.colorfilter/src/leaflet-tilelayer-colorfilter.js';
import { SitesService } from '../services/sites.service';
import { AuthService } from '../services/auth.service';
import { ViewService } from '../services/view.service';
import { UserService } from '../services/user.service';
import { PlanificationsService } from '../services/planifications.service';
import * as XLSX from 'xlsx';
import { Site, SteeringNetwork, Planification } from '../interfaces/interfaces';

// import * as moment from 'moment';

@Component({
  selector: 'app-historique-planif',
  templateUrl: './historique-planif.component.html',
  styleUrls: ['./historique-planif.component.css']
})
export class HistoriquePlanifComponent implements OnInit {

  p =1;
  pS = 1; // Pagination site inclus
  pE = 1; // Pagination site exclus
  data: any[];
  user: any;
  dataForTable: any[] = [];
  item: any;
  fr: any;
  title = '';
  isUpdate = false;
  macarte: any;
  chart: any;
  token = '';
  role: string;
  views = [];
  errors: any[] = [];
  submited = false;
  sites: any[] = [];
  orderedSitesByZones: any[] = [];
  zonesCommerciales: any[];
  zoneSelected: any;
  sitesExcluded: any[]  = [];
  steeringNetwork: any[] = [];
  // upload file
  sitesExludedFile: any;
  steeringNetworkFile: any;
  plannifDetails: Planification;
  selectedPlanifications: any[] = []; // Les planifications sélectionnés pour la comparaison

  addForm: FormGroup;
  errorMessages = {
    name: [
      { type: 'required', message: 'Le nom de la planification est obligatoire' },
      { type: 'pattern', message: 'Le nom de la planification doit commencer par "Planification#" suivi de son numéro' },
      { type: 'maxLength', message: 'Le nom de la planification ne doit pas dépasser 255 caractères.' },
    ],
    zonesConsidered: [
      { type: 'required', message: 'Il faut choisir au moins une zone' },
    ],
    anneeDeploiement: [
      { type: 'required', message: 'L\'année de déploiement est obligatoire' },
    ],
    wacc: [
      { type: 'required', message: 'Le WACC est obligatoire' },
    ]
  };
  get f() { return this.addForm.controls; }

  constructor(
    private backendService: BackendService,
    private ngxService: NgxUiLoaderService,
    private toastr: ToastrService,
    private siteService: SitesService,
    public authService: AuthService,
    public fb: FormBuilder,
    private planifService: PlanificationsService,
    private userService: UserService,
    public viewService: ViewService
  ) { 
  }

  ngOnInit(): void {
    //this.token = this.authService.getToken();
    this.fr = this.backendService.translateInFrench();
    this.user = this.authService.getUser();
    this.addForm = this.fb.group({
      name: ['', [Validators.required, Validators.maxLength(255), Validators.pattern(new RegExp('^Planification#[0-9]{6,}'))]],
      budget: [],
      zonesConsidered: [[], [Validators.required]],
      sitesConsidered: [],
      createdBy: [],
      updatedBy: [],
      validatedBy: [],
      sitesExcluded: [],
      impactDuration: [],
      etatValidation: ['NON_VALIDE'],
      wacc: [9.75,[Validators.required]],
      steeringNetwork: [],
      dateDebut: [],
      anneeDeploiement: ['', [Validators.required]],
      statutAnalyse: ['NON_DEMARRE'],
    });
    this.updateForm(); 
      // Get token first and after initial data
      if(this.authService.isProd){
        this.userService.refreshToken().subscribe(data => {
          this.token = data.token;
          this.authService.token.next(data.token)
          this.getData();
        }, (err => {
          console.log(err);
          this.toastr.error('Une erreur est survenue pendant le chargement de la page.', '', {
            timeOut: 10000,
            closeButton: true,
            positionClass: 'toast-top-center',
            progressBar: true,
          });
        }))
      } else {
          this.token = this.authService.getToken();
          this.authService.token.next(this.token)
          // Get initial data
          this.getData();
      }
  }

  exportToExcel(data: any[]): void {
      console.log(data);
     /*const infoGen = [];
     data.forEach(item => {
        infoGen.push(item);
     });*/
     const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(data);
     // const wsDetails: XLSX.WorkSheet = XLSX.utils.json_to_sheet(details);
     const wb: XLSX.WorkBook = XLSX.utils.book_new();
     XLSX.utils.book_append_sheet(wb, ws, 'SITES_OCI');
     XLSX.writeFile(wb, 'SITES_OCI.xlsx');
}

closeModal() {
  // document.getElementById('delete-box').style.display='none'
  document.getElementById("myModal-add").style.display='none'
  this.addForm.reset();
}

showModal(){
  // this.modalVisibility = true;
  document.getElementById("myModal-add").style.display='block'
}

showDetails(plannif){
  this.planifService.getItem(plannif.id, this.token).subscribe(data => {
    //console.log(data);
    this.plannifDetails = data;
    document.getElementById("myModal").style.display='block'
  }, (error) => {console.log(error)})
}

showDeleteConfirm(item): void {
  this.item = item;
  document.getElementById('delete-box').style.display='block'
}

updateForm() {
  if (this.isUpdate) {
    this.title = 'MODIFIER LA PLANIFICATION';
    this.addForm.get('name').setValue(this.item.name);
    this.addForm.get('budget').setValue(this.item.budget);
    this.addForm.get('createdBy').setValue(this.item.createdBy);
    this.addForm.get('updatedBy').setValue(this.item.updatedBy);
    this.addForm.get('validatedBy').setValue(this.item.validatedBy);
    this.addForm.get('sitesExcluded').setValue(this.item.sitesExcluded);
    this.addForm.get('zonesConsidered').setValue(this.item.zonesConsidered);
    this.addForm.get('sitesConsidered').setValue(this.item.sitesConsidered);
    this.addForm.get('impactDuration').setValue(this.item.impactDuration);
    this.addForm.get('etatValidation').setValue(this.item.etatValidation);
    // this.addForm.get('etatValidation').disable();
    this.addForm.get('wacc').setValue(this.item.wacc);
    this.addForm.get('steeringNetwork').setValue(this.item.steeringNetwork);
    this.addForm.get('dateDebut').setValue(new Date(this.item.dateDebut));
    //this.addForm.get('dateDebut').disable();
    this.addForm.get('anneeDeploiement').setValue(this.item.anneeDeploiement);
    this.addForm.get('statutAnalyse').setValue(this.item.statutAnalyse);
  } else {
    this.title = 'AJOUTER UNE NOUVELLE PLANIFICATION';
    // this.addForm.get('name').setValue(this.data[this.data.length -1].name);
    //this.addForm.get('etatValidation').disable();
    this.addForm.get('dateDebut').setValue(new Date(this.backendService.getMonthPeriodeEnd(new Date(), 6)));
    //this.addForm.get('dateDebut').disable();
    this.addForm.get('steeringNetwork').disable();
    this.addForm.get('impactDuration').disable();
    this.addForm.get('statutAnalyse').setValue('NON_DEMARRE');
    console.log('new item');
  }
}

// Obtenir la liste des sites faisant partie de la plannification et des zones choisies
getSitesConsidered(zones: string[]): Site[]{
  let selectedSites: Site[] = [];
  zones.forEach(zone => {
    const zoneSites = this.sites.filter(site => zone == site.siteZoneCommerciale);
    if(zoneSites.length > 0){
      selectedSites = _.concat(selectedSites, zoneSites);
    }
  })
  console.log(selectedSites);
  return selectedSites;
}

//
getData(){
  this.getPlannifications();
  this.getSites();
  this.checkPlanificationExecution();
}

checkPlanificationExecution(){
  this.planifService.checkExecutionStatut(this.token).subscribe(data => {
    console.log(data);
  }, (error) => {console.log(error)})
}

// La liste des planifications
getPlannifications(){
  this.planifService.getItems(this.token).subscribe(data => {
    console.log(data);
    this.data = _.orderBy(data, 'id', 'desc');;
    this.dataForTable = data.filter(item => item.anneeDeploiement == new Date().getFullYear());
    this.dataForTable = _.orderBy(this.dataForTable, 'id', 'desc');
  }, (error) => {console.log(error)})
}

// Obtenir la liste  des sites Techniques OCI
getSites(){
    this.siteService.getItems(this.token).subscribe(data => {
      console.log(data);
      this.sites = data; 
      // Ordonner les sites par zones commerciales
      this.orderedSitesByZones = _.groupBy(data, (item) => item.siteZoneCommerciale );
      console.log(this.orderedSitesByZones);
      this.zonesCommerciales = _.keys(this.orderedSitesByZones);
      console.log(this.zonesCommerciales);
    }, (error) => {console.log(error)})
  }


  heatMap(site?): void{
    // this.ngxService.start();
    if (!this.macarte){
      this.macarte = L.map('macarte', { zoomControl: false }).setView([this.backendService.latitude, this.backendService.longitude], 6);
      (L.tileLayer as any).colorFilter(this.backendService.tileUrl, {
      minZoom: 5,
      maxZoom: 20,
    // filter: ['grayscale:100%', 'invert:0%']
    }).addTo(this.macarte);
     // Positionner le zoom panel
      new L.Control.Zoom({ position: 'bottomleft' }).addTo(this.macarte);
      // Le découpage commercial
      this.initDecoupageCommercial(this.macarte);
    }
  }

  onEachFeature(feature, layer): void {
    console.log('count');
    // does this feature have a property named popupContent?
    // feature.properties.QUARTIER && feature.properties.COMMUNE
    if (feature.properties.ZC) {
        layer.
        bindTooltip(`
            <div style="background:#FFF">
            <div style="color:#000;text-align: center;font-weight: bold;font-size: 14px;margin:0px auto;">
            ${feature.properties.ZC}
            </div>

            <table class="tooltip-table">
              <tr>
                <td>${feature.properties.Superf} KM²</td>
              </tr>
            </table>
            </div>
            `, {className: 'small-tooltip'});
        }
  }

  initDecoupageCommercial(map): void {
    const colors = ['#085EBD', '#0A6E31', '#FF8AD4', '#FFB400', '#492191', '#595959', '#000000', '#4BB4E6', '#A885D8',
  '#FF7900', '#62342D', '#FFD200', '#FFF6B6', '#880E4F', '#FFAB91'];
    this.backendService.getZoneCommerciale().subscribe((zones) => {
      zones.features.forEach((feacture, index) => {
        feacture.properties.index = index;
      });
      console.log(zones);
      L.geoJSON(zones, {
        style: (feature) => {
            return {color: colors[feature.properties.index], weight: 0.3, opacity: 0.3,fillOpacity: 0.1};
        },
        onEachFeature: this.onEachFeature
    }).addTo(map);
    });
  }

  close(){
    document.getElementById("myModal").style.display = "none";
  }

  closeAdd(){
    document.getElementById("myModal-add").style.display = "none";
  }

  closeChart(){
    document.getElementById("myModal-chart").style.display = "none";
  }

  modifyItem(item){
    this.isUpdate = true;
    this.planifService.getItem(item.id, this.token).subscribe(data => {
      //console.log(data);
      this.item = data;
      this.updateForm();
      this.showModal();
      console.log('modification item');

    }, (error) => {console.log(error)})
    
  }

  addNewItem(){
    this.isUpdate = false;
    this.updateForm();
    this.showModal();
  }

  reset(){
    // Réinitialiser les fichiers uploader
    const inputLSC = document.getElementById('lsc') as HTMLInputElement;
    inputLSC.value = null;
    const inputSTN = document.getElementById('stn') as HTMLInputElement;
    inputSTN.value = null;
    this.addForm.reset();
    this.sitesExcluded = [];
    this.steeringNetwork = [];
    this.submited = false; this.closeModal(); this.isUpdate = false; 
  }

  removeEmptyFormData(data: any): any {    // Filter any fields that aren't empty & store in a new object - To be passed on the Pipe map's caller
    let fields = {};

    for (const key in data) {
      if( data.hasOwnProperty( key ) ) {
        data[key] != null ? fields[key] = data[key] : key;
      }
      
    }

    return fields;   
}

globalFilter(value: any): any {
  //console.log(value);
  if (!value) {
    this.dataForTable = this.data;
  } else {
    this.dataForTable = this.data.filter((val) => {
      // console.log(val.name);
      const rVal = (
        val.name.toLocaleLowerCase().includes(value) ||
        val.createdBy.toLocaleLowerCase().includes(value)
       );
      return rVal;
    });
  }

}

filterByEtatValidation(value: any): any {
  // console.log(value);
  if (!value) {
    this.dataForTable = this.data;
  } else {
    this.dataForTable = this.data.filter((val) => {
      const rVal = (
        val.etatValidation == value
       );
      return rVal;
    });
  }
}

filterByYear(value: any): any {
  //console.log(value)
  if (!value) {                                       
    this.dataForTable = this.data;
  } else {
    this.dataForTable = this.data.filter((val) => {
      const rVal = (
        val.anneeDeploiement == value
       );
      return rVal;
    });
  }
}


  onSubmit() {
    this.submited = true;
    console.log(this.addForm.value);
    if (this.isUpdate) {
      this.updateItem();
    } else {
      this.addItem();
    }
  }

  addItem() {
    let selectedSites = this.getSitesConsidered(this.addForm.get('zonesConsidered').value);

    if (this.steeringNetwork.length > 0){
      this.addForm.get('steeringNetwork').setValue(this.steeringNetwork);
    }

    // console.log(this.sitesExcluded);
    if(this.sitesExcluded.length > 0){
      this.addForm.get('sitesExcluded').setValue(this.sitesExcluded);
      // Trouver la liste définitive des sites choisis en excluant ceux ne faisant pas partie de la planification
      selectedSites = _.differenceBy(selectedSites, this.sitesExcluded, 'siteId');
      console.log(selectedSites);
    }

    this.addForm.get('sitesConsidered').setValue(selectedSites);
    this.addForm.get('createdBy').setValue(this.user.name + ' ' + this.user.firstname);
    this.addForm.get('etatValidation').setValue('NON_VALIDE');
    this.addForm.get('statutAnalyse').setValue('NON_DEMARRE');
    this.addForm.get('dateDebut').setValue(new Date(this.backendService.getMonthPeriodeEnd(new Date(), 6)));

    // console.log(this.addForm.value);
    const data = this.addForm.value;
    const cleanForm = this.removeEmptyFormData(data);
    //console.log(cleanForm);

    this.planifService.postItem(cleanForm, this.token).subscribe((data) => {
      console.log(data);
      this.toastr.success('La planification a été enregistrée avec succès', '', {
        timeOut: 10000,
        closeButton: true,
        positionClass: 'toast-top-center',
        progressBar: true,
      });
      this.getData();
    }, (error) => {
      this.errors = [];
      console.log(error);
      if(error.status === 400){
        this.toastr.error(error.error.message, '', {
          timeOut: 120000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      } else{
        this.toastr.error('Une erreur est survenue pendant l\'ajout', '', {
          timeOut: 10000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      }
    }, () => {this.reset();});
  }

  executeItem(item:Planification) {
    const id = item['id'];
    //item.statutAnalyse = 'DEMARRE';
    //console.log(id);
    this.planifService.getItem(item['id'], this.token).subscribe(planif => {
      console.log(planif)
      const planifToExecute = planif;
      planifToExecute.statutAnalyse = 'DEMARRE';
      this.planifService.executeItem(planifToExecute, id, this.token).subscribe((data) => {
        //console.log(data);
        if(data){
          this.toastr.error('Une erreur est survenue pendant l\'éxécution de la planification', '', {
            timeOut: 10000,
            closeButton: true,
            positionClass: 'toast-top-center',
            progressBar: true,
          });
        } else {
          this.toastr.success('L\'éxécution de la plannification a démarré avec succès!', '', {
            timeOut: 10000,
            closeButton: true,
            positionClass: 'toast-top-center',
            progressBar: true,
          });
        }
        
        // this.getData();
        this.getPlannifications();
        this.checkPlanificationExecution();

      }, (error) => {
        this.errors = [];
        this.getPlannifications();
        console.log(error);
        if(error.status === 400){
          this.toastr.error(error.error.message, '', {
            timeOut: 120000,
            closeButton: true,
            positionClass: 'toast-top-center',
            progressBar: true,
          });
        } else{
          this.toastr.error('Une erreur est survenue pendant l\'éxécution de la planification', '', {
            timeOut: 10000,
            closeButton: true,
            positionClass: 'toast-top-center',
            progressBar: true,
          });
        }
       
      }, () => {this.reset()});

      // End fetch planif
    }, (error) => {console.log(error)})

  }

  updateItem() {
    const id = this.item['id'];
    //console.log(id);
    
    let selectedSites = this.getSitesConsidered(this.addForm.get('zonesConsidered').value);

    if (this.steeringNetwork.length > 0){
      this.addForm.get('steeringNetwork').setValue(this.steeringNetwork);
    }

    // console.log(selectedSites);
    if(this.sitesExcluded.length > 0){
      this.addForm.get('sitesExcluded').setValue(this.sitesExcluded);
      // Trouver la liste définitive des sites choisis en excluant ceux ne faisant pas partie de la planification
      selectedSites = _.differenceBy(selectedSites, this.sitesExcluded, 'siteId');
      // console.log(selectedSites);
    }
    this.addForm.get('sitesConsidered').setValue(selectedSites);
    //this.addForm.get('statutAnalyse').setValue('NON_DEMARRE');
    
    this.addForm.get('updatedBy').setValue(this.user.name + ' ' + this.user.firstname);
   
    // exclure les données nulles
    // console.log(this.addForm.value);
    const data = this.addForm.value;
    const cleanForm = this.removeEmptyFormData(data);
    console.log(cleanForm);
    // cleanForm.statutAnalyse = 'NON_DEMARRE';
    
    this.planifService.updateItem(cleanForm, id, this.token).subscribe((data) => {
      console.log(data);
      this.toastr.success('La planification a été modifiée avec succès', '', {
        timeOut: 10000,
        closeButton: true,
        positionClass: 'toast-top-center',
        progressBar: true,
      });
      this.getData();
    }, (error) => {
      this.errors = [];
      console.log(error);
      if(error.status === 400){
        this.toastr.error(error.error.message, '', {
          timeOut: 120000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      } else{
        this.toastr.error('Une erreur est survenue pendant la modification', '', {
          timeOut: 10000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      }
     
    }, () => {this.reset()});
  }

  deteleItem(){
    const id = this.item['id'];
    // console.log(id);
    this.planifService.deleteItem(id, this.token).subscribe((data) => {
      console.log(data);
      this.toastr.success('La planification a été supprimé avec succès', '', {
        timeOut: 10000,
        closeButton: true,
        positionClass: 'toast-top-center',
        progressBar: true,
      });
      this.getData();
    }, (error) => {
      this.errors = [];
      console.log(error);
      if(error.status === 400){
        this.toastr.error(error.error.message, '', {
          timeOut: 120000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      } else{
        this.toastr.error('Une erreur est survenue pendant la modification', '', {
          timeOut: 10000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      }
    }, () => {this.submited = false; document.getElementById('delete-box').style.display='none'});
  }

// Sélectionner une planification
selectPlanif(event, item){
  if(event.target.checked){
    //console.log('check');
    this.selectedPlanifications.push(item);
    //console.log(event.target.checked);
    //console.log(item);
  } else {
    // Supprimer notre élément de la liste
    //console.log('uncheck')
    this.selectedPlanifications = this.selectedPlanifications.filter(el => el.id !== item.id);
  }
  
}
  // Les résultats d'éxécution des planifications à comparer
getComparePlanifData(){
  if(this.selectedPlanifications.length >= 2){
    const planifs = this.selectedPlanifications.slice(0,2); // Prendre uniquement les 2 premiers
    zip(
      this.planifService.getPlanificationExecutionResult(planifs[0].id,this.token),
      this.planifService.getPlanificationExecutionResult(planifs[1].id,this.token)
    ).subscribe(([data1, data2]) => {
      let dataset1 = data1;
      let dataset2 = data2;
      const name1 = data1[0].name; // Le nom de la planification1
      const name2 = data2[0].name; // Le nom de la planification1
      
      // Caster nos npv en nombre
      dataset1.forEach(item => {
        item.npv = item.npv ? parseFloat(parseFloat(item.npv).toFixed(2)) : 0;
      });

      dataset2.forEach(item => {
        item.npv = item.npv ? parseFloat(parseFloat(item.npv).toFixed(2)) : 0;
      });

      // Ordonner nos résultats
      dataset1 = _.orderBy(dataset1, 'npv', 'desc');
      dataset2 = _.orderBy(dataset2, 'npv', 'desc');
    
      // Afficher notre popup
      document.getElementById("myModal-chart").style.display = "block";

      // Construction de notre courbe de comparaison
      this.comparePlanif(dataset1, dataset2, name1, name2)
      console.log(this.data);
    }, (error) => {
      console.log(error);
      this.toastr.error('Une erreur est survenue pendant la comparaison, veuillez recommencer!', '', {
        timeOut: 10000,
        closeButton: true,
        positionClass: 'toast-top-center',
        progressBar: true,
      });
    })
  }else {
    this.toastr.error('Veuillez choisir deux planifications pour la comparaison!', '', {
      timeOut: 10000,
      closeButton: true,
      positionClass: 'toast-top-center',
      progressBar: true,
    });
  }
}

comparePlanif(data1: any[], data2: any[], name1:string, name2: string){
  document.getElementById("myModal-chart").style.display = "block";
  if(!this.chart){
    this.chart = echarts.init(document.getElementById('chart'));
  }

  const yVALUES1 = [];
  const yVALUES2 = [];
    const xAXIS = [];
    let dataset1: any[] = data1;
    let dataset2: any[] = data2;
    // dataset.forEach(item => {item.npv = parseFloat(item.npv)});
    // Ordonner nos npv
    dataset1 = _.orderBy(dataset1, 'npv', 'desc');
    dataset2 = _.orderBy(dataset2, 'npv', 'desc');
    // Choisir le plus grand dataset
    const selectedDataset = dataset1.length > dataset2.length ? dataset1 : dataset2;
    // console.log(dataset)
    // Calculer nos NPV par actions cumulées
    for (let i = 0; i < selectedDataset.length; i = i+10) {

      // Dataset1
      const actions1 = dataset1.filter((item, index) => index <= i ); // Les elements de i à i+10
      if(actions1.length > 0){
        let npv  = _.sumBy(actions1, 'npv');
        npv = npv/1000000;
        yVALUES1.push(parseFloat(npv).toFixed(2));
       
      }

      // Dataset1
      const actions2 = dataset2.filter((item, index) => index <= i ); // Les elements de i à i+10
      if(actions2.length > 0){
        let npv  = _.sumBy(actions2, 'npv');
        npv = npv/1000000;
        yVALUES2.push(parseFloat(npv).toFixed(2));
       
      }

      xAXIS.push(i);
      
    } 

  const option = {
    /*title:{
      text: 'Évolution NPV par nombre d\'actions',
    },*/
    xAxis: {
        type: 'category',
        data: xAXIS,
        name: 'Nombre d\'actions',
        nameLocation: 'end'
    },
    legend:{},
    tooltip:{
      trigger: 'axis'
    },
    grid: {
      right: '20%'
    },
    yAxis: {
        type: 'value',
        name: 'NPV cumulé (Millions XOF)'
    },
    series: [
      {
        data: yVALUES1,
        type: 'line',
        name: name1,
        smooth: true,
        showSymbol: false,
        itemStyle:{
          color: '#4BB4E6'
        }
    },
    {
      data: yVALUES2,
      type: 'line',
      name: name2,
      smooth: true,
      showSymbol: false,
      itemStyle:{
        color: '#FF7900'
      }
  }
  ]
};

  // use configuration item and data specified to show chart
  this.chart.setOption(option);
}



isSteeringNetwork(data: any): data is SteeringNetwork  {
  return 'identifiant' in data && 
          'typeTraffic' in data &&
          'technologie' in data &&
          'steering2020Percent' in data &&
          'steering2021Percent' in data &&
          'steering2022Percent' in data &&
          'steering2023Percent' in data &&
          'steering2024Percent' in data &&
          'steering2025Percent' in data;
}

isSite(data: any): data is Site {
  return  'siteId' in data && 
          'sitePhysique' in data &&
          'siteStatus' in data &&
          'siteVille' in data &&
          'siteGestionnaire' in data &&
          'siteQuartier' in data &&
          'siteCommune' in data &&
          'siteDepartment' in data &&
          'siteRegion' in data &&
          'siteDistrict' in data &&
          'siteZoneCommerciale' in data &&
          'siteLongitude' in data &&
          'siteLatitude' in data &&
          'siteTowerHeight' in data &&
          'siteTypeBaie' in data &&
          'siteGeotype' in data &&
          'siteEnergyType' in data &&
          'opexKey' in data
          ;
}

// Validate data uploaded structure
validateData(data: any[], isType: Function){
  console.log(data[0]);
  if (isType(data[0])) {
    return true;
  } else{
    return false;
  }
}

// Upload Function
onFileChange(ev: any, fileTabName: string, parameterName: string) {
  // this.ngxService.start();
  let workBook = null;
  let jsonData = null;
  const reader = new FileReader();
  const file = ev.target.files[0];
  reader.onload = (event) => {
    const data = reader.result;
    workBook = XLSX.read(data, { type: 'binary' });
    jsonData = workBook.SheetNames.reduce((initial, name) => {
      const sheet = workBook.Sheets[name];
      initial[name] = XLSX.utils.sheet_to_json(sheet, {blankrows: true, raw: true});
      return initial;
    }, {});
    // const dataString = JSON.stringify(jsonData);
    console.log(jsonData);
    console.log(fileTabName);
    const intData: any[] = jsonData[fileTabName];
    console.log(intData);
    const finalData = [];

    if(!intData){
      // console.log('type nok');
      return this.uploadErrorMessage();
    }
    if(intData.length > 0){
      intData.forEach(item => {
        let newItem: any = {};
        for (let [key, value] of Object.entries(item)) {
          // Transform our data to Backend format
          newItem[_.camelCase(key)] = value;
        }
        finalData.push(newItem);
      });
    }
    console.log(finalData);
    // Determine the best function for us
    switch(parameterName) {
      case 'sitesExcluded':
        if(this.validateData(finalData, this.isSite)){
          this.sitesExcluded = finalData;
        }else{
          const input = document.getElementById('lsc') as HTMLInputElement;
          input.value = null;
          this.uploadErrorMessage();
          // console.log('upload nok');
        }
        break;
      case 'SteeringNetwork':
        if(this.validateData(finalData, this.isSteeringNetwork)){
          this.steeringNetwork = finalData;
        }else{
          const input = document.getElementById('stn') as HTMLInputElement;
          input.value = null;
          this.uploadErrorMessage();
            // console.log('upload nok');
        }
        break;
      default:
        return;
    }

  }
  reader.readAsBinaryString(file);
 /// this.ngxService.stop();
}

uploadErrorMessage(){
  this.toastr.error('Echec, le fichier n\'est pas au bon format.Merci de vérifier les entêtes.', '', {
    timeOut: 20000,
    closeButton: true,
    positionClass: 'toast-top-center',
    progressBar: true,
  });
}

}
