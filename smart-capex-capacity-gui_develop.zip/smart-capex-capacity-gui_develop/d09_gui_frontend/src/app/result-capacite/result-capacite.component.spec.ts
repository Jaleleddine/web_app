import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ResultCapaciteComponent } from './result-capacite.component';

describe('ResultCapaciteComponent', () => {
  let component: ResultCapaciteComponent;
  let fixture: ComponentFixture<ResultCapaciteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ResultCapaciteComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ResultCapaciteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
