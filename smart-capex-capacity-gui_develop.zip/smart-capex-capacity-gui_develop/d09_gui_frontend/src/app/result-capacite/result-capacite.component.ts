import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
// import * as $ from 'jquery';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { BackendService } from '../services/backend.service';
import { AuthService } from '../services/auth.service';
import { DashboardService } from '../services/dashboard.service';
import { SitesService } from '../services/sites.service';
import { UserService } from '../services/user.service'
import * as _ from 'lodash';
// import * as z from 'zebras';
// import { forkJoin, zip} from 'rxjs';
import * as echarts from 'echarts';
import * as L from 'leaflet';
import 'node_modules/leaflet.tilelayer.colorfilter/src/leaflet-tilelayer-colorfilter.js';
import * as XLSX from 'xlsx';

@Component({
  selector: 'app-result-capacite',
  templateUrl: './result-capacite.component.html',
  styleUrls: ['./result-capacite.component.css']
})
export class ResultCapaciteComponent implements OnInit {

  p =1;
  data: any[];
  dataForTable: any[];
  item: any;
  sites: any[];
  title = '';
  isUpdate = false;
  macarte: any;
  token = '';
  user: any;
  fr: any;
  npvChart: any;
  siteMarker: any;

  constructor(
    private backendService: BackendService,
    private ngxService: NgxUiLoaderService,
    private toastr: ToastrService,
    private authService: AuthService,
    private dashboardService: DashboardService,
    private siteService: SitesService,
    private userService: UserService
  ) { }

  ngOnInit(): void {
    this.fr = this.backendService.translateInFrench();
    this.user = this.authService.getUser();
      // Get token first and after initial data
      if(this.authService.isProd){
        this.userService.refreshToken().subscribe(data => {
          //console.log(data)
          this.token = data.token;
          this.authService.token.next(data.token)
          // Get initial data
          this.getFinalNPVResult();
          this.getSites();
        }, (err => {
          console.log(err);
          this.toastr.error('Une erreur est survenue pendant le chargement de la page.', '', {
            timeOut: 10000,
            closeButton: true,
            positionClass: 'toast-top-center',
            progressBar: true,
          });
        }))
      } else {
          this.token = this.authService.getToken();
          this.authService.token.next(this.token)
          // Get initial data
          this.getFinalNPVResult();
          this.getSites();
      }
  }

  getSites(){
    this.siteService.getItems(this.token).subscribe(data => {
      this.sites = data;
      console.log(this.sites);
    }, (err) => {
      console.log(err);
      this.toastr.error('Une erreur est survenue pendant le chargement des sites', '', {
        timeOut: 10000,
        closeButton: true,
        positionClass: 'toast-top-center',
        progressBar: true,
      });
    })
  }


  exportToExcel(data: any[]): void {
    console.log(data);
   const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(data);
   // const wsDetails: XLSX.WorkSheet = XLSX.utils.json_to_sheet(details);
   const wb: XLSX.WorkBook = XLSX.utils.book_new();
   XLSX.utils.book_append_sheet(wb, ws, 'CAPACITY_FINAL_NPV');
   XLSX.writeFile(wb, 'CAPACITY_FINAL_NPV.xlsx');
}

  getFinalNPVResult(){
    this.backendService.getFinalNPV(this.token).subscribe(data => {
      this.data = data;
      // Caster nos npv en nombre
      this.data.forEach(item => {
        item.npv = item.npv ? parseFloat(item.npv).toFixed(2) : 0;
        item.cashFlowYear0 = parseFloat(item.cashFlowYear0).toFixed(2);
        item.cashFlowYear1 = parseFloat(item.cashFlowYear1).toFixed(2);
        item.cashFlowYear2 = parseFloat(item.cashFlowYear2).toFixed(2);
        item.cashFlowYear3 = parseFloat(item.cashFlowYear3).toFixed(2);
        item.cashFlowYear4 = parseFloat(item.cashFlowYear4).toFixed(2);
        item.cashFlowYear5 = parseFloat(item.cashFlowYear5).toFixed(2);
        item.cashFlowYear6 = item.cashFlowYear6== 'NA' ? 0 : parseFloat(item.cashFlowYear6).toFixed(2)
      });

      // Ordonner nos résultats
      this.data = _.orderBy(this.data, 'npv', 'desc');
    
      this.dataForTable = this.data;
      console.log(this.data);
    }, (error) => {console.log(error)})
  }

  heatMap(site?): void{
    // this.ngxService.start();
    if (!this.macarte){
      this.macarte = L.map('macarte', { zoomControl: false }).setView([this.backendService.latitude, this.backendService.longitude], 6);
      (L.tileLayer as any).colorFilter(this.backendService.tileUrl, {
    minZoom: 5,
    maxZoom: 20,
    // filter: ['grayscale:100%', 'invert:0%']
    }).addTo(this.macarte);
     // Positionner le zoom panel
      new L.Control.Zoom({ position: 'bottomleft' }).addTo(this.macarte);
      // Le découpage commercial
      this.initDecoupageCommercial(this.macarte);
    }
  }

  onEachFeature(feature, layer): void {
    // console.log('count');
    // does this feature have a property named popupContent?
    // feature.properties.QUARTIER && feature.properties.COMMUNE
    if (feature.properties.ZC) {
        layer.
        bindTooltip(`
            <div style="background:#FFF">
            <div style="color:#000;text-align: center;font-weight: bold;font-size: 14px;margin:0px auto;">
            ${feature.properties.ZC}
            </div>

            <table class="tooltip-table">
              <tr>
                <td>${feature.properties.Superf} KM²</td>
              </tr>
            </table>
            </div>
            `, {className: 'small-tooltip'});
        }
  }

  initDecoupageCommercial(map): void {
    const colors = ['#085EBD', '#0A6E31', '#FF8AD4', '#FFB400', '#492191', '#595959', '#000000', '#4BB4E6', '#A885D8',
  '#FF7900', '#62342D', '#FFD200', '#FFF6B6', '#880E4F', '#FFAB91'];
    this.backendService.getZoneCommerciale().subscribe((zones) => {
      zones.features.forEach((feacture, index) => {
        feacture.properties.index = index;
      });
      console.log(zones);
      L.geoJSON(zones, {
        style: (feature) => {
            return {color: colors[feature.properties.index], weight: 0.3, opacity: 0.3,fillOpacity: 0.1};
        },
        onEachFeature: this.onEachFeature
    }).addTo(map);
    });
  }

  close(){
    document.getElementById("myModal").style.display = "none";
  }

  globalFilter(value: any): any {
    if (!value) {
      this.dataForTable = this.data;
    } else {
      this.dataForTable = this.data.filter((val) => {
        const rVal = (
          val.siteId.includes(value) || val.cellBand.includes(value)
         );
        return rVal;
      });
    }
  }

  showDetails(result?){
    console.log(result);
    this.item = result;
    document.getElementById("myModal").style.display='block';
    this.heatMap();
    // Rechercher tous les résultats concernant le site
    const datas = this.data.filter(item => item.siteId == result.siteId);
    console.log(datas);
    // On crée notre courbe d'évolution
    this.evolCashFlow(datas);
    // Search siteLocation
    const siteLocated = this.sites.filter(item => item.siteId == result.siteId);
    console.log(siteLocated[0]);
    if(siteLocated.length > 0){
      // Supprimer un ancien site positionné
      if(this.siteMarker){
        this.macarte.removeLayer(this.siteMarker)
      }
      const Dicon = L.divIcon({
        className: 'custom-div-icon',
        html: `<div style='background-color:#FF7900;
        'class='marker-pin'><i class=""></i></div>`,
        iconSize: [30, 42],
        iconAnchor: [15, 42]
    });
      const site = siteLocated[0];
      this.siteMarker = L.marker([site.siteLatitude, site.siteLongitude], {icon: Dicon}).addTo(this.macarte);
      this.siteMarker.bindTooltip(`
      <div style="background:#FFF">
      <div style="color:#000;text-align: center;font-size: 14px;margin:0px auto;">
      ${site.siteId} | ${site.sitePhysique}
      </div>
      <table class="tooltip-table">
        <tr>
          <td>Geo Type:</td>
          <td>${site.siteGeotype}</td>
        </tr>
        <tr>
          <td>Type Baie:</td>
          <td>${site.siteTypeBaie}</td>
        </tr>
        <tr>
          <td>Zone Commerciale:</td>
          <td>${site.siteZoneCommerciale}</td>
        </tr>
        <tr>
          <td>Site Gestionnaire:</td>
          <td>${site.siteGestionnaire}</td>
        </tr>
        <tr>
          <td>District:</td>
          <td>${site.siteDistrict}</td>
        </tr>
        <tr>
          <td>Région:</td>
          <td>${site.siteRegion}</td>
        </tr>
        <tr>
          <td>Département:</td>
          <td>${site.siteDepartment}</td>
        </tr>
        <tr>
          <td>Ville:</td>
          <td>${site.siteVille}</td>
        </tr>
        <tr>
          <td>Commune:</td>
          <td>${site.siteCommune}</td>
        </tr>
        <tr>
          <td>Quartier:</td>
          <td>${site.siteQuartier}</td>
        </tr>
        <tr>
          <td>Status:</td>
          <td>${site.siteStatus}</td>
        </tr>
      </table>
      </div>
      `, {className: 'tooltip'});
    }
  }

  evolCashFlow(data: any[]){
    if(!this.npvChart){
      this.npvChart = echarts.init(document.getElementById('cashflowchart'));
    }
    const series = [];
    const XAXIS = ['Annee 0', 'Annee 1', 'Annee 2', 'Annee 3', 'Annee 4', 'Annee 5', 'Annee 6'];
    const colors = ['#FF7900', '#4BB4E6', '#50BE87', '#A885D8', '#FFD200', '#0000'];
    data.forEach((item, index) => {
      // Si le cashFlowYear6 est égal à 0, on le supprime du graphe
      if(item.cashFlowYear6 == 0){
        series.push({
          data: [(parseFloat(item.cashFlowYear0)/1000000).toFixed(2), (parseFloat(item.cashFlowYear1)/1000000).toFixed(2), (parseFloat(item.cashFlowYear2)/1000000).toFixed(2),
            (parseFloat(item.cashFlowYear3)/1000000).toFixed(2), (parseFloat(item.cashFlowYear4)/1000000).toFixed(2), (parseFloat(item.cashFlowYear5)/1000000).toFixed(2)],
          type: 'line',
          name: item.siteId + '-' + item.cellBand,
          smooth: true,
          itemStyle:{
            color: colors[index]
          }
      })
      }else {
        series.push({
          data: [(parseFloat(item.cashFlowYear0)/1000000).toFixed(2), (parseFloat(item.cashFlowYear1)/1000000).toFixed(2), (parseFloat(item.cashFlowYear2)/1000000).toFixed(2),
            (parseFloat(item.cashFlowYear3)/1000000).toFixed(2), (parseFloat(item.cashFlowYear4)/1000000).toFixed(2), (parseFloat(item.cashFlowYear5)/1000000).toFixed(2), (parseFloat(item.cashFlowYear6)/1000000)],
          type: 'line',
          name: item.siteId + '-' + item.cellBand,
          smooth: true,
          itemStyle:{
            color: colors[index]
          }
      })
      }

    });

    // Les options de notre graphe
    const option = {
      title:{
        text: 'Évolution CashFlow par année',
      },
      xAxis: {
          type: 'category',
          data: XAXIS,
          name: 'Période',
          nameLocation: 'end'
      },
      legend:{
        bottom: 0
      },
      tooltip:{
        trigger: 'axis'
      },
      grid: {
        right: '20%'
      },
      yAxis: {
          type: 'value',
          name: 'CashFlow (Millions XOF)'
      },
      series
  };
  
    // use configuration item and data specified to show chart
    this.npvChart.setOption(option);
  }



}
