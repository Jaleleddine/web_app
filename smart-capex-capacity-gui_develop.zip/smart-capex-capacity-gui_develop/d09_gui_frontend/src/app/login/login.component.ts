import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup} from '@angular/forms';
import { AuthService } from '../services/auth.service';
import { Router, ActivatedRoute} from '@angular/router';
import * as _ from 'lodash'
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private route: ActivatedRoute,
    private cookieService: CookieService
    ) { }
  loginForm: FormGroup;
  errors = [];
  loginError = '';
  submited = false;
  returnUrl = '';
  date = new Date();
  get login() { return this.loginForm.get('login'); }
  get password() { return this.loginForm.get('password'); }

  ngOnInit() {
    this.authService.logout();
    console.log('is authenticated? :' + this.authService.isAuthenticated());
    this.loginForm = this.fb.group({
      login: ['', [Validators.required]],
      password: ['', [Validators.required]]
    });
    // console.log(this.auth.authenticationState.value);
  }

  // Getters
  // get email() { return this.loginForm.get('email'); }
  get f() { return this.loginForm.controls; }

  onSubmit() {
    this.errors = [];
    this.submited = true;
    this.loginForm.get('login').setValue(this.loginForm.get('login').value.toLowerCase());
    this.authService.login(this.loginForm.value).subscribe((result) => {
      this.submited = false;
      console.log(result);
      // Save data in session storage without token in production
      const data = this.authService.isProd ?_.omit(result, ['token','id','username']): _.omit(result, ['id','username']);
      window.sessionStorage.setItem(this.authService.STORAGE_ID, JSON.stringify(data));
      window.sessionStorage.setItem('state', '1');
      this.authService.token.next(result.token);
      this.authService.authenticationState.next(true);
      console.log('is authenticated? :' + this.authService.isAuthenticated());
      this.cookieService.set( 'timer', new Date().toString(), {expires: 0.042, sameSite: 'Lax'});// expires in 1 hour
      this.router.navigate(['/dashboard']);
    },
    (err) => {
      console.log(err);
      const error = err.error.error ? err.error.error : err.error;
      // console.log(error.statusCode)
      if (err.status === 403) {
        this.loginError = 'Mot de passe ou login AD invalide!'
      } else {
        this.loginError = 'Mot de passe ou login applicatif invalide!'
      }
      this.submited = false;
    },
    );
}

}
