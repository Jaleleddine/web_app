import { Component, OnInit } from '@angular/core';
import { NgxUiLoaderService } from "ngx-ui-loader";
import { ToastrService } from 'ngx-toastr';
import { BackendService } from '../services/backend.service';
import * as echarts from 'echarts';
import * as L from 'leaflet';
import 'node_modules/leaflet.tilelayer.colorfilter/src/leaflet-tilelayer-colorfilter.js';
import 'node_modules/leaflet.markercluster/dist/leaflet.markercluster.js';
import { DashboardService } from '../services/dashboard.service';
import { SitesService } from '../services/sites.service';
import { AuthService } from '../services/auth.service';
import { UserService } from '../services/user.service'
import * as XLSX from 'xlsx';
import * as moment from 'moment';
import * as _ from 'lodash';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  fr: any;
  user: any;
  token: string;
  isTabOneVisible = true;
  isTabTwoVisible = false;
  legend: any;
  /*************** GRAPHIQUES **************/
  chart: any;
  voixByTechnoChart: any;
  dataByTechnoChart: any;
  dataVSChart: any;
  congestBandChart: any;
  congestTechnoChart: any;
  debitBandChart: any;
  debitTechnoChart: any;

  macarte: any;
  congestMap: any;
  sites: any[];
  KPIs: any;
  mapLayer: any;
  /******************** KPIS ***************/
  TRAFICVOICE_BEGIN: string | number = 0;
  TRAFICVOICE_END: string | number = 0;
  TRAFICDATA_BEGIN: string | number = 0;
  TRAFICDATA_END: string | number = 0;
  EVOL_TRAFICVOICE: string | number = 0;
  EVOL_TRAFICDATA: string | number = 0;

  locations: any; // Les différentes localisations (sites, quartiers, villes, communes etc ...)
  currentLocations: any[]; // Le filtre courant sur les localisations
  selectedLocation: string; // La localisation choisie pour le dashboard
  periode: string | number;
  periodeEnd: string | number;
  start: any;
  end: any;
  monthSelected: Date; // Le mois choisi
  weekSelected: Date = new Date(); // La semaine choisie
  weekPeriode: string | number; // La période de la semaine
  periodeType: string; // Le type de période (date, year, week_period)
  locationType: string; // Le type de localisation (site_physique, site_ville, site_quartier, site_commune, site_department, site_region, site_district, site_zone_commerciale)
  yearSelected: string; // L'année choisie
  isWeekSelected = true;
  isMonthSelected = false;
  isYearSelected = false;
  nbreSiteCongested = 0; // Nombre de sites congestionnés
  sitesCongested = []; // sites congestionnés

  constructor(
    private userService: UserService,
    private ngxService: NgxUiLoaderService,
    private backendService: BackendService,
    private dashboardService: DashboardService,
    private siteService: SitesService,
    private authService: AuthService,
    private toastr: ToastrService
    ) { }

  ngOnInit(): void {
    this.fr = this.backendService.translateInFrench();
    this.user = this.authService.getUser();
    this.weekPeriode = this.backendService.getWeekPeriod();
    this.heatMap();
     // Get token first and after initial data
     if(this.authService.isProd){
      this.userService.refreshToken().subscribe(data => {
        //console.log(data)
        this.token = data.token;
        this.authService.token.next(data.token)
        // Get initial data
        this.getData();
      }, (err => {
        console.log(err);
        this.toastr.error('Une erreur est survenue pendant le chargement de la page.', '', {
          timeOut: 10000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      }))
    } else {
        this.token = this.authService.getToken();
        this.authService.token.next(this.token)
        // Get initial data
        this.getData();
    }
  }

  scrollToFixed(){
    // Get the header
  const header = document.getElementById("filter");
// Get the offset position of the navbar
  const sticky = header.offsetTop;

// Add the sticky class to the header when you reach its scroll position. Remove "sticky" when you leave the scroll position
  if (window.pageYOffset > sticky) {
      header.classList.add("fix");
  } else {
      header.classList.remove("fix");
    }
}


  exportToExcel(data: any[]): void {
    console.log(data);
   const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(data);
   const wb: XLSX.WorkBook = XLSX.utils.book_new();
   XLSX.utils.book_append_sheet(wb, ws, 'SITES_CONGESTIONNES');
   XLSX.writeFile(wb, 'SITES_CONGESTIONNES.xlsx');
}
// Choisir la période de recherche
togglePeriode(periode: string){
  switch (periode) {
    case 'week':
      this.isWeekSelected = true;
      this.isMonthSelected = false;
      this.isYearSelected = false;
      this.periodeType = 'week_period';
      break;
    case 'month':
      this.isWeekSelected = false;
      this.isMonthSelected = true;
      this.isYearSelected = false;
      this.periodeType = 'date';
      break;
    case 'year':
      this.isWeekSelected = false;
      this.isMonthSelected = false;
      this.isYearSelected = true;
      this.periodeType = 'year';
      break;
    default:
      break;
  }
}

// Charger nos données
getData(){
  this.getSites();
  this.getLocations();
}

// Charger toutes les localisations (à l'échelle nationale)
loadALLLocations(e?){
  const isChecked = e ? e.target.checked : true;
  if(isChecked){
    // Initialisation de notre zone de recherche
    const checkedbox = document.getElementById("all-location") as HTMLInputElement;
    checkedbox.checked = true;
    this.currentLocations = this.locations['sitePhysiques'];
    this.selectedLocation = '';

    // La recherche sur tous les sites
      this.dashboardService.getALLLocationKPIs(this.token, this.periodeType, this.periode, this.periodeEnd).subscribe(data => {
      console.log(data);
      const width = this.getBarWidth(this.periodeType);
      this.getPeriodeStartANDEnd(this.periodeType);
      this.KPIs = data;
      this.TRAFICDATA_BEGIN = data.TRAFICDATA_BEGIN;
      this.TRAFICDATA_END =  data.TRAFICDATA_END;
      this.EVOL_TRAFICDATA = data.EVOL_TRAFICDATA;
      // TRAFIC VOICE KPI
      this.TRAFICVOICE_BEGIN = data.TRAFICVOICE_BEGIN;
      this.TRAFICVOICE_END =  data.TRAFICVOICE_END;
      this.EVOL_TRAFICVOICE = data.EVOL_TRAFICVOICE;
      this.traficActuelVSTraficPredit(data.TRAFFICVOICE, 'Trafic(GErlang)', 1000);
      this.dataActuelVSTraficPredit(data.TRAFFICDATA, 'Trafic (TB)', 1000);
      this.voixByTechno(data.TRAFFICVOICETECH, width);
      this.dataByTechno(data.TRAFFICDATATECH, width);
      this.congestByTechno(this.KPIs.CELLOCCUPATIONTECH, width),
      this.debitByTechno(this.KPIs.DEBITTECH, /*width*/ data.TRAFICDATA);
      this.sitesCongested = _.intersectionBy(data.sites,data.sitesCongestion, 'site_id');
      this.nbreSiteCongested = this.sitesCongested.length; // le nombre de sites congestionnés
      this.SiteMapping(data.sites);
    }, (err) => {
      console.log(err);
      this.toastr.error('Une erreur est survenue pendant la mise à jour des KPIs.', '', {
        timeOut: 10000,
        closeButton: true,
        positionClass: 'toast-top-center',
        progressBar: true,
      });
    })
  }else {
    // Rénitialisation sur l'ensemble du territoire
    this.currentLocations = this.locations['sitePhysiques'];
    this.selectedLocation = this.locations['sitePhysiques'][0];
    this.getKPIs(this.locationType, this.selectedLocation, this.periodeType, this.periode, this.periodeEnd);
  }
  console.log(isChecked);
}

// Get current locations for search
getCurrentLocations(value){
  this.selectedLocation = null;
  this.currentLocations = this.locations[value];
  switch (value) {
    case 'sitePhysiques':
      this.locationType = 'site_physique';
      break;
    case 'quartiers':
     this.locationType = 'site_quartier';
      break;
    case 'villes':
      this.locationType = 'site_ville';
      break;
    case 'communes':
      this.locationType = 'site_commune';
      break;
    case 'departements':
      this.locationType = 'site_department';
      break;
    case 'regions':
      this.locationType = 'site_region';
      break;
    case 'districts':
      this.locationType = 'site_district';
      break;
    case 'zonesCommerciales':
      this.locationType = 'site_zone_commerciale';
      break;
    default:
      break;
  }
}

// chercher les données de cette période à partir du backend
getLocationData(value, type ?: string, isAll?: number){
  //console.log(value);
  switch (type) {
    case 'week':
      this.periode = parseInt(this.backendService.getWeekPeriod(this.weekSelected));
      this.periodeEnd = parseInt(this.backendService.getWeekPeriodEnd(this.weekSelected));
      /*this.start = this.periode;
      this.end = this.periodeEnd;*/
      this.weekPeriode = this.periode; // Mise à jour de la semaine sur l'interface
      this.getKPIs(this.locationType, this.selectedLocation, this.periodeType, this.periode, this.periodeEnd);
      break;
    case 'month':
      this.periode = this.backendService.getMonthPeriode(this.monthSelected);
      this.periodeEnd = this.backendService.getMonthPeriodeEnd(this.monthSelected);
      /*this.start = moment(this.periode).format('YYYY-MM');
      this.end = moment(this.periodeEnd).format('YYYY-MM');*/
      this.getKPIs(this.locationType, this.selectedLocation, this.periodeType, this.periode, this.periodeEnd);
      break;
    case 'year':
      this.periode = parseInt(this.yearSelected);
      this.periodeEnd = parseInt(this.yearSelected) + 2;
      /*this.start = this.periode;
      this.end = this.periodeEnd;*/
      this.getKPIs(this.locationType, this.selectedLocation, this.periodeType, this.yearSelected, this.periodeEnd);
      break;
    case 'location':
      this.getKPIs(this.locationType, this.selectedLocation, this.periodeType, this.periode, this.periodeEnd);
      break;
    default:
      break;
  }
}

// Obtenir la période de départ et la période de fin sur l'interface
getPeriodeStartANDEnd(periodeType: string){
  this.start = periodeType == 'date' ?  moment(this.periode).format('YYYY-MM') : this.periode;
  this.end = periodeType == 'date' ? moment(this.periodeEnd).format('YYYY-MM') : this.periodeEnd;
}

// Obtenir la taille des bars de nos histogrammes
getBarWidth(periodeType: string){
  let width = 40;
  switch (periodeType) {
    case 'week_period':
        width = 5;
      break;
    case 'date':
      width = 15;
      break;
    default:
      break;
  };
  return width;
}

// get KPI from Backend
getKPIs(locationType, location, periodeType, periode, periodeEnd){
  this.dashboardService.getForecastingKPIs(this.token, locationType, location, periodeType, periode, periodeEnd).subscribe(data => {
    //console.log(data);
    // Définir la taille des bars
    const width = this.getBarWidth(periodeType);
    this.getPeriodeStartANDEnd(periodeType);
    this.KPIs = data;
    this.TRAFICDATA_BEGIN = data.TRAFICDATA_BEGIN;
    this.TRAFICDATA_END =  data.TRAFICDATA_END;
    this.EVOL_TRAFICDATA = data.EVOL_TRAFICDATA;
    // TRAFIC VOICE KPI
    this.TRAFICVOICE_BEGIN = data.TRAFICVOICE_BEGIN;
    this.TRAFICVOICE_END =  data.TRAFICVOICE_END;
    this.EVOL_TRAFICVOICE = data.EVOL_TRAFICVOICE;
    this.traficActuelVSTraficPredit(data.TRAFFICVOICE, 'Trafic(Erlang)', 1);
    this.dataActuelVSTraficPredit(data.TRAFFICDATA, 'Trafic(GB)', 1);
    this.voixByTechno(data.TRAFFICVOICETECH, width);
    this.dataByTechno(data.TRAFFICDATATECH, width);
    this.congestByTechno(this.KPIs.CELLOCCUPATIONTECH, width),
    this.debitByTechno(this.KPIs.DEBITTECH, /*width*/data.TRAFICDATA);

    this.sitesCongested = _.intersectionBy(data.sites,data.sitesCongestion, 'site_id');
    this.nbreSiteCongested = this.sitesCongested.length; // le nombre de sites congestionnés
    this.SiteMapping(data.sites);
  }, (err) => {
    console.log(err);
    this.toastr.error('Une erreur est survenue pendant la mise à jour des KPIs.', '', {
      timeOut: 10000,
      closeButton: true,
      positionClass: 'toast-top-center',
      progressBar: true,
    });
  })
}

// Obtenir la liste  des sites Techniques OCI
getSites(){
    this.siteService.getItems(this.token).subscribe(data => {
      console.log(data);
      this.sites = data; 
    }, (err) => {
      console.log(err);
      this.toastr.error('Une erreur est survenue pendant le chargement des sites', '', {
        timeOut: 10000,
        closeButton: true,
        positionClass: 'toast-top-center',
        progressBar: true,
      });
    })
  }

  // Réinitialiser le search
  reinitSearch(){
      // Filtres par défaut
      this.currentLocations = this.locations['sitePhysiques'];
      this.selectedLocation = this.locations['sitePhysiques'][0];
      this.locationType = 'site_physique';
      this.periodeType = 'week_period';
      this.periode = parseInt(this.backendService.getWeekPeriod(new Date()));
      this.periodeEnd = parseInt(this.backendService.getWeekPeriodEnd(new Date()));
      this.start = this.periode;
      this.end = this.periodeEnd;
      this.getKPIs(this.locationType, this.selectedLocation, this.periodeType, parseInt(this.backendService.getWeekPeriod(new Date())), this.periodeEnd);
  }

  getLocations(){
    this.dashboardService.getLocations(this.token).subscribe(data => {
      console.log(data);
      this.locations = data;
     this.reinitSearch();
    }, (err) => {
      console.log(err);
      this.toastr.error('Une erreur est survenue pendant le chargement des localisations', '', {
        timeOut: 10000,
        closeButton: true,
        positionClass: 'toast-top-center',
        progressBar: true,
      });
    })
  }

  getColor(congestion) {
    let color = '';
    if (congestion === undefined) {
      color = '#50BE87';
    } else {
      color = '#CD3C14';
    }
    return color;
  }

  SiteMapping(data: any[]) {
    if (data.length > 0) {
      const markersCluster = new (L as any).MarkerClusterGroup(); // Un groupe de marker
  
      data.forEach(site => {
  
        if (site.latitude !== 'NULL' && site.longitude !== 'NULL') {
          const congestion = site.congestion;
          // Classifier les sites par des couleurs (Les couleurs affichées sur la carte)
          const color = this.getColor(site.congestion);
          const Dicon = L.divIcon({
              className: 'custom-div-icon',
              html: `<div style='background-color:${color};
              'class='marker-pin'><i class=""></i></div>`,
              iconSize: [30, 42],
              iconAnchor: [15, 42]
          });
  
          /*const lat = site.site_latitude.replace(',', '.');
          const long = site.site_longitude.replace(',', '.');*/
            // Positionner le site sur la carte
          const marker = L.marker([site.latitude, site.longitude], {icon: Dicon});
  
          marker.bindTooltip(`
              <div style="background:#FFF">
              <div style="color:#000;text-align: center;font-size: 14px;margin:0px auto;">
              ${site.site_id} | ${site.sitename}
              </div>
              <table class="tooltip-table">
                <tr>
                  <td>Zone Commerciale:</td>
                  <td>${site.sitezone}</td>
                </tr>
                <tr>
                  <td>Site Gestionnaire:</td>
                  <td>${site.sitegestionnaire}</td>
                </tr>
                <tr>
                  <td>District:</td>
                  <td>${site.sitedistrict}</td>
                </tr>
                <tr>
                  <td>Région:</td>
                  <td>${site.siteregion}</td>
                </tr>
                <tr>
                  <td>Département:</td>
                  <td>${site.sitedepartement}</td>
                </tr>
                <tr>
                  <td>Ville:</td>
                  <td>${site.siteville}</td>
                </tr>
                <tr>
                  <td>Commune:</td>
                  <td>${site.sitecommune}</td>
                </tr>
                <tr>
                  <td>Quartier:</td>
                  <td>${site.sitequartier}</td>
                </tr>
                <tr>
                  <td>Status:</td>
                  <td>${site.sitestatus}</td>
                </tr>
                <tr>
                  <td>Site GeoType:</td>
                  <td>${site.siteGeotype}</td>
                </tr>
                <tr>
                  <td>Congestion:</td>
                  <td>${site.congestion ? site.congestion: '-'}</td>
                </tr>
                <tr>
                  <td>Bandes Upgradées:</td>
                  <td>${site.bandsUpgraded ? site.bandsUpgraded: '-'}</td>
                </tr>
                <tr>
                  <td>Date Congestion:</td>
                  <td>${site.date ? site.date: '-'}</td>
                </tr>
                <tr>
                  <td>Site Tech:</td>
                  <td>${site.siteTech ? site.siteTech: '-'}</td>
                </tr>
                <tr>
                  <td>Tech Upgraded:</td>
                  <td>${site.techUpgraded ? site.techUpgraded: '-'}</td>
                </tr>
                <tr>
                  <td>Week Period:</td>
                  <td>${site.weekPeriod ? site.weekPeriod: '-'}</td>
                </tr>
              </table>
              </div>
              `, {className: 'tooltip'});
  
            markersCluster.addLayer(marker);
              // Ajout du site à sa catégorie
            }
      });
  
      // On suprrime une éventuelle couche sur la carte
      if (this.mapLayer) {
        this.macarte.removeLayer(this.mapLayer);
      }
     // this.macarte.removeLayer(this.mapLayer);
     this.mapLayer = markersCluster;
      this.macarte.addLayer(this.mapLayer);
  
    }
  }

  drawLegend() {
    // <span><i style="background:#2ca961;color:#2ca961;">color</i> SANS DÉPHASAGE<span/> <br/> <br/>
    // Création de légende
   return `
    <span>[ SITE STATUS ]<span/> <br/><br/>
    <span><i style="background:#50BE87;
    color:#50BE87;display:inline-block;width: 15px;height: 15px;border-radius: 50%;"></i> NO CONGESTION <span/><br/>
      <span><i style="background:#CD3C14;
    color:#CD3C14;display:inline-block;width: 15px;height: 15px;border-radius: 50%;"></i> WITH CONGESTION <span/><br/>
   `;
  }
  

  heatMap(site?): void{
    // this.ngxService.start();
    if (!this.macarte){
      this.macarte = L.map('macarte', { zoomControl: false }).setView([this.backendService.latitude, this.backendService.longitude], 6);
      (L.tileLayer as any).colorFilter(this.backendService.tileUrl, {
    minZoom: 5,
    maxZoom: 20,
    // filter: ['grayscale:100%', 'invert:0%']
    }).addTo(this.macarte);
     // Positionner le zoom panel
      new L.Control.Zoom({ position: 'bottomleft' }).addTo(this.macarte);
      // Positionner la légende
      const div = L.DomUtil.create('div', 'info legend');
      div.innerHTML += this.drawLegend();
      this.legend = L.Control.extend({
              options: {
                position: 'bottomleft'
                // control position - allowed: 'topleft', 'topright', 'bottomleft', 'bottomright'
              },
              onAdd(map) {
                return div;
              },
            });
      this.macarte.addControl(new this.legend());
      // Le découpage commercial
      this.initDecoupageCommercial(this.macarte);
    }
  }

  onEachFeature(feature, layer): void {
    // console.log('count');
    // does this feature have a property named popupContent?
    // feature.properties.QUARTIER && feature.properties.COMMUNE
    if (feature.properties.ZC) {
        layer.
        bindTooltip(`
            <div style="background:#FFF">
            <div style="color:#000;text-align: center;font-weight: bold;font-size: 14px;margin:0px auto;">
            ${feature.properties.ZC}
            </div>

            <table class="tooltip-table">
              <tr>
                <td>${feature.properties.Superf} KM²</td>
              </tr>
            </table>
            </div>
            `, {className: 'small-tooltip'});
        }
  }

  initDecoupageCommercial(map): void {
    const colors = ['#085EBD', '#0A6E31', '#FF8AD4', '#FFB400', '#492191', '#595959', '#000000', '#4BB4E6', '#A885D8',
  '#FF7900', '#62342D', '#FFD200', '#FFF6B6', '#880E4F', '#FFAB91'];
    this.backendService.getZoneCommerciale().subscribe((zones) => {
      zones.features.forEach((feacture, index) => {
        feacture.properties.index = index;
      });
      console.log(zones);
      L.geoJSON(zones, {
        style: (feature) => {
            return {color: colors[feature.properties.index], weight: 0.3, opacity: 0.3,fillOpacity: 0.1};
        },
        onEachFeature: this.onEachFeature
    }).addTo(map);
    });
  }

  traficActuelVSTraficPredit(data: any[], yAxisName, factor){
    if(!this.chart){
      this.chart = echarts.init(document.getElementById('chart-voix'));
    }
    const datas = [];
    const cats = [];
    data.forEach(item => {
      const value = (parseFloat(item.sum)/factor).toFixed(2)
      datas.push(value);
      cats.push(item.group);
    });
    const option = {
      title:{
        text: 'Évolution Trafic voix Prédit',
      },
      /*dataZoom: [{
        type: 'inside',
        start: 0,
        end: 50
    }, {
        start: 0,
        end: 50
    }],*/
      xAxis: {
          type: 'category',
          data: cats,//['01/2021', '02/2021', '03/2021'],
          name: 'Période',
          nameLocation: 'end'
      },
      legend:{
        bottom: 0
      },
      tooltip:{
        trigger: 'axis'
      },
      grid: {
        right: '20%'
      },
      yAxis: {
          type: 'value',
          name: yAxisName
      },
      series: [
        {
          data: datas,//[409, 780, 720],
          type: 'line',
          name: 'TRAFIC PREDIT',
          smooth: true,
          showSymbol: false,
          itemStyle:{
            color: '#FF7900'
          }
      },
      /*{
        data: [520, 480, 420],
        type: 'line',
        name: 'TRAFIC ACTUEL',
        smooth: true,
        itemStyle:{
          color: '#FF7900'
        }
    }*/
    ]
  };
  
    // use configuration item and data specified to show chart
    this.chart.setOption(option);
  }

 
  debitByTechno(data: any, traficData: any){
    if(!this.debitTechnoChart){
      this.debitTechnoChart = echarts.init(document.getElementById('debit-techno'));
    }
 
    const cats = _.keys(data);
    const G2Data = [];
    const G3Data = [];
    const G4Data = [];
    const mean = []; // La moyenne du débit
    const TOTAL_TRAFFICDATA = 0;

    for (const property in data) {
      const item: any[] = data[property];
      
      /**
       * Find period data which not predicted
       */
      // Key By TECHNO (2G, 3G, or 4G)
      const keys = ['2G','3G','4G']
      const keyByTechno = _.keyBy(item, function(o) {return o.group;});
      const keyProvided = _.keys(keyByTechno);
      const keyNotProvided: [] = _.difference(keys, keyProvided);

      // We give 0 as data for the techno which not provided
      keyNotProvided.forEach(key => {
        item.push({group: key, mean:0})
      })
      // mean.push(parseFloat(_.meanBy(item, function(o) { return o.mean; })).toFixed(2)); // On prend la moyenne des congestions
      item.forEach(el => {
        switch (el.group) {
          case '2G':
            const G2Value = parseFloat(el.mean).toFixed(2);
            G2Data.push(G2Value);
            break;
          case '3G':
            const G3Value = parseFloat(el.mean).toFixed(2);
            G3Data.push(G3Value);
            break;
          case '4G':
            // console.log(el.sum);
            const G4Value = parseFloat(el.mean).toFixed(2);
            G4Data.push(G4Value);
            break;
          default:
            break;
        }
      } )
    }

    const option = {
      /*title:{
        text: 'Débit Moyen Prédit par Techno',
      },*/
      tooltip: {
          trigger: 'axis',
          axisPointer: {            // Use axis to trigger tooltip
              type: 'line'        // 'shadow' as default; can also be 'line' or 'shadow'
          }
      },
      /*dataZoom: [{
        type: 'slider',
        start: 0,
        end: 30,
        bottom: -8,
    }, {
        start: 0,
        end: 30,
        bottom: -8
    }],*/
      legend: {
          data: ['2G', '3G', '4G'],
          top: 0,
          right: 0
      },
      grid: {
          left: '3%',
          right: '4%',
          bottom: '8%',
          containLabel: true
      },
      yAxis: {
          type: 'value',
          name: 'Débit(kbps)'
      },
      xAxis: {
          type: 'category',
          data: cats,//['01/2021', '02/2021'],
          name: 'Période',
          nameLocation: 'center'
      },
      series: [
          {
              name: '2G',
              type: 'line',
              //stack: 'techno',
              //barWidth: width,
              label: {
                  show: false
              },
              smooth: true,
              showSymbol: false,
              itemStyle:{
                color: '#B5E8F7'
              },
              emphasis: {
                  focus: 'series'
              },
              data: G2Data//[320, 302]
          },
          {
              name: '3G',
              type: 'line',
              //stack: 'techno',
              //barWidth: width,
              itemStyle:{
                color: '#4BB4E6'
              },
              smooth: true,
              showSymbol: false,
              label: {
                  show: false
              },
              emphasis: {
                  focus: 'series'
              },
              data: G3Data//[120, 132]
          },
          {
              name: '4G',
              type: 'line',
              //stack: 'techno',
              //barWidth: width,
              smooth: true,
              showSymbol: false,
              itemStyle:{
                color: '#085EBD'
              },
              label: {
                  show: false
              },
              emphasis: {
                  focus: 'series'
              },
              data: G4Data, //[220, 182]
          },
          /*{
            name: 'Débit Moyen',
            type: 'line',
            smooth: true,
            showSymbol: false,
            itemStyle:{
              color: '#FF7900'
            },
            label: {
                show: true
            },
            emphasis: {
                focus: 'series'
            },
            data: mean,
        },*/
        
      ]
  };
    // use configuration item and data specified to show chart
    this.debitTechnoChart.setOption(option);
  }

  
  congestByTechno(data: any, width){
    if(!this.congestTechnoChart){
      this.congestTechnoChart = echarts.init(document.getElementById('congest-techno'));
    } 
    const cats = _.keys(data);
    const G2Data = [];
    const G3Data = [];
    const G4Data = [];
    // const mean = []; // La moyenne des congestions

    for (const property in data) {
      const item: any[] = data[property];
      // console.log(item);

      /**
       * Find period data which not predicted
       */
      // Key By TECHNO (2G, 3G, or 4G)
      const keys = ['2G','3G','4G']
      const keyByTechno = _.keyBy(item, function(o) {return o.group;});
      const keyProvided = _.keys(keyByTechno);
      const keyNotProvided: [] = _.difference(keys, keyProvided);

      // We give 0 as data for the techno which not provided
      keyNotProvided.forEach(key => {
        item.push({group: key, mean:0})
      })
     // mean.push(parseFloat(_.meanBy(item, function(o) { return o.mean; })).toFixed(2)); // On prend la moyenne des congestions
      item.forEach(el => {
        switch (el.group) {
          case '2G':
            const G2Value = parseFloat(el.mean).toFixed(2);
            G2Data.push(G2Value);
            break;
          case '3G':
            const G3Value = parseFloat(el.mean).toFixed(2);
            G3Data.push(G3Value);
            break;
          case '4G':
            // console.log(el.sum);
            const G4Value = parseFloat(el.mean).toFixed(2);
            G4Data.push(G4Value);
            break;
          default:
            break;
        }
      } )
    }
   // console.log(G4Data);
  

    const option = {
      /*title:{
        text: 'Congestion Prédite par Techno',
      },*/
      tooltip: {
          trigger: 'axis',
          axisPointer: {            // Use axis to trigger tooltip
              type: 'line'        // 'shadow' as default; can also be 'line' or 'shadow'
          }
      },
      /*dataZoom: [{
        type: 'slider',
        start: 0,
        end: 30,
        bottom: -8,
    }, {
        start: 0,
        end: 30,
        bottom: -8
    }],*/
      legend: {
          data: ['2G', '3G', '4G'],
          top: 0,
      },
      grid: {
          left: '3%',
          right: '4%',
          bottom: '8%',
          containLabel: true
      },
      yAxis: {
          type: 'value',
          name: 'Taux(%)'
      },
      xAxis: {
          type: 'category',
          data: cats,
          name: 'Période',
          nameLocation: 'center',
          axisPointer: {
            type: 'shadow'
        }
      },
      series: [
          {
              name: '2G',
              type: 'line',
              smooth: true,
              showSymbol: false,
              //stack: 'techno',
              // barWidth: width,
              label: {
                  show: false
              },
              itemStyle:{
                color: '#B5E8F7'
              },
              emphasis: {
                  focus: 'series'
              },
              data: G2Data//[320, 302]
          },
          {
              name: '3G',
              type: 'line',
              //stack: 'techno',
              // barWidth: width,
              smooth: true,
              showSymbol: false,
              itemStyle:{
                color: '#4BB4E6'
              },
              label: {
                  show: false
              },
              emphasis: {
                  focus: 'series'
              },
              data: G3Data//[120, 132]
          },
          {
              name: '4G',
              type: 'line',
              //stack: 'techno',
              //barWidth: width,
              smooth: true,
              showSymbol: false,
              itemStyle:{
                color: '#085EBD'
              },
              label: {
                  show: false
              },
              emphasis: {
                  focus: 'series'
              },
              data: G4Data, //[220, 182]
          },
          /*{
            name: '% Congest. Moy.',
            type: 'line',
            smooth: true,
            showSymbol: false,
            itemStyle:{
              color: '#FF7900'
            },
            label: {
                show: true
            },
            emphasis: {
                focus: 'series'
            },
            data: mean, //[220, 182]
        },*/
        
      ]
  };
    // use configuration item and data specified to show chart
    this.congestTechnoChart.setOption(option);
  }

  voixByTechno(data: any, width){
    if(!this.voixByTechnoChart){
      this.voixByTechnoChart = echarts.init(document.getElementById('voix-techno'));
    }
  
    
    const cats = _.keys(data);
    const G2Data = [];
    const G3Data = [];
    const G4Data = [];

    for (const property in data) {
      const item: any[] = data[property];
      // console.log(item);

      /**
       * Find period data which not predicted
       */
      // Key By TECHNO (2G, 3G, or 4G)
      const keys = ['2G','3G','4G']
      const keyByTechno = _.keyBy(item, function(o) {return o.group;});
      //console.log(keyByTechno)
      const keyProvided = _.keys(keyByTechno);
      //console.log(keyProvided)
      const keyNotProvided: [] = _.difference(keys, keyProvided);
      //console.log(keyNotProvided)

      // We give 0 as data for the techno which not provided
      keyNotProvided.forEach(key => {
        item.push({group: key, sum:0})
      })

      //
      item.forEach(el => {
        switch (el.group) {
          case '2G':
            const G2Value = parseFloat(el.sum).toFixed(2);
            G2Data.push(G2Value);
            break;
          case '3G':
            const G3Value = parseFloat(el.sum).toFixed(2);
            G3Data.push(G3Value);
            break;
          case '4G':
            // console.log(el.sum);
            const G4Value = parseFloat(el.sum).toFixed(2);
            G4Data.push(G4Value);
            break;
          default:
            break;
        }
      } )
    }
   // console.log(G4Data);
  

    const option = {
      title:{
        text: 'Trafic VOIX Prédit par Techno',
      },
      tooltip: {
          trigger: 'axis',
          axisPointer: {            // Use axis to trigger tooltip
              type: 'line'        // 'shadow' as default; can also be 'line' or 'shadow'
          }
      },
      /*dataZoom: [{
        type: 'slider',
        start: 0,
        end: 30,
        bottom: -8,
    }, {
        start: 0,
        end: 30,
        bottom: -8
    }],*/
      legend: {
          data: ['2G', '3G', '4G'],
          top: 0,
          right: 0
      },
      grid: {
          left: '3%',
          right: '4%',
          bottom: '8%',
          containLabel: true
      },
      yAxis: {
          type: 'value',
          name: 'Trafic(Erlang)'
      },
      xAxis: {
          type: 'category',
          data: cats,//['01/2021', '02/2021'],
          name: 'Période',
          nameLocation: 'center'
      },
      series: [
          {
              name: '2G',
              type: 'bar',
              stack: 'techno',
              barWidth: width,
              label: {
                  show: false
              },
              itemStyle:{
                color: '#B5E8F7'
              },
              emphasis: {
                  focus: 'series'
              },
              data: G2Data//[320, 302]
          },
          {
              name: '3G',
              type: 'bar',
              stack: 'techno',
              barWidth: width,
              itemStyle:{
                color: '#4BB4E6'
              },
              label: {
                  show: false
              },
              emphasis: {
                  focus: 'series'
              },
              data: G3Data//[120, 132]
          },
          {
              name: '4G',
              type: 'bar',
              stack: 'techno',
              barWidth: width,
              itemStyle:{
                color: '#085EBD'
              },
              label: {
                  show: false
              },
              emphasis: {
                  focus: 'series'
              },
              data: G4Data, //[220, 182]
          },
        
      ]
  };
    // use configuration item and data specified to show chart
    this.voixByTechnoChart.setOption(option);
  }

  dataActuelVSTraficPredit(data: any[], yAxisName, factor){
    if(!this.dataVSChart){
      this.dataVSChart = echarts.init(document.getElementById('chart-data'));
    }
    const datas = [];
    const cats = [];
    data.forEach(item => {
      const value = (parseFloat(item.sum)/factor).toFixed(2)
      datas.push(value);
      cats.push(item.group);
    })
    // console.log(datas);
    // console.log(cats);
    const option = {
      title:{
        text: 'Évolution Trafic data DL Prédit',
      },
      /*dataZoom: [{
        type: 'inside',
        start: 0,
        end: 50
    }, {
        start: 0,
        end: 50
    }],*/
      xAxis: {
          type: 'category',
          data: cats,// ['01/2021', '02/2021', '02/2021'],
          name: 'Période',
          nameLocation: 'end'
      },
      legend:{
        bottom: 0
      },
      tooltip:{
        trigger: 'axis'
      },
      grid: {
        right: '20%'
      },
      yAxis: {
          type: 'value',
          name: yAxisName
      },
      series: [
        {
          data: datas,// [409, 780, 720],
          type: 'line',
          name: 'TRAFIC PREDIT',
          smooth: true,
          showSymbol: false,
          itemStyle:{
            color: '#FF7900'
          }
      },
      /*{
        data: [520, 480, 420],
        type: 'line',
        name: 'TRAFIC ACTUEL',
        smooth: true,
        itemStyle:{
          color: '#FF7900'
        }
    }*/
    ]
  };
  
    // use configuration item and data specified to show chart
    this.dataVSChart.setOption(option);
  }

  dataByTechno(data: any, width){
    if(!this.dataByTechnoChart){
      this.dataByTechnoChart = echarts.init(document.getElementById('data-techno'));
    }

    const cats = _.keys(data);
    const G2Data = [];
    const G3Data = [];
    const G4Data = [];
    

    for (const property in data) {
      const item: any[] = data[property];

      /**
       * Find period data which not predicted
       */
      // Key By TECHNO (2G, 3G, or 4G)
      const keys = ['2G','3G','4G']
      const keyByTechno = _.keyBy(item, function(o) {return o.group;});
      const keyProvided = _.keys(keyByTechno);
      const keyNotProvided: [] = _.difference(keys, keyProvided);

      // We give 0 as data for the techno which not provided
      keyNotProvided.forEach(key => {
        item.push({group: key, sum:0})
      })

      item.forEach(el => {
        switch (el.group) {
          case '2G':
            console.log(el.sum);
            const G2Value = parseFloat(el.sum).toFixed(2);
            G2Data.push(G2Value);
            break;
          case '3G':
            const G3Value = parseFloat(el.sum).toFixed(2);
            G3Data.push(G3Value);
            break;
          case '4G':
            const G4Value = parseFloat(el.sum).toFixed(2);
            G4Data.push(G4Value);
            break;
          default:
            break;
        }
      } )
    }
  
    const option = {
      title:{
        text: 'Trafic DATA DL Prédit par Techno',
      },
      tooltip: {
          trigger: 'axis',
          axisPointer: {            // Use axis to trigger tooltip
              type: 'shadow'        // 'shadow' as default; can also be 'line' or 'shadow'
          }
      },
      legend: {
          data: ['2G', '3G', '4G'],
          top: 0,
          right: 0
      },
      /*dataZoom: [{
        type: 'slider',
        start: 0,
        end: 30,
        bottom: -8,
    }, {
        start: 0,
        end: 30,
        bottom: -8,
    }],*/
      grid: {
          left: '3%',
          right: '4%',
          bottom: '8%',
          containLabel: true
      },
      yAxis: {
          type: 'value',
          name: 'Trafic(GB)'
      },
      xAxis: {
          type: 'category',
          data: cats,//['01/2021', '02/2021'],
          name: 'Période',
          nameLocation: 'center'
      },
      series: [
          {
              name: '2G',
              type: 'bar',
              stack: 'techno',
              barWidth: width,
              label: {
                  show: false
              },
              itemStyle:{
                color: '#B5E8F7'
              },
              emphasis: {
                  focus: 'series'
              },
              data: G2Data//[320, 302]
          },
          {
              name: '3G',
              type: 'bar',
              stack: 'techno',
              barWidth: width,
              itemStyle:{
                color: '#4BB4E6'
              },
              label: {
                  show: false
              },
              emphasis: {
                  focus: 'series'
              },
              data: G3Data//[120, 132]
          },
          {
              name: '4G',
              type: 'bar',
              stack: 'techno',
              barWidth: width,
              itemStyle:{
                color: '#085EBD'
              },
              label: {
                  show: false
              },
              emphasis: {
                  focus: 'series'
              },
              data: G4Data//[220, 182]
          },
        
      ]
  };
    // use configuration item and data specified to show chart
    this.dataByTechnoChart.setOption(option);
  }



}
