import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DashboardComponent } from './dashboard/dashboard.component';
import { ConfEconomiqueComponent } from './conf-economique/conf-economique.component';
import { ConfTechniqueComponent } from './conf-technique/conf-technique.component';
import { UtilisateurComponent } from './utilisateur/utilisateur.component';
import { ResultCapaciteComponent } from './result-capacite/result-capacite.component';
import { ResultPlanifComponent } from './result-planif/result-planif.component';
import { HistoriquePlanifComponent } from './historique-planif/historique-planif.component';
//import { QosDashboardComponent } from './qos-dashboard/qos-dashboard.component';
//import { CapacityDashboardComponent } from './capacity-dashboard/capacity-dashboard.component';
import { LoginComponent } from './login/login.component';
import { Error403Component } from './error403/error403.component';
import { Error404Component } from './error404/error404.component';
import { DvReportComponent } from './dv-report/dv-report.component';
import { CoverageNpvComponent } from './coverage-npv/coverage-npv.component';
import { CoverageDashboardComponent } from './coverage-dashboard/coverage-dashboard.component';

import { AuthGuard } from './auth/auth.guard';

const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'acces-refuse', component: Error403Component},
  { path: 'login', component: LoginComponent},
  { path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard], data: { expectedRole: ['editor','viewer','admin','validator','marketing','finance','ser','modeling','strategy']}  },
  { path: 'coverage-dashboard', component: CoverageDashboardComponent, canActivate: [AuthGuard], data: { expectedRole: ['editor','viewer','admin','validator','marketing','finance','ser','modeling','strategy']}  },
  { path: 'coverage-npv', component: CoverageNpvComponent, canActivate: [AuthGuard], data: { expectedRole: ['editor','viewer','admin','validator','marketing','finance','ser','modeling','strategy']}  },
  { path: 'dv-report', component: DvReportComponent, canActivate: [AuthGuard], data: { expectedRole: ['editor','viewer','admin','validator','marketing','finance','ser','modeling','strategy']}  },
  { path: 'conf-economique', component: ConfEconomiqueComponent, canActivate: [AuthGuard], data: { expectedRole: ['editor','admin','validator','marketing','finance','ser','modeling','strategy']}  },
  { path: 'conf-technique', component: ConfTechniqueComponent, canActivate: [AuthGuard], data: { expectedRole: ['editor','admin','validator','marketing','finance','ser','modeling','strategy']}  },
  { path: 'utilisateur', component: UtilisateurComponent, canActivate: [AuthGuard], data: { expectedRole: ['admin','validator']}  },
  { path: 'resultats-capacite', component: ResultCapaciteComponent, canActivate: [AuthGuard], data: { expectedRole: ['editor','viewer','admin','validator','marketing','finance','ser','modeling','strategy']}  },
  { path: 'resultats-planification/:id', component: ResultPlanifComponent, canActivate: [AuthGuard], data: { expectedRole: ['editor','viewer','admin','validator','marketing','finance','ser','modeling','strategy']}  },
  // { path: 'resultats-planification', component: ResultPlanifComponent, canActivate: [AuthGuard], data: { expectedRole: ['admin','validator']}  },
  { path: 'historique-planification', component: HistoriquePlanifComponent, canActivate: [AuthGuard], data: { expectedRole: ['editor','viewer','admin','validator','marketing','finance','ser','modeling','strategy']}  },
  //{ path: 'qos-dashboard', component: QosDashboardComponent, canActivate: [AuthGuard], data: { expectedRole: ['admin','validator']}  },
  //{ path: 'capacity-dashboard', component: CapacityDashboardComponent, canActivate: [AuthGuard], data: { expectedRole: ['admin','validator']}  },
  { path: '**', component: Error404Component},
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true, anchorScrolling: 'enabled', })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
