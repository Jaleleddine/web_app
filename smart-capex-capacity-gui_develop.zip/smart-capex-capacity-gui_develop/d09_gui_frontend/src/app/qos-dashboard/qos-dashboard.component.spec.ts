import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QosDashboardComponent } from './qos-dashboard.component';

describe('QosDashboardComponent', () => {
  let component: QosDashboardComponent;
  let fixture: ComponentFixture<QosDashboardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QosDashboardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QosDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
