import { Component, OnInit } from '@angular/core';
import * as echarts from 'echarts';
import * as L from 'leaflet';
import 'node_modules/leaflet.tilelayer.colorfilter/src/leaflet-tilelayer-colorfilter.js';
import { BackendService } from '../services/backend.service';

@Component({
  selector: 'app-qos-dashboard',
  templateUrl: './qos-dashboard.component.html',
  styleUrls: ['./qos-dashboard.component.css']
})
export class QosDashboardComponent implements OnInit {

  date = new Date();
  fr: any;
  dataChart: any;
  voiceChart: any;
  latenceChart: any;
  latenceAVMap: any;
  latenceAPMap: any;

  constructor( private backendService: BackendService) { }

  ngOnInit(): void {
    this.fr = this.backendService.translateInFrench();
    this.voixByTechno();
    this.dataByTechno();
    // this.latenceByTechno();
    this.latenceAVANTMap();
    this.latenceAPRESTMap();
  }

  latenceAPRESTMap(site?): void{
    // this.ngxService.start();
    if (!this.latenceAPMap){
      this.latenceAPMap = L.map('latence-ap', { zoomControl: false }).setView([this.backendService.latitude, this.backendService.longitude], 5);
      (L.tileLayer as any).colorFilter(this.backendService.tileUrl, {
    minZoom: 5,
    maxZoom: 20,
    // filter: ['grayscale:100%', 'invert:0%']
    }).addTo(this.latenceAPMap);
     // Positionner le zoom panel
      new L.Control.Zoom({ position: 'bottomleft' }).addTo(this.latenceAPMap);
      // Le découpage commercial
      this.initDecoupageCommercial(this.latenceAPMap);
    }
  }

  latenceAVANTMap(site?): void{
    // this.ngxService.start();
    if (!this.latenceAVMap){
      this.latenceAVMap = L.map('latence-av', { zoomControl: false }).setView([this.backendService.latitude, this.backendService.longitude], 5);
      (L.tileLayer as any).colorFilter(this.backendService.tileUrl, {
    minZoom: 5,
    maxZoom: 20,
    // filter: ['grayscale:100%', 'invert:0%']
    }).addTo(this.latenceAVMap);
     // Positionner le zoom panel
      new L.Control.Zoom({ position: 'bottomleft' }).addTo(this.latenceAVMap);
      // Le découpage commercial
      this.initDecoupageCommercial(this.latenceAVMap);
    }
  }

  onEachFeature(feature, layer): void {
    console.log('count');
    // does this feature have a property named popupContent?
    // feature.properties.QUARTIER && feature.properties.COMMUNE
    if (feature.properties.ZC) {
        layer.
        bindTooltip(`
            <div style="background:#FFF">
            <div style="color:#000;text-align: center;font-weight: bold;font-size: 14px;margin:0px auto;">
            ${feature.properties.ZC}
            </div>

            <table class="tooltip-table">
              <tr>
                <td>${feature.properties.Superf} KM²</td>
              </tr>
            </table>
            </div>
            `, {className: 'small-tooltip'});
        }
  }

  initDecoupageCommercial(map): void {
    const colors = ['#085EBD', '#0A6E31', '#FF8AD4', '#FFB400', '#492191', '#595959', '#000000', '#4BB4E6', '#A885D8',
  '#FF7900', '#62342D', '#FFD200', '#FFF6B6', '#880E4F', '#FFAB91'];
    this.backendService.getZoneCommerciale().subscribe((zones) => {
      zones.features.forEach((feacture, index) => {
        feacture.properties.index = index;
      });
      console.log(zones);
      L.geoJSON(zones, {
        style: (feature) => {
            return {color: colors[feature.properties.index], weight: 0.3, opacity: 0.3,fillOpacity: 0.1};
        },
        onEachFeature: this.onEachFeature
    }).addTo(map);
    });
  }


  
  dataByTechno(){
    if(!this.dataChart){
      this.dataChart = echarts.init(document.getElementById('data-techno-q'));
  
    }
    const option = {
      title:{
        text: 'Call Setup Success par Technologies',
      },
      legend: {
        bottom: 50
      },
      tooltip: {},
      dataset: {
          source: [
              ['call', '202035', '202036'],
              ['2G', 41.1, 30.4],
              ['3G', 86.5, 92.1],
              ['4G', 24.1, 67.2]
          ]
      },
      xAxis: [
          {type: 'category', gridIndex: 0},
      ],
      yAxis: [
          {gridIndex: 0},
      ],
      grid: [
          {bottom: '55%'},
          {top: '55%'}
      ],
      series: [
          // These series are in the first grid.
          {type: 'bar', seriesLayoutBy: 'row', itemStyle:{color: '#FFD200'},barWidth: 30,},
          {type: 'bar', seriesLayoutBy: 'row', itemStyle:{color: '#A885D8'}, barWidth: 30,},
          {type: 'bar', seriesLayoutBy: 'row', itemStyle:{color: '#50BE87'}, barWidth: 30,},
      ]
  };
    // use configuration item and data specified to show chart
    this.dataChart.setOption(option);
  }


  voixByTechno(){
    if(!this.voiceChart){
      this.voiceChart = echarts.init(document.getElementById('voix-techno-q'));
    }
  
    const option = {
      title:{
        text: 'Dropped call par Technologies',
      },
      legend: {
        bottom: 50
      },
      tooltip: {},
      dataset: {
          source: [
              ['call', '202035', '202036'],
              ['2G', 41.1, 30.4],
              ['3G', 86.5, 92.1],
              ['4G', 24.1, 67.2]
          ]
      },
      xAxis: [
          {type: 'category', gridIndex: 0},
      ],
      yAxis: [
          {gridIndex: 0},
      ],
      grid: [
          {bottom: '55%'},
          {top: '55%'}
      ],
      series: [
          // These series are in the first grid.
          {type: 'bar', seriesLayoutBy: 'row', itemStyle:{color: '#FFD200'},barWidth: 30,},
          {type: 'bar', seriesLayoutBy: 'row', itemStyle:{color: '#A885D8'}, barWidth: 30,},
          {type: 'bar', seriesLayoutBy: 'row', itemStyle:{color: '#50BE87'}, barWidth: 30,},
      ]
  };
    // use configuration item and data specified to show chart
    this.voiceChart.setOption(option);
  }

  latenceByTechno(){
    if(!this.latenceChart){
      this.latenceChart = echarts.init(document.getElementById('latence-techno-q'));
    }
  
    const option = {
      title:{
        text: 'Latence par Technologies',
      },
      legend: {
        bottom: 50
      },
      tooltip: {},
      dataset: {
          source: [
              ['call', '202035', '202036'],
              ['2G', 41.1, 30.4],
              ['3G', 86.5, 92.1],
              ['4G', 24.1, 67.2]
          ]
      },
      xAxis: [
          {type: 'category', gridIndex: 0},
      ],
      yAxis: [
          {gridIndex: 0},
      ],
      grid: [
          {bottom: '55%'},
          {top: '55%'}
      ],
      series: [
          // These series are in the first grid.
          {type: 'bar', seriesLayoutBy: 'row', itemStyle:{color: '#FFD200'},barWidth: 30,},
          {type: 'bar', seriesLayoutBy: 'row', itemStyle:{color: '#A885D8'}, barWidth: 30,},
          {type: 'bar', seriesLayoutBy: 'row', itemStyle:{color: '#50BE87'}, barWidth: 30,},
      ]
  };
    // use configuration item and data specified to show chart
    this.latenceChart.setOption(option);
  }

}
