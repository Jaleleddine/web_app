import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfTechniqueComponent } from './conf-technique.component';

describe('ConfTechniqueComponent', () => {
  let component: ConfTechniqueComponent;
  let fixture: ComponentFixture<ConfTechniqueComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConfTechniqueComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfTechniqueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
