import { Component, OnInit } from '@angular/core';
import * as XLSX from 'xlsx';
//import {FormGroup, FormBuilder, Validators} from '@angular/forms';
import { BackendService } from '../services/backend.service';
import { AuthService } from '../services/auth.service';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { ToastrService } from 'ngx-toastr';
import { UserService } from '../services/user.service';
import { ConstanteService } from '../services/constante.service';
import { UpgradePathService } from '../services/upgrade-path.service';
import  { SteeringNetworkService } from '../services/steering-network.service';
import {Constante, UpgradePathParameter, SteeringNetwork } from '../interfaces/interfaces';
import * as _ from 'lodash';
import { ViewService } from '../services/view.service';


@Component({
  selector: 'app-conf-technique',
  templateUrl: './conf-technique.component.html',
  styleUrls: ['./conf-technique.component.css']
})
export class ConfTechniqueComponent implements OnInit {

  file: any; // Le fichier excel chargé
  tabName: string; // The tab name of the excell file
  fileData: any; // Les données du fichier excel chargé
  inputFile: any;
  dataForTable: any;
  item: any;
  p: number = 1;
  token = '';
  fr: any;
  date = new Date();
  errors = [];
  isParamTableVisible = false;// Show parameter Table visible;
  title = '';
  user: any;

  /*** CONSTANTE DATA *****/
  maximumNumberOfSite: number;
  proxyToBeConsidered: string;
  MAX_NUMBER_OF_NEIGHBORS: number;
  WEEK_OF_THE_UPGRADE: string;
  weekSelected: Date;

  /***  STRUCTURE DATA  ***/
  constanteData:Constante[];
  capexData: any;

  /*** CONFIGS FROM ANALITYC SERVER***/
  CONFIGS: any;


  constructor(
    public backendService: BackendService,
    private toastr: ToastrService,
    private ngxService: NgxUiLoaderService,
    private authService: AuthService,
    public constanteService: ConstanteService,
    public upgradePathParamService: UpgradePathService,
    public steeringNetworkService: SteeringNetworkService,
    public viewService: ViewService,
    private userService: UserService
  ) { }

  ngOnInit(): void {
    this.fr = this.backendService.translateInFrench();
    this.user = this.authService.getUser();
    // Get token first and after initial data
    if(this.authService.isProd){
      this.userService.refreshToken().subscribe(data => {
        this.token = data.token;
        this.authService.token.next(data.token)
        this.getConstanteData();
        this.getConfigs();
      }, (err => {
        console.log(err);
        this.toastr.error('Une erreur est survenue pendant le chargement de la page.', '', {
          timeOut: 10000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      }))
    } else {
        this.token = this.authService.getToken();
        this.authService.token.next(this.token)
        // Get initial data
        this.getConstanteData();
        this.getConfigs()
    }
  }

  openModal(){
    document.getElementById("myModal").style.display='block';
  }

  closeModal(){
    document.getElementById("myModal").style.display='none';
  }

  // Get the week of upgrade depending of date selected
  getWeekPeriod(){
    this.WEEK_OF_THE_UPGRADE = this.backendService.getWeekPeriod(this.weekSelected);
  }

  addConstante(data: any, id: string, parameterName: string){
    const newData = {identifiant: id, parameter: parameterName,valeur: data + '', modifiedBy: this.user.name + ' ' + this.user.firstname};
    const constante = this.constanteData.filter(item => item.identifiant == id);
    console.log(newData);
    // S'il y a des données
    if(data){
      // Ajout de la constante
      if(constante.length !== 0){
        // Mise à jour de la constante
        this.updateConstante(newData, id);
      } else{
        this.postConstante(newData);
      }
    }
    
  }

  // Ajouter une constante en base
  postConstante(data: object){
    this.constanteService.postItem(data, this.token).subscribe((data) => {
      console.log(data);
      this.toastr.success('La valeur a été ajoutée avec succès', '', {
        timeOut: 10000,
        closeButton: true,
        positionClass: 'toast-top-center',
        progressBar: true,
      });
      
      // Charger nos constantes enregistrées en bases de données
      this.getConstanteData();

    }, (error) => {
      this.errors = [];
      console.log(error);
      if(error.status === 400){
        this.toastr.error(error.error.message, '', {
          timeOut: 120000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      } else{
        this.toastr.error('Une erreur est survenue pendant la mise à jour de la valeur', '', {
          timeOut: 10000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      }
    }, () => {});
  }

  // Mis à jour d'une constante
  updateConstante(data: object, id: string){
    this.constanteService.updateItem(data, id, this.token).subscribe((data) => {
      console.log(data);
      this.toastr.success('La valeur a été mise à jour avec succès', '', {
        timeOut: 10000,
        closeButton: true,
        positionClass: 'toast-top-center',
        progressBar: true,
      });
      
      // Charger nos constantes enregistrées en bases de données
      this.getConstanteData();

    }, (error) => {
      this.errors = [];
      console.log(error);
      if(error.status === 400){
        this.toastr.error(error.error.message, '', {
          timeOut: 120000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      } else{
        this.toastr.error('Une erreur est survenue pendant la mise à jour de la valeur', '', {
          timeOut: 10000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      }
    }, () => {});
  }

  addItem(data: any[], service: ConstanteService|UpgradePathService|SteeringNetworkService) {
    service.postItem(data, this.token).subscribe((data) => {
      console.log(data);
      this.toastr.success('Les données ont été mises à jour avec succès', '', {
        timeOut: 10000,
        closeButton: true,
        positionClass: 'toast-top-center',
        progressBar: true,
      });
      
      // Charger nos données enregistrées en bases de données
      service.getItems(this.token).subscribe((data)=>{
        console.log(data);
        service.data = data;
        this.backendService.paramData = data;
        service.showDetails();
        this.openModal();
      });

    }, (error) => {
      this.errors = [];
      console.log(error);
      if(error.status === 400){
        this.toastr.error(error.error.message, '', {
          timeOut: 120000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      } else{
        this.toastr.error('Une erreur est survenue pendant la mise à jour des données', '', {
          timeOut: 10000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      }
    }, () => {});
  }

  updateItem(data: any[], service: ConstanteService|UpgradePathService|SteeringNetworkService) {
    // console.log(id);
    service.updateAll(data, this.token).subscribe((data) => {
      console.log(data);
      this.toastr.success('La mise à jour a été effectuée avec succès', '', {
        timeOut: 10000,
        closeButton: true,
        positionClass: 'toast-top-center',
        progressBar: true,
      });

      // Charger nos données enregistrées en bases de données
      service.getItems(this.token).subscribe((data)=>{
        console.log(data);
        service.data = data;
        this.backendService.paramData = data;
        service.showDetails();
        this.openModal();
      });

    }, (error) => {
      this.errors = [];
      console.log(error);
      if(error.status === 400){
        this.toastr.error(error.error.message, '', {
          timeOut: 120000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      } else{
        this.toastr.error('Une erreur est survenue pendant la modification', '', {
          timeOut: 10000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      }
     
    }, () => {});
  }

  deteleItem(service){
    const id = this.item['id'];
    // console.log(id);
    service.deleteItem(id, this.token).subscribe((data) => {
      console.log(data);
      this.toastr.success('L\'élément a été supprimé avec succès', '', {
        timeOut: 10000,
        closeButton: true,
        positionClass: 'toast-top-center',
        progressBar: true,
      });
    }, (error) => {
      this.errors = [];
      console.log(error);
      if(error.status === 400){
        this.toastr.error(error.error.message, '', {
          timeOut: 120000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      } else{
        this.toastr.error('Une erreur est survenue pendant la modification', '', {
          timeOut: 10000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      }
    }, () => {});
  }

  // Get Configs from AE server
  getConfigs(){
    this.backendService.getConfigs(this.token).subscribe(data => {
      console.log(data)
      this.CONFIGS = data;
      this.WEEK_OF_THE_UPGRADE = this.CONFIGS.TRAFFIC_IMPROVEMENT.WEEK_OF_THE_UPGRADE;
      this.MAX_NUMBER_OF_NEIGHBORS = this.CONFIGS.TRAFFIC_IMPROVEMENT.MAX_NUMBER_OF_NEIGHBORS;
    }, (err) => console.log(err))
  }

  // Get Params details from the Data base
  getParamDetails(service: ConstanteService|UpgradePathService|SteeringNetworkService){
    service.getItems(this.token).subscribe((data) => {
      service.data = data;
      this.backendService.paramData = data;
      service.showDetails();
      this.openModal(); 
    });
  }

  getConstanteData(){
    this.constanteService.getItems(this.token).subscribe((data) => {
      this.constanteData = data == null ? [] : data;

    }, (error) => console.log(error));
  }


  exportToExcel(data: any[]): void {
      console.log(data);
       const infoGen = [];
       data.forEach(item => {
          infoGen.push(item);
       });
       // console.log(details);
       const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(infoGen);
       // const wsDetails: XLSX.WorkSheet = XLSX.utils.json_to_sheet(details);
       const wb: XLSX.WorkBook = XLSX.utils.book_new();
       XLSX.utils.book_append_sheet(wb, ws, this.tabName);
       //XLSX.utils.book_append_sheet(wb, wsDetails, 'Détails');
  
       XLSX.writeFile(wb, this.backendService.title + '.xlsx');
  }

  
  isConstante(data: any): data is Constante {
    return 'identifiant' in data && 
            'parameter' in data &&
            'value' in data;
  }

  isUpgradePathParam(data: any): data is UpgradePathParameter {
    return 'identifiant' in data && 
            'parameter' in data &&
            'value' in data;
  }

  isSteeringNetwork(data: any): data is SteeringNetwork {
    return 'identifiant' in data && 
            'typeTraffic' in data &&
            'technologie' in data &&
            'steering2020Percent' in data &&
            'steering2021Percent' in data &&
            'steering2022Percent' in data &&
            'steering2023Percent' in data &&
            'steering2024Percent' in data &&
            'steering2025Percent' in data;
  }

  // Validate data uploaded structure
  validateData(data: any[], isType: Function){
    console.log(data[0]);
    if (isType(data[0])) {
      return true;
    } else{
      return false;
    }
  }

// Upload Function
  onFileChange(ev: any, fileTabName: string, parameterName: string) {
    // this.ngxService.start();
    let workBook = null;
    let jsonData = null;
    const reader = new FileReader();
    this.file = ev.target.files[0];
    reader.onload = (event) => {
      const data = reader.result;
      workBook = XLSX.read(data, { type: 'binary' });
      jsonData = workBook.SheetNames.reduce((initial, name) => {
        const sheet = workBook.Sheets[name];
        initial[name] = XLSX.utils.sheet_to_json(sheet, {blankrows: true, raw: true});
        return initial;
      }, {});
      // const dataString = JSON.stringify(jsonData);
      console.log(jsonData);
      const intData: any[] = jsonData[fileTabName];
      console.log(intData);
      const finalData = [];

      if(!intData){
        console.log('type nok');
        return this.uploadErrorMessage();
      }
      if(intData.length > 0){
        intData.forEach(item => {
          let newItem: any = {};
          for (let [key, value] of Object.entries(item)) {
            // Transform our data to Backend format
            if(parameterName == 'SteeringNetwork'){
              newItem[_.camelCase(key)] = value + '';
            } else {
              newItem[_.camelCase(key)] = value;
            }
            
          }
          finalData.push(newItem);
        });
      }
      console.log(finalData);
      // Determine the best function for us
      switch(parameterName) {
        case 'UpgradePathParameter':
          if(this.validateData(finalData, this.isUpgradePathParam)){
            this.tabName = fileTabName; // Our current file Tab name
            this.upgradePathParamService.getItems(this.token).subscribe((data) => {
              const datas: any[] = data;
              if(datas.length > 0){
                //this.updateItem(finalData, this.upgradePathParamService);
                this.addItem(finalData, this.upgradePathParamService);
              }else{
                this.addItem(finalData, this.upgradePathParamService);
              }
              
            }, (error) => console.log(error));
            
          }else{
            this.uploadErrorMessage();
            // console.log('upload nok');
          }
          break;
          case 'SteeringNetwork':
            if(this.validateData(finalData, this.isSteeringNetwork)){
              const input = document.getElementById('steering') as HTMLInputElement;
              input.value = null;
              this.tabName = fileTabName; // Our current file Tab name
              this.steeringNetworkService.getItems(this.token).subscribe((data) => {
                const datas: any[] = data;
                if(datas.length > 0){
                  //this.updateItem(finalData, this.steeringNetworkService);
                  this.addItem(finalData, this.steeringNetworkService);
                }else{
                  this.addItem(finalData, this.steeringNetworkService);
                }
                
              }, (error) => console.log(error));
              
            }else{
              this.uploadErrorMessage();
              // console.log('upload nok');
            }
            break;
        default:
          return;
      }

      // Reinit our input file
      //this.inputFile = '';

    }
    reader.readAsBinaryString(this.file);
   /// this.ngxService.stop();
  }

  uploadErrorMessage(){
    this.toastr.error('Echec, le fichier n\'est pas au bon format.Merci de vérifier les entêtes et le contenu.', '', {
      timeOut: 20000,
      closeButton: true,
      positionClass: 'toast-top-center',
      progressBar: true,
    });
  }

}
