import { Component, OnInit } from '@angular/core';
import { BackendService } from '../services/backend.service';
import * as echarts from 'echarts';
import * as L from 'leaflet';
import 'node_modules/leaflet.tilelayer.colorfilter/src/leaflet-tilelayer-colorfilter.js';

@Component({
  selector: 'app-capacity-dashboard',
  templateUrl: './capacity-dashboard.component.html',
  styleUrls: ['./capacity-dashboard.component.css']
})
export class CapacityDashboardComponent implements OnInit {

  date = new Date();
  fr: any;
  dataChart: any;
  voiceChart: any;
  constructor( private backendService: BackendService) { }

  ngOnInit(): void {
    this.fr = this.backendService.translateInFrench();
    this.voixByTechno();
    this.dataByTechno();
  }

  
  dataByTechno(){
    if(!this.dataChart){
      this.dataChart = echarts.init(document.getElementById('data-techno-c'));
    }
    const option = {
      title:{
        text: 'Timeslot Occupancy par Technologies',
      },
      legend: {
        bottom: 50
      },
      tooltip: {},
      dataset: {
          source: [
              ['call', '202035', '202036'],
              ['2G', 41.1, 30.4],
              ['3G', 86.5, 92.1],
              ['4G', 24.1, 67.2]
          ]
      },
      xAxis: [
          {type: 'category', gridIndex: 0},
      ],
      yAxis: [
          {gridIndex: 0},
      ],
      grid: [
          {bottom: '55%'},
          {top: '55%'}
      ],
      series: [
          // These series are in the first grid.
          {type: 'bar', seriesLayoutBy: 'row', itemStyle:{color: '#FFD200'},barWidth: 30,},
          {type: 'bar', seriesLayoutBy: 'row', itemStyle:{color: '#A885D8'}, barWidth: 30,},
          {type: 'bar', seriesLayoutBy: 'row', itemStyle:{color: '#50BE87'}, barWidth: 30,},
      ]
  };
    // use configuration item and data specified to show chart
    this.dataChart.setOption(option);
  }


  voixByTechno(){
    if(!this.voiceChart){
      this.voiceChart = echarts.init(document.getElementById('voix-techno-c'));
    }
  
    const option = {
      title:{
        text: 'Lost Traffic par Technologies',
      },
      legend: {
        bottom: 50
      },
      tooltip: {},
      dataset: {
          source: [
              ['call', '202035', '202036'],
              ['2G', 41.1, 30.4],
              ['3G', 86.5, 92.1],
              ['4G', 24.1, 67.2]
          ]
      },
      xAxis: [
          {type: 'category', gridIndex: 0},
      ],
      yAxis: [
          {gridIndex: 0},
      ],
      grid: [
          {bottom: '55%'},
          {top: '55%'}
      ],
      series: [
          // These series are in the first grid.
          {type: 'bar', seriesLayoutBy: 'row', itemStyle:{color: '#FFD200'},barWidth: 30,},
          {type: 'bar', seriesLayoutBy: 'row', itemStyle:{color: '#A885D8'}, barWidth: 30,},
          {type: 'bar', seriesLayoutBy: 'row', itemStyle:{color: '#50BE87'}, barWidth: 30,},
      ]
  };
    // use configuration item and data specified to show chart
    this.voiceChart.setOption(option);
  }


}
