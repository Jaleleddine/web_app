import { Injectable } from '@angular/core';
import { CanActivate, CanActivateChild, CanDeactivate, CanLoad, Route, UrlSegment,
  ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from '../services/auth.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate, CanActivateChild, CanDeactivate<unknown>, CanLoad {

  isAuthenticated = this.authService.isAuthenticated();
  role = this.authService.getRoles();
  constructor(private authService: AuthService, private router: Router) {
  }

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
      const url: string = state.url;
      // Gestion des rôles sur les routes
      //const role = this.role;
      let expectedRoleArray = route.data;
      expectedRoleArray = expectedRoleArray.expectedRole;
      // console.log(expectedRoleArray);
      let  expectedRole = '';
      for(let i=0; i< expectedRoleArray.length; i++){
      if (expectedRoleArray[i] === this.role) {
        console.log('Route corespond');
        expectedRole = this.role;
      }
    }

      if (this.isAuthenticated && this.role === expectedRole) {
      console.log('Accès autorisé');
      return true;
    }

      if (this.isAuthenticated) {
      this.authService.redirectUrl = url;
      this.router.navigate(['/login'], /*{queryParams: { returnUrl: url }}*/ );
    }

    if (this.isAuthenticated && this.role !== expectedRole) {
      console.log('Accès refusé');
      this.router.navigate(['/acces-refuse'] );
    }

    //this.router.navigate(['/acces-refuse'] );
      
  }
  canActivateChild(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    return true;
  }
  canDeactivate(
    component: unknown,
    currentRoute: ActivatedRouteSnapshot,
    currentState: RouterStateSnapshot,
    nextState?: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    return true;
  }
  canLoad(
    route: Route,
    segments: UrlSegment[]): Observable<boolean> | Promise<boolean> | boolean {
    return true;
  }

  checkLogin(url?: string) {
    if (this.authService.isLoggedIn()) {
      return true;
    }
    this.authService.redirectUrl = url;
    this.router.navigate(['/login'], /*{queryParams: { returnUrl: url }}*/ );
  }
}
