import { Component, OnDestroy, OnInit } from '@angular/core';
import { NavigationStart, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { AuthService } from './services/auth.service';
import { CookieService } from 'ngx-cookie-service';

export let browserRefresh = false;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, OnDestroy {
  title = 'SmartCAPEX';
  subscription: Subscription;
  constructor(
    private router: Router,
    private authService: AuthService,
    private cookieService: CookieService
    ) {
    this.subscription = this.router.events.subscribe((event) => {
        if (event instanceof NavigationStart) {
          browserRefresh = !this.router.navigated;
        }
    });
    // check if cookie is expired every two minutes
    setInterval(() => {
      this.checkTimer()
      }, 120000);

  }

  checkTimer(){
    /*console.log('cookie check')
    console.log(this.diffDate(this.cookieService.get('timer')));
    const cookieLifetime = this.diffDate(this.cookieService.get('timer'));*/
    const cookieExits: boolean = this.cookieService.check('timer')
      if(!cookieExits){
        this.authService.logout()
        this.router.navigate(['/login']);
    }
  }

  diffDate(date){
    const date1: any = new Date(date);
    const date2: any = new Date();
    // diff in milliseconds
    const diffTime = Math.abs(date2 - date1);
    return diffTime;
  }

  ngOnInit(): void {
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
}
