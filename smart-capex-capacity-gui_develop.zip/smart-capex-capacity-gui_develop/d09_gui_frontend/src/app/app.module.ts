import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule  } from '@angular/forms';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { HttpClientModule } from "@angular/common/http";
import { ToastrModule } from 'ngx-toastr';

import {
  NgxUiLoaderModule,
  NgxUiLoaderConfig,
  NgxUiLoaderHttpModule,
  SPINNER,
  POSITION,
  PB_DIRECTION,
} from "ngx-ui-loader";

import { NgSelectModule } from '@ng-select/ng-select';
import {CalendarModule} from 'primeng-lts/calendar';
import {TableModule} from 'primeng-lts/table';
/*import {CheckboxModule} from 'primeng-lts/checkbox';
import {ButtonModule} from 'primeng-lts/button';
import {SelectButtonModule} from 'primeng-lts/selectbutton';
import {ToggleButtonModule} from 'primeng-lts/togglebutton';
import {RadioButtonModule} from 'primeng-lts/radiobutton';*/


import { registerLocaleData } from '@angular/common';
import fr from '@angular/common/locales/fr';
import { CookieService } from 'ngx-cookie-service';
registerLocaleData(fr);

import {NgxPaginationModule} from 'ngx-pagination';
import { NavbarComponent } from './navbar/navbar.component';
import { SubnavbarComponent } from './subnavbar/subnavbar.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { FooterComponent } from './footer/footer.component';
import { ConfEconomiqueComponent } from './conf-economique/conf-economique.component';
import { ConfTechniqueComponent } from './conf-technique/conf-technique.component';
import { UtilisateurComponent } from './utilisateur/utilisateur.component';
import { ResultCapaciteComponent } from './result-capacite/result-capacite.component';
import { HistoriquePlanifComponent } from './historique-planif/historique-planif.component';
import { ResultPlanifComponent } from './result-planif/result-planif.component';
import { CapacityDashboardComponent } from './capacity-dashboard/capacity-dashboard.component';
import { QosDashboardComponent } from './qos-dashboard/qos-dashboard.component';
import { LoginComponent } from './login/login.component';
import { Error404Component } from './error404/error404.component';
import { Error403Component } from './error403/error403.component';
import { DvReportComponent } from './dv-report/dv-report.component';
import { CoverageDashboardComponent } from './coverage-dashboard/coverage-dashboard.component';
import { CoverageNpvComponent } from './coverage-npv/coverage-npv.component';
import { TestComponent } from './test/test.component';
const ngxUiLoaderConfig: NgxUiLoaderConfig = {
  bgsColor: "#5FA4D0",
  bgsPosition: POSITION.centerCenter,
  bgsSize: 40,
  bgsType: SPINNER.ballSpinFadeRotating, // background spinner type
  fgsType: SPINNER.ballSpinFadeRotating, // foreground spinner type
  pbDirection: PB_DIRECTION.leftToRight, // progress bar direction
  pbThickness: 5, // progress bar thickness
};


@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    SubnavbarComponent,
    DashboardComponent,
    FooterComponent,
    ConfEconomiqueComponent,
    ConfTechniqueComponent,
    UtilisateurComponent,
    ResultCapaciteComponent,
    HistoriquePlanifComponent,
    ResultPlanifComponent,
    CapacityDashboardComponent,
    QosDashboardComponent,
    LoginComponent,
    Error404Component,
    Error403Component,
    DvReportComponent,
    CoverageDashboardComponent,
    CoverageNpvComponent,
    TestComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule, // import HttpClientModule
    FormsModule,
    ReactiveFormsModule,
    NgxUiLoaderModule.forRoot(ngxUiLoaderConfig),
    NgxUiLoaderHttpModule.forRoot({ 
      showForeground: true,
    }),
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
    NgxPaginationModule,
    NgSelectModule,
    CalendarModule,
    TableModule
  ],
  providers: [CookieService],
  bootstrap: [AppComponent]
})
export class AppModule { }
