import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfEconomiqueComponent } from './conf-economique.component';

describe('ConfEconomiqueComponent', () => {
  let component: ConfEconomiqueComponent;
  let fixture: ComponentFixture<ConfEconomiqueComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConfEconomiqueComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfEconomiqueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
