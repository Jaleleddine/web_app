import { Component, OnInit } from '@angular/core';
import * as XLSX from 'xlsx';
import {FormGroup, FormBuilder, Validators} from '@angular/forms';
import { BackendService } from '../services/backend.service';
import { AuthService } from '../services/auth.service';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { ToastrService } from 'ngx-toastr';
import { IhsOpexService } from '../services/ihs-opex.service';
import { EscoOpexService } from '../services/esco-opex.service';
import { CapexCostService } from '../services/capex-cost.service';
import { ConstanteService } from '../services/constante.service';
import { CagrService } from '../services/cagr.service';
import { UserService } from '../services/user.service';
import { OpexService } from '../services/opex.service'
import { UpgradePathService } from '../services/upgrade-path.service';
import { Cagr, Capex, IhsOpex, EscoOpex, Constante, Clientmargin, UpgradePathParameter, Opex } from '../interfaces/interfaces';
import * as _ from 'lodash';
import { ClientMarginService } from '../services/client-margin.service';
import { ViewService } from '../services/view.service';

@Component({
  selector: 'app-conf-economique',
  templateUrl: './conf-economique.component.html',
  styleUrls: ['./conf-economique.component.css']
})
export class ConfEconomiqueComponent implements OnInit {
  file: any; // Le fichier excel chargé
  tabName: string; // The tab name of the excell file
  fileData: any; // Les données du fichier excel chargé
  inputFile: any;
  dataForTable: any;
  item: any;
  p: number = 1;
  token = '';
  fr: any;
  date = new Date();
  errors = [];
  isParamTableVisible = false;// Show parameter Table visible;
  title = '';
  user: any;

  /*** CONSTANTE DATA *****/
  monthlyRentOpex: number;
  evolutionAnnualOpex: number;
  clientAverageLifetime: number;
  investmentRecoveryTime: number;
  OPEX_INCREASE_BY_YEAR:number;
  TIME_TO_COMPUTE_NPV: number;
  WACC: number;

  /***  STRUCTURE DATA  ***/
  constanteData:Constante[];
  capexData: any;

  /*** CONFIGS FROM ANALITYC SERVER***/
  CONFIGS: any;

  constructor(
    public backendService: BackendService,
    private toastr: ToastrService,
    private ngxService: NgxUiLoaderService,
    private authService: AuthService,
    public ihsOpexService: IhsOpexService,
    public escoOpexService: EscoOpexService,
    public capexService: CapexCostService,
    public opexService: OpexService,
    public constanteService: ConstanteService,
    public clientmarginService: ClientMarginService,
    public upgradePathParamService: UpgradePathService,
    public cagrService: CagrService,
    public viewService: ViewService,
    private userService: UserService
  ) { }

  ngOnInit(): void {
    this.fr = this.backendService.translateInFrench();
    this.user = this.authService.getUser();
    // Get token first and after initial data
    if(this.authService.isProd){
      this.userService.refreshToken().subscribe(data => {
        this.token = data.token;
        this.authService.token.next(data.token)
        this.getConstanteData();
        this.getConfigs()
      }, (err => {
        console.log(err);
        this.toastr.error('Une erreur est survenue pendant le chargement de la page.', '', {
          timeOut: 10000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      }))
    } else {
        this.token = this.authService.getToken();
        this.authService.token.next(this.token)
        // Get initial data
        this.getConstanteData();
        this.getConfigs();
    }
  }

  openModal(){
    document.getElementById("myModal").style.display='block';
  }

  closeModal(){
    document.getElementById("myModal").style.display='none';
  }

  addConstante(data: number, id: string, parameterName: string){
    const newData = {identifiant: id, parameter: parameterName,valeur: data + '', modifiedBy: this.user.name + ' ' + this.user.firstname};
    const constante = this.constanteData.filter(item => item.identifiant == id);
    console.log(newData);
    // S'il y a des données
    if(data){
      // Ajout de la constante
      if(constante.length !== 0){
        // Mise à jour de la constante
        this.updateConstante(newData, id);
      } else{
        this.postConstante(newData);
      }
    }
    
  }

  // Get Configs from AE server
  getConfigs(){
    this.backendService.getConfigs(this.token).subscribe(data => {
      console.log(data)
      this.CONFIGS = data;
      this.OPEX_INCREASE_BY_YEAR = this.CONFIGS.NPV.OPEX_INCREASE_BY_YEAR;
      this.TIME_TO_COMPUTE_NPV = this.CONFIGS.NPV.TIME_TO_COMPUTE_NPV;
      this.WACC = this.CONFIGS.NPV.WACC;
    }, (err) => console.log(err))
  }

  // Ajouter une constante
  postConstante(data: object){
    console.log(data)
    this.constanteService.postItem(data, this.token).subscribe((data) => {
      console.log(data);
      this.toastr.success('La valeur a été ajoutée avec succès', '', {
        timeOut: 10000,
        closeButton: true,
        positionClass: 'toast-top-center',
        progressBar: true,
      });
      
      // Charger nos constantes enregistrées en bases de données
      this.getConstanteData();

    }, (error) => {
      this.errors = [];
      console.log(error);
      if(error.status === 400){
        this.toastr.error(error.error.message, '', {
          timeOut: 120000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      } else{
        this.toastr.error('Une erreur est survenue pendant la mise à jour de la valeur', '', {
          timeOut: 10000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      }
    }, () => {});
  }

  // Mis à jour d'une constante
  updateConstante(data: object, id: string){
    this.constanteService.updateItem(data, id, this.token).subscribe((data) => {
      console.log(data);
      this.toastr.success('La valeur a été mise à jour avec succès', '', {
        timeOut: 10000,
        closeButton: true,
        positionClass: 'toast-top-center',
        progressBar: true,
      });
      
      // Charger nos constantes enregistrées en bases de données
      this.getConstanteData();

    }, (error) => {
      this.errors = [];
      console.log(error);
      if(error.status === 400){
        this.toastr.error(error.error.message, '', {
          timeOut: 120000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      } else{
        this.toastr.error('Une erreur est survenue pendant la mise à jour de la valeur', '', {
          timeOut: 10000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      }
    }, () => {});
  }

  addItem(data: any[], service: OpexService|CapexCostService|IhsOpexService|EscoOpexService|CagrService|ConstanteService|UpgradePathService|ClientMarginService) {
    service.postItem(data, this.token).subscribe((data) => {
      console.log(data);
      this.toastr.success('Les données ont été mises à jour avec succès', '', {
        timeOut: 10000,
        closeButton: true,
        positionClass: 'toast-top-center',
        progressBar: true,
      });
      
      // Charger nos données enregistrées en bases de données
      service.getItems(this.token).subscribe((data)=>{
        console.log(data);
        service.data = data;
        this.backendService.paramData = data;
        service.showDetails();
        this.openModal();
      });

    }, (error) => {
      this.errors = [];
      console.log(error);
      if(error.status === 400){
        this.toastr.error(error.error.message, '', {
          timeOut: 120000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      } else{
        this.toastr.error('Une erreur est survenue pendant la mise à jour des données', '', {
          timeOut: 10000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      }
    }, () => {});
  }

  updateItem(data: any[], service: OpexService|CapexCostService|IhsOpexService|EscoOpexService|CagrService|ConstanteService|UpgradePathService|ClientMarginService) {
    // console.log(id);
    service.updateAll(data, this.token).subscribe((data) => {
      console.log(data);
      this.toastr.success('La mise à jour a été effectuée avec succès', '', {
        timeOut: 10000,
        closeButton: true,
        positionClass: 'toast-top-center',
        progressBar: true,
      });

      // Charger nos données enregistrées en bases de données
      service.getItems(this.token).subscribe((data)=>{
        console.log(data);
        service.data = data;
        this.backendService.paramData = data;
        service.showDetails();
        this.openModal();
      });

    }, (error) => {
      this.errors = [];
      console.log(error);
      if(error.status === 400){
        this.toastr.error(error.error.message, '', {
          timeOut: 120000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      } else{
        this.toastr.error('Une erreur est survenue pendant la modification', '', {
          timeOut: 10000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      }
     
    }, () => {});
  }

  deteleItem(service){
    const id = this.item['id'];
    // console.log(id);
    service.deleteItem(id, this.token).subscribe((data) => {
      console.log(data);
      this.toastr.success('L\'élément a été supprimé avec succès', '', {
        timeOut: 10000,
        closeButton: true,
        positionClass: 'toast-top-center',
        progressBar: true,
      });
    }, (error) => {
      this.errors = [];
      console.log(error);
      if(error.status === 400){
        this.toastr.error(error.error.message, '', {
          timeOut: 120000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      } else{
        this.toastr.error('Une erreur est survenue pendant la modification', '', {
          timeOut: 10000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      }
    }, () => {});
  }

  // Get Params details from the Data base
  getParamDetails(service: OpexService|CapexCostService|IhsOpexService|EscoOpexService|CagrService|ConstanteService|UpgradePathService|ClientMarginService){
    service.getItems(this.token).subscribe((data) => {
      console.log(data);
      service.data = data;
      this.backendService.paramData = data;
      service.showDetails();
      this.openModal(); 
    });
  }

  getConstanteData(){
    this.constanteService.getItems(this.token).subscribe((data) => {
      console.log(data);
      this.constanteData = data == null ? [] : data; // ALL const PARAMETERS, so we should filter to find each one
      /*const monthlyRentOpex: Constante[] = this.constanteData.filter(item => item.identifiant == 'P1');
      if (monthlyRentOpex.length !==0){
        this.monthlyRentOpex = parseInt(monthlyRentOpex[0].valeur);
      }

      const investmentRecoveryTime: Constante[] = this.constanteData.filter(item => item.identifiant == 'P4');
      if (investmentRecoveryTime.length !==0){
        this.investmentRecoveryTime= parseInt(investmentRecoveryTime[0].valeur);
      }

      const evolutionAnnualOpex: Constante[] = this.constanteData.filter(item => item.identifiant == 'P2');
      if (evolutionAnnualOpex.length !==0){
        this.evolutionAnnualOpex= parseInt(evolutionAnnualOpex[0].valeur);
      }

      const clientAverageLifetime: Constante[] = this.constanteData.filter(item => item.identifiant == 'P3');
      if (clientAverageLifetime.length !==0){
        this.clientAverageLifetime = parseInt(clientAverageLifetime[0].valeur);
      }*/

    }, (error) => console.log(error));
  }

  // Vérifier s'il y a des données pour ce paramètre
  /*getParamData(service: CapexCostService|IhsOpexService|EscoOpexService|CagrService|ConstanteService|UpgradePathService|ClientMarginService): any{
    service.getItems(this.token).subscribe((data) => {
      return data;
      
    }, (error) => console.log(error));
  }*/

  exportToExcel(data: any[]): void {
      console.log(data);
       const infoGen = [];
       data.forEach(item => {
          infoGen.push(item);
       });
       // console.log(details);
       const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(infoGen);
       // const wsDetails: XLSX.WorkSheet = XLSX.utils.json_to_sheet(details);
       const wb: XLSX.WorkBook = XLSX.utils.book_new();
       XLSX.utils.book_append_sheet(wb, ws, this.tabName);
       //XLSX.utils.book_append_sheet(wb, wsDetails, 'Détails');
  
       XLSX.writeFile(wb, this.backendService.title + '.xlsx');
  }

  isCapex(data: object): data is Capex {
    return data.hasOwnProperty('capex') && data.hasOwnProperty('cellBand');
  }

  isEscoOpex(data: any): data is IhsOpex {
    return 'band' in data && 
            'averagePower' in data &&
            'indoorAverageMonthlyOpexXof' in data &&
            'outdoorAverageMonthlyOpexXof' in data;
  }

  isOpex(data: any): data is IhsOpex {
    return 'identifiant' in data &&
            'cellBand' in data &&
            'provider' in data &&
            'power' in data &&
            'indoor' in data &&
            'outdoor' in data &&
            'gridGenset' in data &&
            'other' in data;
  }

  isIhsOpex(data: any): data is EscoOpex {
    return 'band' in data && 
            'averageEnergy' in data &&
            'gridGensetSiteAverageMonthlyOpexXof' in data &&
            'gensetOnlyOrSolarSiteAverageMonthlyOpexXof' in data;
  }

  isCagr(data: any): data is Cagr {
    return 'identifiant' in data && 
            'parameter' in data &&
            'valeur' in data;
  }
  
  isConstante(data: any): data is Constante {
    return 'identifiant' in data && 
            'parameter' in data &&
            'valeur' in data;
  }

  isUpgradePathParam(data: any): data is UpgradePathParameter {
    return 'identifiant' in data && 
            'parameter' in data &&
            'valeur' in data;
  }

  isClientmargin(data: any): data is Clientmargin {
    return data.hasOwnProperty('identifiant') && data.hasOwnProperty('categorie') &&
    data.hasOwnProperty('donnee') && data.hasOwnProperty('unite') &&
    data.hasOwnProperty('valeur');
  }

  // Validate data uploaded structure
  validateData(data: any[], isType: Function){
    console.log(data[0]);
    if (isType(data[0])) {
      return true;
    } else{
      return false;
    }
  }

// Upload Function
  onFileChange(ev: any, fileTabName: string, parameterName: string) {
    // this.ngxService.start();
    let workBook = null;
    let jsonData = null;
    const reader = new FileReader();
    this.file = ev.target.files[0];
    reader.onload = (event) => {
      const data = reader.result;
      workBook = XLSX.read(data, { type: 'binary' });
      jsonData = workBook.SheetNames.reduce((initial, name) => {
        const sheet = workBook.Sheets[name];
        initial[name] = XLSX.utils.sheet_to_json(sheet, {blankrows: true, raw: true});
        return initial;
      }, {});
      // const dataString = JSON.stringify(jsonData);
      console.log(jsonData);
      const intData: any[] = jsonData[fileTabName];
      console.log(intData);
      const finalData = [];

      if(!intData){
        console.log('type nok');
        return this.uploadErrorMessage();
      }
      if(intData.length > 0){
        intData.forEach(item => {
          let newItem: any = {};
          for (let [key, value] of Object.entries(item)) {
            // Transform our data to Backend format
            newItem[key] = value;
          }
          newItem['modifiedBy'] = this.user.name + ' ' + this.user.firstname
          finalData.push(newItem);
        });
      }
      console.log(finalData);
      // Determine the best function for the parameter
      switch(parameterName) {
        case 'Capex':
          const input = document.getElementById('capex') as HTMLInputElement;
          input.value = null;
          // Cast value to float
          finalData.forEach(data => {
            data.capex =data.capex? parseFloat(data.capex):0;
          })
          if(this.validateData(finalData, this.isCapex)){
            this.tabName = fileTabName; // Our current file Tab name
            this.addItem(finalData, this.capexService); 
          }else{
            this.uploadErrorMessage();
            // console.log('upload nok');
          }
          break;
        case 'Opex':
            const opexInput = document.getElementById('opex') as HTMLInputElement;
            opexInput.value = null;
            // Cast value to float
            finalData.forEach(data => {
              data.power = data.power ? parseFloat(data.power):0;
              data.indoor = data.indoor ? parseFloat(data.indoor):0;
              data.outdoor = data.outdoor? parseFloat(data.outdoor):0;
              data.gridGenset =data.gridGenset? parseFloat(data.gridGenset):0;
              data.other = data.other?parseFloat(data.other):0;
            })
            if(this.validateData(finalData, this.isOpex)){
              this.tabName = fileTabName; // Our current file Tab name
              this.addItem(finalData, this.opexService); 
            }else{
              this.uploadErrorMessage();
              // console.log('upload nok');
            }
            break;
        case 'IhsOpex':
          const ihsOpexInput = document.getElementById('ihs') as HTMLInputElement;
          ihsOpexInput.value = null;
          if(this.validateData(finalData, this.isIhsOpex)){
            this.tabName = fileTabName; // Our current file Tab name
            this.addItem(finalData, this.ihsOpexService);
            
          }else{
            this.uploadErrorMessage();
            // console.log('upload nok');
          }
          break;
        case 'EscoOpex':
          const escoOpexInput = document.getElementById('esco') as HTMLInputElement;
          escoOpexInput.value = null;
          if(this.validateData(finalData, this.isEscoOpex)){
            this.tabName = fileTabName; // Our current file Tab name
            this.addItem(finalData, this.escoOpexService);
          }else{
            this.uploadErrorMessage();
            // console.log('upload nok');
          }
          break;
        case 'Cagr':
          const cagrInput = document.getElementById('cagr') as HTMLInputElement;
          cagrInput.value = null;
          if(this.validateData(finalData, this.isCagr)){
            this.tabName = fileTabName; // Our current file Tab name
            // Cast value to float
            finalData.forEach(data => {
              data.valeur = data.valeur?parseFloat(data.valeur):0
            })
            // 
            this.addItem(finalData, this.cagrService); 
          }else{
            this.uploadErrorMessage();
            // console.log('upload nok');
          }
            break;
        case 'ClientMargin':
          const clientMarginInput = document.getElementById('client-margin') as HTMLInputElement;
          clientMarginInput.value = null;
          if(this.validateData(finalData, this.isClientmargin)){
            this.tabName = fileTabName; // Our current file Tab name
            this.addItem(finalData, this.clientmarginService);
          }else{
            this.uploadErrorMessage();
            console.log('client margin file nok');
          }
          break;
        case 'UpgradePathParameter':
          if(this.validateData(finalData, this.isUpgradePathParam)){
            this.tabName = fileTabName; // Our current file Tab name
            this.addItem(finalData, this.clientmarginService);
          }else{
            this.uploadErrorMessage();
            // console.log('upload nok');
          }
          break;
        default:
          return;
      }

      // Reinit our input file
      //this.inputFile = '';

    }
    reader.readAsBinaryString(this.file);
   /// this.ngxService.stop();
  }

  uploadErrorMessage(){
    this.toastr.error('Echec, le fichier n\'est pas au bon format.Merci de vérifier les entêtes et le contenu.', '', {
      timeOut: 20000,
      closeButton: true,
      positionClass: 'toast-top-center',
      progressBar: true,
    });
  }

  
  

}
