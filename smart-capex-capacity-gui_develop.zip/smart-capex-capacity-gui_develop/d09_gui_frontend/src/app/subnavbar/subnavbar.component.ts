import { Component, OnInit } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { UserService } from '../services/user.service';
import { ViewService } from '../services/view.service';

@Component({
  selector: 'app-subnavbar',
  templateUrl: './subnavbar.component.html',
  styleUrls: ['./subnavbar.component.css']
})
export class SubnavbarComponent implements OnInit {

  role: string; // le rôle de l'user actuel
  views = []; // Les views (roles que l'user courant a)
  token = '';
  constructor(
    public authService: AuthService,
    public userService: UserService,
    public viewService: ViewService
  ) { }

  ngOnInit(): void {
    this.token = this.authService.getToken();
    /*this.userService.me(this.authService.getToken()).subscribe(data => {
      this.role = data.role;
      this.views = this.authService.getViews(this.role);
    })*/
  }

}
