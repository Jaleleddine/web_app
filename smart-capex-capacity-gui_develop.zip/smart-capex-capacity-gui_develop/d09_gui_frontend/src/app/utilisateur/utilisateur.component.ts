import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import { ToastrService } from 'ngx-toastr';
import { ViewService } from '../services/view.service'
import { AuthService } from '../services/auth.service';
import { BackendService } from '../services/backend.service';
import { FormGroup, FormBuilder, Validators} from '@angular/forms';

@Component({
  selector: 'app-utilisateur',
  templateUrl: './utilisateur.component.html',
  styleUrls: ['./utilisateur.component.css']
})
export class UtilisateurComponent implements OnInit {

  user: any;
  data: any;
  dataForTable: any;
  item: any;
  p: number = 1;
  token = '';
  role: string;
  views = [];
  fr: any;
  date = new Date()

  isUpdate = false;
  title = ''; // Le titre du modal
  addForm: FormGroup;
  errors = [];
  submited = false;
  modalVisibility = false;

  errorMessages = {
    email: [
      { type: 'required', message: 'L\'email est obligatoire.' },
      { type: 'pattern', message: 'L\'email n\'est pas valide.' }
    ],
    uLogin: [
      { type: 'required', message: 'Le login est obligatoire.' },
      { type: 'maxlength', message: 'Le login ne doit pas dépasser 20 caractères.' }
    ],
    uName: [
      { type: 'required', message: 'Le nom est obligatoire.' },
      { type: 'maxlength', message: 'Le nom ne doit pas dépasser 80 caractères.' }
    ],
    firstname: [
      { type: 'required', message: 'Le prénom est obligatoire.' },
      { type: 'maxlength', message: 'Le prénom ne doit pas dépasser 100 caractères.' }
    ],
    isActive: [
      { type: 'required', message: 'Le status est obligatoire.' },
    ],
    role: [
      { type: 'required', message: 'Le rôle est obligatoire.' },
    ],
    phoneNumber: [
      { type: 'required', message: 'Le numéro de téléphone est obligatoire.' },
      { type: 'pattern', message: 'Le numéro de téléphone n\'est pas valide.' },
    ],
  };

  get f() { return this.addForm.controls; }

  constructor(
    private userService: UserService,
    private toastr: ToastrService,
    public fb: FormBuilder,
    private authService: AuthService,
   private backendService: BackendService,
   private viewService: ViewService
  ) { }

  ngOnInit(): void {
    // Get user views
    this.views = this.viewService.views;
    this.fr = this.backendService.translateInFrench();
    this.user = this.authService.getUser();
    this.addForm = this.fb.group({
      uName: ['', [Validators.required, Validators.maxLength(80)]],
      firstname: ['', [Validators.required, Validators.maxLength(100)]],
      uLogin: ['', [Validators.required, Validators.maxLength(20)]],
      createdBy: [''],
      updatedBy: [''],
      isActive: [0, [Validators.required]],
      role: [, [Validators.required]],
      email: ['', [Validators.required, Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
      phoneNumber: ['', [Validators.required, Validators.pattern(new RegExp('^22507[0-9]{8}$'))]],
    });
    this.updateForm();
    // Get token first and after initial data
    if(this.authService.isProd){
      this.userService.refreshToken().subscribe(data => {
        this.token = data.token;
        this.authService.token.next(data.token);
        this.getData();
      }, (err => {
        console.log(err);
        this.toastr.error('Une erreur est survenue pendant le chargement de la page.', '', {
          timeOut: 10000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      }))
    } else {
        this.token = this.authService.getToken();
        this.authService.token.next(this.token)
        // Get initial data
        this.getData();
    }
  }

  closeModal() {
    // document.getElementById('delete-box').style.display='none'
    document.getElementById("myModal").style.display='none'
    this.addForm.reset();
  }

  showModal(){
    // this.modalVisibility = true;
    document.getElementById("myModal").style.display='block'
  }

  showDeleteConfirm(item): void {
    this.item = item;
    document.getElementById('delete-box').style.display='block'
  }

  updateForm() {
    if (this.isUpdate) {
      this.title = 'MODIFIER L\'UTILISATEUR';
      this.addForm.get('email').setValue(this.item.email);
      this.addForm.get('uLogin').setValue(this.item.uLogin);
      this.addForm.get('createdBy').setValue(this.item.createdBy);
      this.addForm.get('updatedBy').setValue(this.item.updatedBy);
      this.addForm.get('uName').setValue(this.item.uName);
      this.addForm.get('firstname').setValue(this.item.firstname);
      this.addForm.get('role').setValue(this.item.role);
      this.addForm.get('isActive').setValue(this.item.isActive);
      this.addForm.get('phoneNumber').setValue(this.item.phoneNumber);
    } else {
      this.title = 'AJOUTER UN NOUVEL UTILISATEUR';
      console.log('new item');
    }
  }

 getData(){
    this.userService.getItems(this.token).subscribe(datas => {
      console.log(datas);
      this.data = datas;
      this.dataForTable = this.data;
      console.log(this.data);
    }, (error) => {
      console.log(error);
      this.toastr.error('Une erreur est survenue pendant le chargement!', '', {
        timeOut: 10000,
        closeButton: true,
        positionClass: 'toast-top-center',
        progressBar: true,
      });
    });
  }

  globalFilter(value) {
    if (!value){
      this.dataForTable = this.data;
    } else {
      this.dataForTable = this.data.filter(val => {
        const result = (val.email.includes(value)) ||
        (val.uLogin.includes(value))||
        (val.uName.includes(value))||
        (val.phoneNumber.includes(value))||
        (val.firstname.includes(value))
        return result;
      });
    }
  }

  modifyItem(item){
    this.item = item;
    this.isUpdate = true;
    this.updateForm();
    this.showModal();
    console.log('modification item');
  }

  addNewItem(){
    this.isUpdate = false;
    this.updateForm();
    this.showModal();
  }


  onSubmit() {
    this.submited = true;
    console.log(this.addForm.value);
    if (this.isUpdate) {
      this.updateItem();
    } else {
      this.addItem();
    }
  }


  addItem() {
    this.addForm.get('createdBy').setValue(this.user.name + ' ' + this.user.firstname);
    const statut = this.addForm.get('isActive').value == '1' ? 1 : 0;
    this.addForm.get('isActive').setValue(statut);
    console.log(this.addForm.value);
    this.userService.postItem(this.addForm.value, this.token).subscribe((data) => {
      console.log(data);
      this.toastr.success('L\'utilisateur a été enregistré avec succès', '', {
        timeOut: 10000,
        closeButton: true,
        positionClass: 'toast-top-center',
        progressBar: true,
      });
      this.getData();
    }, (error) => {
      this.errors = [];
      console.log(error);
      if(error.status === 400){
        this.toastr.error(error.error.message, '', {
          timeOut: 120000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      } else{
        this.toastr.error('Une erreur est survenue pendant l\'ajout', '', {
          timeOut: 10000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      }
    }, () => {this.submited = false; this.closeModal(); this.addForm.reset(); });
  }

  updateItem() {
    this.addForm.get('updatedBy').setValue(this.user.name + ' ' + this.user.firstname);
    const statut = this.addForm.get('isActive').value == '1' ? 1 : 0;
    this.addForm.get('isActive').setValue(statut);
    const id = this.item['id'];
    console.log(id);
    this.userService.updateItem(this.addForm.value, id, this.token).subscribe((data) => {
      console.log(data);
      this.toastr.success('L\'utilisateur a été modifié avec succès', '', {
        timeOut: 10000,
        closeButton: true,
        positionClass: 'toast-top-center',
        progressBar: true,
      });
      this.getData();
    }, (error) => {
      this.errors = [];
      console.log(error);
      if(error.status === 400){
        this.toastr.error(error.error.message, '', {
          timeOut: 120000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      } else{
        this.toastr.error('Une erreur est survenue pendant la modification', '', {
          timeOut: 10000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      }
     
    }, () => {this.submited = false; this.closeModal(); this.addForm.reset(); this.isUpdate = false; });
  }

  deteleItem(){
    const id = this.item['id'];
    // console.log(id);
    this.userService.deleteItem(id, this.token).subscribe((data) => {
      console.log(data);
      this.toastr.success('L\'utilisateur a été supprimé avec succès', '', {
        timeOut: 10000,
        closeButton: true,
        positionClass: 'toast-top-center',
        progressBar: true,
      });
      this.getData();
    }, (error) => {
      this.errors = [];
      console.log(error);
      if(error.status === 400){
        this.toastr.error(error.error.message, '', {
          timeOut: 120000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      } else{
        this.toastr.error('Une erreur est survenue pendant la modification', '', {
          timeOut: 10000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      }
    }, () => {this.submited = false; document.getElementById('delete-box').style.display='none'});
  }

}
