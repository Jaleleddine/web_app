import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { NgxUiLoaderService } from 'ngx-ui-loader';
import { BackendService } from '../services/backend.service';
import { AuthService } from '../services/auth.service';
import { DvReportService } from '../services/dv-report.service';
import { UserService } from '../services/user.service'
import * as _ from 'lodash';
// import * as z from 'zebras';
//import { forkJoin, zip} from 'rxjs';
import * as echarts from 'echarts';
//import * as L from 'leaflet';
import 'node_modules/leaflet.tilelayer.colorfilter/src/leaflet-tilelayer-colorfilter.js';
import * as XLSX from 'xlsx';
import * as moment from 'moment';

@Component({
  selector: 'app-dv-report',
  templateUrl: './dv-report.component.html',
  styleUrls: ['./dv-report.component.css']
})
export class DvReportComponent implements OnInit {

  p =1;
  data: any[];
  dvP =1;
  dvData: any[];
  dataForTable: any[];
  selectedAnomalie: any;
  selectedAnomaly: any;
  anomalies: any[];
  item: any;
  title = '';
  isUpdate = false;
  token = '';
  user: any;
  fr: any;
  treeChart: any;
  heatChart: any;
  periodeStart = new Date('2022-04-01');
  periodeEnd = new Date()
  periodeStartStr = this.backendService.getIsoWeek(this.periodeStart)//moment(this.periodeStart).format('DD-MM-YYYY');
  periodeEndStr = this.backendService.getIsoWeek(this.periodeEnd)//moment(this.periodeEnd).format('DD-MM-YYYY')

  constructor(
    private backendService: BackendService,
    private ngxService: NgxUiLoaderService,
    private toastr: ToastrService,
    private authService: AuthService,
    private userService: UserService,
    private dvReportService: DvReportService
  ) { }

  ngOnInit(): void {
    this.fr = this.backendService.translateInFrench();
    this.user = this.authService.getUser();
      // Get token first and after initial data
      if(this.authService.isProd){
        this.userService.refreshToken().subscribe(data => {
          //console.log(data)
          this.token = data.token;
          this.authService.token.next(data.token)
          // Get initial data
          this.getData()
          this.getTreeMapData()
        }, (err => {
          console.log(err);
          this.toastr.error('Une erreur est survenue pendant le chargement de la page.', '', {
            timeOut: 10000,
            closeButton: true,
            positionClass: 'toast-top-center',
            progressBar: true,
          });
        }))
      } else {
          this.token = this.authService.getToken();
          this.authService.token.next(this.token)
          // Get initial data
          this.getData()
          this.getTreeMapData()
      }
  }

  getPeriodeEnd(itemDate?) {
    const date = itemDate ? new Date(itemDate) : new Date();
    const dateEnd = this.backendService.getIsoWeek(date)//moment(date).format('YYYY-MM-DD')
    return dateEnd;
  }

  getData(){
    /*console.log(this.backendService.getIsoWeek(this.periodeStart))
    console.log(this.backendService.getIsoWeek(this.periodeEnd))*/
    this.dvReportService.getItems(this.token, this.backendService.getIsoWeek(this.periodeStart), this.backendService.getIsoWeek(this.periodeEnd)).subscribe(data => {
      this.data = data?.data;
      this.dataForTable = data?.data;
      this.anomalies = _.uniq(data?.allData.map((item: any) => item["anomaly_short_description"]));
      //console.log(data)
      this.selectedAnomalie = this.anomalies[0];
      // Get the heatmap data
      this.dvReportService.getHeatMapData(this.token, `${this.selectedAnomalie}`, this.backendService.getIsoWeek(this.periodeStart), this.backendService.getIsoWeek(this.periodeEnd)).subscribe(heatData =>{
        //console.log(heatData)
        // Build the heat map
      this.heatMapChart(heatData.values, heatData.dates, heatData.kpis);
      }, (err) => {
        console.log(err);
        this.toastr.error('Une erreur est survenue pendant le chargement des données heatmap', '', {
          timeOut: 10000,
          closeButton: true,
          positionClass: 'toast-top-center',
          progressBar: true,
        });
      })

    }, (err) => {
      console.log(err);
      this.toastr.error('Une erreur est survenue pendant le chargement des anomalies', '', {
        timeOut: 10000,
        closeButton: true,
        positionClass: 'toast-top-center',
        progressBar: true,
      });
    })
  }

  // Search Data
  searchData(){
    this.getData();
    this.getTreeMapData();
    this.periodeStartStr = this.backendService.getIsoWeek(this.periodeStart)//moment(this.periodeStart).format('DD-MM-YYYY');
    this.periodeEndStr = this.backendService.getIsoWeek(this.periodeEnd)//moment(this.periodeEnd).format('DD-MM-YYYY')
  }


  getDvExempelsData(anomaly){
    //console.log(anomaly)
    this.dvReportService.getDvExemplesData(this.token, anomaly?.id).subscribe(data => {
      console.log(data)
      this.dvData = data;
      document.getElementById("myModal").style.display='block';
      this.selectedAnomaly = anomaly;
    }, (err) => {
      console.log(err);
      this.toastr.error('Une erreur est survenue pendant le chargement des anomalies', '', {
        timeOut: 10000,
        closeButton: true,
        positionClass: 'toast-top-center',
        progressBar: true,
      });
    })
  }

  // 
  getTreeMapData(){
    const dateEnd = this.periodeEnd ? this.backendService.getIsoWeek(this.periodeEnd): this.getPeriodeEnd();
    this.dvReportService.getTreeMapData(this.token,this.backendService.getIsoWeek(this.periodeStart)/*this.backendService.getIsoWeek(this.periodeStart)*/, dateEnd).subscribe(data => {
      //console.log(data)
      // Build the tree map
      this.treeMapChart(data)
    }, (err) => {
      console.log(err);
      this.toastr.error('Une erreur est survenue pendant le chargement des anomalies', '', {
        timeOut: 10000,
        closeButton: true,
        positionClass: 'toast-top-center',
        progressBar: true,
      });
    })
  }

  getHeatMapData(){
    const dateEnd = this.periodeEnd ? this.backendService.getIsoWeek(this.periodeEnd): this.getPeriodeEnd();
    this.dvReportService.getHeatMapData(this.token,this.selectedAnomalie, this.backendService.getIsoWeek(this.periodeStart), dateEnd).subscribe(data => {
      console.log(data)
      // Build the heat map
      this.heatMapChart(data.values, data.dates, data.kpis);
      // Filter the table data
      this.dataForTable = this.data.filter((val) => {
        const rVal = (
          val.anomaly_short_description.includes(this.selectedAnomalie)
         );
        return rVal;
      });
    }, (err) => {
      console.log(err);
      this.toastr.error('Une erreur est survenue pendant le chargement des anomalies', '', {
        timeOut: 10000,
        closeButton: true,
        positionClass: 'toast-top-center',
        progressBar: true,
      });
    })
  }


  exportToExcel(data: any[]): void {
    //console.log(data);
   const ws: XLSX.WorkSheet = XLSX.utils.json_to_sheet(data);
   // const wsDetails: XLSX.WorkSheet = XLSX.utils.json_to_sheet(details);
   const wb: XLSX.WorkBook = XLSX.utils.book_new();
   XLSX.utils.book_append_sheet(wb, ws, 'LISTE_ANOMALIES');
   XLSX.writeFile(wb, 'LISTE_ANOMALIES.xlsx');
}

  close(){
    document.getElementById("myModal").style.display = "none";
  }

  globalFilter(value: any): any {
    if (!value) {
      this.dataForTable = this.data;
    } else {
      this.dataForTable = this.data.filter((val) => {
        const rVal = (
          val.id.includes(value) || val.anomaly_short_description.includes(value) || val.feature_name.includes(value)
         );
        return rVal;
      });
    }
  }

  // For tree map
  getLevelOption() {
    return [
      {
        itemStyle: {
          borderWidth: 0,
          gapWidth: 5
        }
      },
      {
        itemStyle: {
          gapWidth: 1
        }
      },
      {
        colorSaturation: [0.35, 0.5],
        itemStyle: {
          gapWidth: 1,
          borderColorSaturation: 0.6
        }
      }
    ];
  }

  treeMapChart(data: any[]){
    if(!this.treeChart){
      this.treeChart = echarts.init(document.getElementById('tree-map'));
    }

    const formatUtil = echarts.format;

    // Les options de notre graphe
    const option = {
      title: {
        text: `Anomalies Détectées sur la période de ${moment(this.periodeStart).format('DD-MM-YYYY')} à ${moment(this.periodeEnd).format('DD-MM-YYYY')}`,
        left: 'center',
        textStyle:{
          fontSize: 14
        }
      },
      tooltip: {
        formatter: function (info) {
          var value = info.value;
          var treePathInfo = info.treePathInfo;
          var treePath = [];
          for (var i = 1; i < treePathInfo.length; i++) {
            treePath.push(treePathInfo[i].name);
          }
          return [
            '<div class="tooltip-title">' +
              formatUtil.encodeHTML(treePath.join('/')) +
              '</div>',
            'Anomalie: ' + formatUtil.addCommas(value) + ''
          ].join('');
        }
      },
      series: [
        {
          name: 'Anomalies Détectées',
          type: 'treemap',
          visibleMin: 300,
          label: {
            show: true,
            formatter: '{b}'
          },
          itemStyle: {
            borderColor: '#fff'
          },
          levels: this.getLevelOption(),
          data
        }
      ]
    }
  
    // use configuration item and data specified to show chart
    this.treeChart.setOption(option);
  }

  
  heatMapChart(data:any, dates, kpis){
    if(!this.heatChart){
      this.heatChart = echarts.init(document.getElementById('heat-map'));
    }
    // Les options de notre graphe
    const option =  {
      title: {
        text: `Anomalie "${this.selectedAnomalie}" détectée sur la période de ${moment(this.periodeStart).format('DD-MM-YYYY')} à ${moment(this.periodeEnd).format('DD-MM-YYYY')}`,
        left: 'center',
        textStyle:{
          fontSize: 14
        }
      },
      tooltip: {
        position: 'top'
      },
      grid: {
        height: '50%',
        top: '10%',
        left: '20%'
      },
      xAxis: {
        type: 'category',
        data: dates,
        splitArea: {
          show: true
        }
      },
      yAxis: {
        type: 'category',
        data: kpis,
        splitArea: {
          show: true
        }
      },
      visualMap: {
        min: 0,
        max: 10,
        calculable: true,
        orient: 'horizontal',
        left: 'center',
        bottom: '15%'
      },
      series: [
        {
          name: 'Nbre Anomalies',
          type: 'heatmap',
          data: data,
          label: {
            show: true
          },
          emphasis: {
            itemStyle: {
              shadowBlur: 10,
              shadowColor: 'rgba(0, 0, 0, 0.5)'
            }
          }
        }
      ]
    };
  
    // use configuration item and data specified to show chart
    this.heatChart.setOption(option);
  }


}
