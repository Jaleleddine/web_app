import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DvReportComponent } from './dv-report.component';

describe('DvReportComponent', () => {
  let component: DvReportComponent;
  let fixture: ComponentFixture<DvReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DvReportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DvReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
