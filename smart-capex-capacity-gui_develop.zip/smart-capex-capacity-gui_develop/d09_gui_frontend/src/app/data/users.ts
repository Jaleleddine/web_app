export const users = [
    {
        username: 'DATASCIENCE',
        password: 'adm1+1=2',
        role: 'ADMIN',
    },
    {
        username: 'TEST',
        password: 'test0-0=0',
        role: 'ADMIN',
    },
    
];
