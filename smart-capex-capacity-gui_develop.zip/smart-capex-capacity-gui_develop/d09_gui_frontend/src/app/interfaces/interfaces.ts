export interface Capex {
      cellBand: string,
      capex: number,
}

export interface EscoOpex{
      band: string,
      averagePower: number,
      indoorAverageMonthlyOpexXof: number,
      outdoorAverageMonthlyOpex: number,
}

export interface IhsOpex{
      band: string,
      averageEnergy: number,
      gridGensetSiteAverageMonthlyOpexXof: number,
      gensetOnlyOrSolarSiteAverageMonthlyOpexXof: number,
    
}

export interface Opex{
      identifiant: string,
      cellBand: string,
      provider: string,
      power: number,
      indoor: number,
      outdoor: number,
      gridGenset: number,
      other: number
}

export interface Cagr {
      identifiant: string;
      parameter: string;
      valeur?: number;
}

export interface Constante{
      identifiant: string,
      parameter: string,
      valeur: string,
}

export interface Clientmargin{
      identifiant: string,
      categorie: string,
      donnee: string,
      unite?: string,
      valeur?: any,
}

export interface UpgradePathParameter{
      identifiant: string,
      parameter: string,
      valeur: string,
}

export interface Site {
      siteId?: string,
      sitePhysique?: string,
      siteStatus?: string,
      siteVille?: string,
      siteGestionnaire?: string,
      siteQuartier?: string,
      siteCommune?: string,
      siteDepartment?: string,
      siteRegion?: string,
      siteDistrict?: string,
      siteZoneCommerciale?: string,
      siteLongitude?: number,
      siteLatitude?: number,
      siteTowerHeight?: string,
      siteTypeBaie?: string,
      siteGeotype?: string,
      siteEnergyType?: string,
      opexKey?: string
}

export interface SteeringNetwork{
      identifiant: string,
      typeTraffic: string,
      technologie: string,
      steering2020Percent: string,
      steering2021Percent: string,
      steering2022Percent: string,
      steering2023Percent?: string,
      steering2024Percent?: string,
      steering2025Percent?: string,
        
}

export interface Planification {
      name: string,
      budget: number,
      zonesConsidered: object[],
      sitesConsidered: object[],
      createdBy: string,
      updatedBy: string,
      validatedBy: string,
      sitesExcluded: string[],
      impactDuration: number,
      etatValidation: string,
      wacc: number,
      steeringNetwork: object[],
      dateDebut: string,
      anneeDeploiement: string,
      statutAnalyse: string,
}